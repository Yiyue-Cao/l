# libstrategy_lf4.so

SHA-256：`88e6969f6603fc9864009122b9f1036b732618416a5637847483096012095410`；大小：1,057,992字节。

## 策略逻辑

低频信号执行分支。配置包含四阈值、PV/滚动触发、动态持仓阈值和动态挂单时限，但风险配置主要为手数限制，没有 comm/SM 系列完整的金额上限字段。额外 max_try_hiter_times、max_try_hiter_time_ms、price_range_bp 控制尝试次数、尝试时间与报价价格范围；主回调中的具体状态更新及比较次序见逐函数伪代码。on_depth 与 on_signal 分担状态维护，on_finish 调用 all_in。不能只用一次 signal->order 的无状态函数代替此版。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x4b690 | 1845 | [strategy_lf4::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_lf4/decompiled_repaired/000000000004b690.c) |
| 0x4c990 | 554 | [strategy_lf4::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_lf4/decompiled_repaired/000000000004c990.c) |
| 0x4bf70 | 264 | [strategy_lf4::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_lf4/decompiled_repaired/000000000004bf70.c) |
| 0x4be60 | 264 | [strategy_lf4::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_lf4/decompiled_repaired/000000000004be60.c) |
| 0x4c740 | 586 | [strategy_lf4::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_lf4/decompiled_repaired/000000000004c740.c) |
| 0x4c080 | 1717 | [strategy_lf4::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_lf4/decompiled_repaired/000000000004c080.c) |
| 0x4bdd0 | 137 | [strategy_lf4::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_lf4/decompiled_repaired/000000000004bdd0.c) |
| 0x4b560 | 290 | [strategy_lf4::signal_trigger::SignalTrigger::new](../analysis/libstrategy_lf4/decompiled_repaired/000000000004b560.c) |
| 0x4cbc0 | 1378 | [_ZN12strategy_lf414signal_trigger17enum_rate_counter17hae8899c0d26c9baeE.llvm.754907104417532979](../analysis/libstrategy_lf4/decompiled_repaired/000000000004cbc0.c) |
| 0x44c20 | 307 | [<strategy_lf4::TargetTaskStatus as core::fmt::Debug>::fmt](../analysis/libstrategy_lf4/decompiled_repaired/0000000000044c20.c) |
| 0x41c80 | 1371 | [<strategy_lf4::StrategyLF4 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_lf4/decompiled_repaired/0000000000041c80.c) |
| 0x421e0 | 448 | [<strategy_lf4::StrategyLF4 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_lf4/decompiled_repaired/00000000000421e0.c) |
| 0x44b00 | 280 | [<strategy_lf4::StrategyLF4 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_lf4/decompiled_repaired/0000000000044b00.c) |
| 0x423a0 | 10073 | [<strategy_lf4::StrategyLF4 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_lf4/decompiled_repaired/00000000000423a0.c) |
| 0x4efd0 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_lf4/decompiled_repaired/000000000004efd0.c) |
| 0x4efe0 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_lf4/decompiled_repaired/000000000004efe0.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：28项

数组文件偏移 `0xc4f10`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `taker_rate_baseline`
9. `max_taker_rate`
10. `trade_slippery`
11. `close_position_block_ms`
12. `max_single_add_vol`
13. `max_single_net_vol`
14. `max_single_close_vol`
15. `long_open_threshold`
16. `long_close_threshold`
17. `short_open_threshold`
18. `short_close_threshold`
19. `dyn_score_position_ts_threshold_s`
20. `dyn_score_max_position_ts_s`
21. `dyn_score_delta_score`
22. `dyn_pending_position_ts_threshold_s`
23. `dyn_pending_max_position_ts_s`
24. `dyn_pending_order_max_pending_time_ms`
25. `dyn_pending_delta_max_pending_ts_ms`
26. `max_try_hiter_times`
27. `max_try_hiter_time_ms`
28. `price_range_bp`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_lf4/assembly.txt)、[符号](../analysis/libstrategy_lf4/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_lf4/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_lf4/核心伪代码.c)。
