# libstrategy_comm2.so

SHA-256：`5b32da10cb657475a2e46d4bf146ac16cbdd5ed3254154ca43de57a213506b5f`；大小：1,102,432字节。

## 策略逻辑

商品期货基础阈值策略。on_begin 解析 Comm2Params；on_signal 过滤交易时段、标的及信号，取得盘口和持仓，计算波动/价差分组，查 G1_LOW/G2_HIGH 的 K1，做 PV 变换和点/滚动窗口触发，再计算开平数量。主动执行前有 margin_filter、cancel_by_pending_ts、impact_block_check、cancel_all，最终调用 place_order_iap。on_depth 维护 touch gate；on_finish 调用 all_in。独有的 dyn_pending_* 参数让允许挂单时间随持仓时长变化。此版没有 comm3 的独立 low 四阈值和 maker 管理辅助函数。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x46350 | 61 | [strategy_comm2::Comm2Params::signal_mode](../analysis/libstrategy_comm2/decompiled_repaired/0000000000046350.c) |
| 0x46390 | 266 | [strategy_comm2::Comm2Params::signal_trigger_mode](../analysis/libstrategy_comm2/decompiled_repaired/0000000000046390.c) |
| 0x50920 | 572 | [strategy_comm2::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_comm2/decompiled_repaired/0000000000050920.c) |
| 0x517b0 | 554 | [strategy_comm2::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_comm2/decompiled_repaired/00000000000517b0.c) |
| 0x50d90 | 264 | [strategy_comm2::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_comm2/decompiled_repaired/0000000000050d90.c) |
| 0x50c80 | 264 | [strategy_comm2::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_comm2/decompiled_repaired/0000000000050c80.c) |
| 0x51560 | 586 | [strategy_comm2::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_comm2/decompiled_repaired/0000000000051560.c) |
| 0x50bf0 | 141 | [strategy_comm2::signal_trigger::SignalTrigger::point_signal_trigger_pv4](../analysis/libstrategy_comm2/decompiled_repaired/0000000000050bf0.c) |
| 0x50ea0 | 1717 | [strategy_comm2::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_comm2/decompiled_repaired/0000000000050ea0.c) |
| 0x50b60 | 137 | [strategy_comm2::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_comm2/decompiled_repaired/0000000000050b60.c) |
| 0x51f50 | 152 | [strategy_comm2::signal_trigger::dynamic_threshold](../analysis/libstrategy_comm2/decompiled_repaired/0000000000051f50.c) |
| 0x519e0 | 1378 | [_ZN14strategy_comm214signal_trigger17enum_rate_counter17h75e99b178f4d0e51E.llvm.12268379600032372830](../analysis/libstrategy_comm2/decompiled_repaired/00000000000519e0.c) |
| 0x50530 | 1001 | [strategy_comm2::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_comm2/decompiled_repaired/0000000000050530.c) |
| 0x55cc0 | 658 | [strategy_comm2::vol_spread_ratio::VolSpreadRatio::update](../analysis/libstrategy_comm2/decompiled_repaired/0000000000055cc0.c) |
| 0x464a0 | 824 | [<strategy_comm2::StrategyComm2 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_comm2/decompiled_repaired/00000000000464a0.c) |
| 0x48da0 | 475 | [<strategy_comm2::StrategyComm2 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_comm2/decompiled_repaired/0000000000048da0.c) |
| 0x48f80 | 280 | [<strategy_comm2::StrategyComm2 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_comm2/decompiled_repaired/0000000000048f80.c) |
| 0x467e0 | 9656 | [<strategy_comm2::StrategyComm2 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_comm2/decompiled_repaired/00000000000467e0.c) |
| 0x55f60 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_comm2/decompiled_repaired/0000000000055f60.c) |
| 0x55f70 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_comm2/decompiled_repaired/0000000000055f70.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：35项

数组文件偏移 `0xcdfc0`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `trade_slippery`
12. `close_position_block_ms`
13. `touch_gate`
14. `touch_gate_timeout_ms`
15. `max_single_add_vol`
16. `max_single_add_amt`
17. `max_single_net_vol`
18. `max_single_net_amt`
19. `max_single_close_vol`
20. `max_single_close_amt`
21. `long_open_threshold`
22. `long_close_threshold`
23. `short_open_threshold`
24. `short_close_threshold`
25. `dyn_score_position_ts_threshold_s`
26. `dyn_score_max_position_ts_s`
27. `dyn_score_delta_score`
28. `dyn_pending_position_ts_threshold_s`
29. `dyn_pending_max_position_ts_s`
30. `dyn_pending_order_max_pending_time_ms`
31. `dyn_pending_delta_max_pending_ts_ms`
32. `use_dynamic_volspread_ratio`
33. `market_volatility_ms`
34. `rolling_windows_ms`
35. `split_high_low_ratio_threshold`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_comm2/assembly.txt)、[符号](../analysis/libstrategy_comm2/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_comm2/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_comm2/核心伪代码.c)。
