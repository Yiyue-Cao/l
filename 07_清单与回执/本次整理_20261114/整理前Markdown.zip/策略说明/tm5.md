# libstrategy_tm5.so

SHA-256：`8ef98ebc94e89ad2274a13201ccb43618416a9df18a594dfe9debed63293aba6`；大小：1,051,448字节。

## 策略逻辑

taker/maker 策略族的滚动收益发布版本。on_signal 包含 PV/滚动触发、四阈值、动态阈值与动态挂单时限，on_order 处理成交回报，on_depth 更新窗口并发布 rolling_pnl。rolling_window_ms 控制收益观察窗口；字符串证据包含 ROLLPNL pl_fill、fill_ts_sec、sum_after、qlen，说明窗口状态围绕成交收益事件维护，而不只是每tick价格收益。具体已实现/浮动损益组成以回调证据为准，不应与账户净值收益率混用。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x4bc30 | 1845 | [strategy_tm5::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_tm5/decompiled_repaired/000000000004bc30.c) |
| 0x4cf30 | 554 | [strategy_tm5::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_tm5/decompiled_repaired/000000000004cf30.c) |
| 0x4c510 | 264 | [strategy_tm5::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_tm5/decompiled_repaired/000000000004c510.c) |
| 0x4c400 | 264 | [strategy_tm5::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_tm5/decompiled_repaired/000000000004c400.c) |
| 0x4cce0 | 586 | [strategy_tm5::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_tm5/decompiled_repaired/000000000004cce0.c) |
| 0x4c620 | 1717 | [strategy_tm5::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_tm5/decompiled_repaired/000000000004c620.c) |
| 0x4c370 | 137 | [strategy_tm5::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_tm5/decompiled_repaired/000000000004c370.c) |
| 0x4bb00 | 290 | [strategy_tm5::signal_trigger::SignalTrigger::new](../analysis/libstrategy_tm5/decompiled_repaired/000000000004bb00.c) |
| 0x4d160 | 1378 | [_ZN12strategy_tm514signal_trigger17enum_rate_counter17h181739a09271ffbbE.llvm.14383927985676670398](../analysis/libstrategy_tm5/decompiled_repaired/000000000004d160.c) |
| 0x415c0 | 915 | [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_tm5/decompiled_repaired/00000000000415c0.c) |
| 0x43d80 | 817 | [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_tm5/decompiled_repaired/0000000000043d80.c) |
| 0x439e0 | 928 | [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_order](../analysis/libstrategy_tm5/decompiled_repaired/00000000000439e0.c) |
| 0x440c0 | 280 | [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_tm5/decompiled_repaired/00000000000440c0.c) |
| 0x41960 | 8309 | [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_tm5/decompiled_repaired/0000000000041960.c) |
| 0x53e20 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_tm5/decompiled_repaired/0000000000053e20.c) |
| 0x53e30 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_tm5/decompiled_repaired/0000000000053e30.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：30项

数组文件偏移 `0xc3890`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `trade_slippery`
12. `close_position_block_ms`
13. `max_single_add_vol`
14. `max_single_add_amt`
15. `max_single_net_vol`
16. `max_single_net_amt`
17. `max_single_close_vol`
18. `max_single_close_amt`
19. `long_open_threshold`
20. `long_close_threshold`
21. `short_open_threshold`
22. `short_close_threshold`
23. `dyn_score_position_ts_threshold_s`
24. `dyn_score_max_position_ts_s`
25. `dyn_score_delta_score`
26. `dyn_pending_position_ts_threshold_s`
27. `dyn_pending_max_position_ts_s`
28. `dyn_pending_order_max_pending_time_ms`
29. `dyn_pending_delta_max_pending_ts_ms`
30. `rolling_window_ms`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_tm5/assembly.txt)、[符号](../analysis/libstrategy_tm5/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_tm5/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_tm5/核心伪代码.c)。
