# libstrategy_comm4.so

SHA-256：`81279cfe7eb2aa4eaf589d563e97bd795a969d77699af8a2cb6294a1f1103de1`；大小：1,226,480字节。

## 策略逻辑

在 comm3_2 框架中引入 watcher 驱动的三阶段控制。读取 watcher_strategy_name、watcher_account_name 指定对象发布的收益信息，next_phase 决定 P1/P2/P3，effective 合并全局参数与当前阶段的可选覆盖项。正常方向 P1 到 P2 用 enter_phase2，P2 到 P3 用 enter_phase3，回退使用 exit_phase2/exit_phase3；invert_phase 反转收益方向。每次最多走一个阶段。每阶段有15项覆盖，涵盖四阈值、LOW四阈值、low_action、持仓/增仓/平仓金额与手数约束。此版没有 min_trades_for_upgrade，不能把后续版的升级交易次数条件套入本版。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x4f0e0 | 151 | [strategy_comm4::next_phase](../analysis/libstrategy_comm4/decompiled_repaired/000000000004f0e0.c) |
| 0x4ed50 | 61 | [strategy_comm4::Comm4Params::signal_mode](../analysis/libstrategy_comm4/decompiled_repaired/000000000004ed50.c) |
| 0x4ed90 | 266 | [strategy_comm4::Comm4Params::signal_trigger_mode](../analysis/libstrategy_comm4/decompiled_repaired/000000000004ed90.c) |
| 0x4eea0 | 573 | [strategy_comm4::Comm4Params::effective](../analysis/libstrategy_comm4/decompiled_repaired/000000000004eea0.c) |
| 0x71d90 | 572 | [strategy_comm4::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_comm4/decompiled_repaired/0000000000071d90.c) |
| 0x72c20 | 554 | [strategy_comm4::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_comm4/decompiled_repaired/0000000000072c20.c) |
| 0x72200 | 264 | [strategy_comm4::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_comm4/decompiled_repaired/0000000000072200.c) |
| 0x720f0 | 264 | [strategy_comm4::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_comm4/decompiled_repaired/00000000000720f0.c) |
| 0x729d0 | 586 | [strategy_comm4::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_comm4/decompiled_repaired/00000000000729d0.c) |
| 0x72060 | 141 | [strategy_comm4::signal_trigger::SignalTrigger::point_signal_trigger_pv4](../analysis/libstrategy_comm4/decompiled_repaired/0000000000072060.c) |
| 0x72310 | 1717 | [strategy_comm4::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_comm4/decompiled_repaired/0000000000072310.c) |
| 0x71fd0 | 137 | [strategy_comm4::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_comm4/decompiled_repaired/0000000000071fd0.c) |
| 0x733c0 | 152 | [strategy_comm4::signal_trigger::dynamic_threshold](../analysis/libstrategy_comm4/decompiled_repaired/00000000000733c0.c) |
| 0x72e50 | 1378 | [_ZN14strategy_comm414signal_trigger17enum_rate_counter17h8905a6d63e128319E.llvm.12030102277605901293](../analysis/libstrategy_comm4/decompiled_repaired/0000000000072e50.c) |
| 0x719a0 | 1001 | [strategy_comm4::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_comm4/decompiled_repaired/00000000000719a0.c) |
| 0x4ff50 | 315 | [strategy_comm4::high_taker_rate](../analysis/libstrategy_comm4/decompiled_repaired/000000000004ff50.c) |
| 0x76a30 | 658 | [strategy_comm4::vol_spread_ratio::VolSpreadRatio::update](../analysis/libstrategy_comm4/decompiled_repaired/0000000000076a30.c) |
| 0x4f9e0 | 1377 | [strategy_comm4::live_pending_counts](../analysis/libstrategy_comm4/decompiled_repaired/000000000004f9e0.c) |
| 0x4f180 | 2134 | [strategy_comm4::cancel_order_use_range](../analysis/libstrategy_comm4/decompiled_repaired/000000000004f180.c) |
| 0x55080 | 27 | [strategy_comm4::place](../analysis/libstrategy_comm4/decompiled_repaired/0000000000055080.c) |
| 0x50090 | 738 | [<strategy_comm4::StrategyComm4 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_comm4/decompiled_repaired/0000000000050090.c) |
| 0x54d80 | 475 | [<strategy_comm4::StrategyComm4 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_comm4/decompiled_repaired/0000000000054d80.c) |
| 0x54f60 | 280 | [<strategy_comm4::StrategyComm4 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_comm4/decompiled_repaired/0000000000054f60.c) |
| 0x50380 | 18938 | [<strategy_comm4::StrategyComm4 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_comm4/decompiled_repaired/0000000000050380.c) |
| 0x6c8c0 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_comm4/decompiled_repaired/000000000006c8c0.c) |
| 0x6c8d0 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_comm4/decompiled_repaired/000000000006c8d0.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：55项

数组文件偏移 `0xe8e60`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `high_taker_half_spread`
12. `taker_mult_max`
13. `taker_cover_k`
14. `taker_skip_half_spread_bp`
15. `trade_slippery`
16. `close_position_block_ms`
17. `touch_gate`
18. `touch_gate_timeout_ms`
19. `max_single_add_vol`
20. `max_single_add_amt`
21. `max_single_net_vol`
22. `max_single_net_amt`
23. `max_single_close_vol`
24. `max_single_close_amt`
25. `long_open_threshold`
26. `long_close_threshold`
27. `short_open_threshold`
28. `short_close_threshold`
29. `low_long_open_threshold`
30. `low_long_close_threshold`
31. `low_short_open_threshold`
32. `low_short_close_threshold`
33. `dyn_score_position_ts_threshold_s`
34. `dyn_score_max_position_ts_s`
35. `dyn_score_delta_score`
36. `use_dynamic_volspread_ratio`
37. `market_volatility_ms`
38. `rolling_windows_ms`
39. `split_high_low_ratio_threshold`
40. `low_action`
41. `maker_order_max_pending_time_ms`
42. `max_maker_pending_vol_on_depth`
43. `maker_ticks_inside`
44. `maker_cancel_range_levels`
45. `enable_phases`
46. `invert_phase`
47. `watcher_strategy_name`
48. `watcher_account_name`
49. `enter_phase2`
50. `exit_phase2`
51. `enter_phase3`
52. `exit_phase3`
53. `phase1`
54. `phase2`
55. `phase3`

### 字段组2：15项

数组文件偏移 `0xe9488`。

1. `long_open_threshold`
2. `long_close_threshold`
3. `short_open_threshold`
4. `short_close_threshold`
5. `max_single_net_vol`
6. `max_single_net_amt`
7. `max_single_add_vol`
8. `max_single_add_amt`
9. `high_taker_half_spread`
10. `taker_mult_max`
11. `taker_cover_k`
12. `taker_skip_half_spread_bp`
13. `taker_rate_baseline`
14. `max_taker_rate`
15. `low_action`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_comm4/assembly.txt)、[符号](../analysis/libstrategy_comm4/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_comm4/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_comm4/核心伪代码.c)。
