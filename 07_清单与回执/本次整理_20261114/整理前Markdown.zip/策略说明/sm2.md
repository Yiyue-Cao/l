# libstrategy_sm2.so

SHA-256：`7d78c5e4ec850fc13bbf7c374eaeb24857de05276cb0c143c3e84a11cd9bf527`；大小：1,113,184字节。

## 策略逻辑

基于效用优化的报价分支，区别于 sm1 的点/滚动触发配置。输入包括 maker_signal_abtype_u、maker_signal_abtype_s、maker_signal_abtype_beta；UtilityRange::get_utility 和 QuotePriceOptimizer::optimal_quote_buy/sell 为核心。HitProbability 函数执行正态CDF型计算：z=(x-u)/s，F=0.5*(1+erf(z/sqrt(2)))；一个方向使用 beta*F，另一方向 beta*(1-F)。报价优化把报价相对收益空间与命中概率相乘，求买卖候选效用，再返回候选报价与有效性。必须保留 s、beta 的实际校验及失败回退，不能把概率输出先验认定总在[0,1]。该版无 cost_alpha、signal_trigger_mode、vote_rate 字段，不能套用 comm 的所有窗口逻辑。 已核对常量sqrt(2)、1、0.5、-0.5与erf导入。UtilityRange在有效候选报价q_b/q_s上计算 U_buy=F(q_b)*(v_buy-q_b)、U_sell=(1-F(q_s))*(q_s-v_sell)，候选不存在时对应效用为0。这里v_buy/v_sell表示该函数调用者传入的两侧价值参数，不擅自等同于中间价；UtilityRange自身的这两项公式未乘HitProbability对象的beta。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x45650 | 87 | [strategy_sm2::default_pv1](../analysis/libstrategy_sm2/decompiled_repaired/0000000000045650.c) |
| 0x48f50 | 501 | [strategy_sm2::format_utility_tag](../analysis/libstrategy_sm2/decompiled_repaired/0000000000048f50.c) |
| 0x456b0 | 723 | [strategy_sm2::apply_book_vol_cap_sm2](../analysis/libstrategy_sm2/decompiled_repaired/00000000000456b0.c) |
| 0x844f0 | 588 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_sm2/decompiled_repaired/00000000000844f0.c) |
| 0x84740 | 175 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::point_signal_trigger_utility](../analysis/libstrategy_sm2/decompiled_repaired/0000000000084740.c) |
| 0x84420 | 199 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::new](../analysis/libstrategy_sm2/decompiled_repaired/0000000000084420.c) |
| 0x847f0 | 152 | [strategy_signal_maker_common::signal_trigger::dynamic_threshold](../analysis/libstrategy_sm2/decompiled_repaired/00000000000847f0.c) |
| 0x841c0 | 598 | [strategy_signal_maker_common::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_sm2/decompiled_repaired/00000000000841c0.c) |
| 0x84890 | 63 | [strategy_signal_maker_common::signal_trigger::dynamic_pending_ts_ms](../analysis/libstrategy_sm2/decompiled_repaired/0000000000084890.c) |
| 0x828c0 | 359 | [strategy_signal_maker_common::get_quote_price::UtilityRange::get_utility](../analysis/libstrategy_sm2/decompiled_repaired/00000000000828c0.c) |
| 0x870b0 | 75 | [strategy_signal_maker_common::hit_probability::HitProbability::hit_probability](../analysis/libstrategy_sm2/decompiled_repaired/00000000000870b0.c) |
| 0x82dc0 | 1423 | [strategy_signal_maker_common::brentq_option_price::QuotePriceOptimizer::optimal_quote_buy](../analysis/libstrategy_sm2/decompiled_repaired/0000000000082dc0.c) |
| 0x83350 | 1455 | [strategy_signal_maker_common::brentq_option_price::QuotePriceOptimizer::optimal_quote_sell](../analysis/libstrategy_sm2/decompiled_repaired/0000000000083350.c) |
| 0x45990 | 854 | [<strategy_sm2::StrategySM2 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_sm2/decompiled_repaired/0000000000045990.c) |
| 0x48df0 | 352 | [<strategy_sm2::StrategySM2 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_sm2/decompiled_repaired/0000000000048df0.c) |
| 0x45cf0 | 12536 | [<strategy_sm2::StrategySM2 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_sm2/decompiled_repaired/0000000000045cf0.c) |
| 0x54a70 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_sm2/decompiled_repaired/0000000000054a70.c) |
| 0x54a80 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_sm2/decompiled_repaired/0000000000054a80.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：30项

数组文件偏移 `0xcf9f0`。

1. `signal_mode`
2. `pv1_alpha`
3. `trade_slippery`
4. `close_position_block_ms`
5. `max_single_add_vol`
6. `max_single_add_amt`
7. `max_single_net_vol`
8. `max_single_net_amt`
9. `max_single_close_vol`
10. `max_single_close_amt`
11. `long_open_threshold`
12. `long_close_threshold`
13. `short_open_threshold`
14. `short_close_threshold`
15. `dyn_score_position_ts_threshold_s`
16. `dyn_score_max_position_ts_s`
17. `dyn_score_delta_score`
18. `dyn_pending_position_ts_threshold_s`
19. `dyn_pending_max_position_ts_s`
20. `dyn_pending_delta_max_pending_ts_ms`
21. `order_max_pending_time_ms`
22. `maker_signal_abtype_u`
23. `maker_signal_abtype_s`
24. `maker_signal_abtype_beta`
25. `signal_all`
26. `touch_gate`
27. `touch_gate_timeout_ms`
28. `book_vol_cap`
29. `max_single_taker_vol`
30. `max_maker_pending_vol_on_depth`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_sm2/assembly.txt)、[符号](../analysis/libstrategy_sm2/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_sm2/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_sm2/核心伪代码.c)。
