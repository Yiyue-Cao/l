# libstrategy_comm4_1.so

SHA-256：`83074a51131a480fa55d4816d377706b47c25ab64bad913afeafe04cc733c16c`；大小：1,230,264字节。

## 策略逻辑

在 comm4 上新增 min_trades_for_upgrade，next_phase 的升级同时要求 watcher 交易次数达到门槛，降级不受该次数门槛约束。新增 taker_fillable_cum，以最多五档对手盘估算限价内可成交量，进一步约束主动单数量。函数第一档的有效性与第二至五档的价格边界检查不同，完整函数已导出。与 comm4 比较必须同时检查阶段状态与盘口数量约束，不能只比较配置四阈值。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x4f4c0 | 208 | [strategy_comm4_1::next_phase](../analysis/libstrategy_comm4_1/decompiled_repaired/000000000004f4c0.c) |
| 0x4f130 | 61 | [strategy_comm4_1::Comm4Params::signal_mode](../analysis/libstrategy_comm4_1/decompiled_repaired/000000000004f130.c) |
| 0x4f170 | 266 | [strategy_comm4_1::Comm4Params::signal_trigger_mode](../analysis/libstrategy_comm4_1/decompiled_repaired/000000000004f170.c) |
| 0x4f280 | 573 | [strategy_comm4_1::Comm4Params::effective](../analysis/libstrategy_comm4_1/decompiled_repaired/000000000004f280.c) |
| 0x72b60 | 572 | [strategy_comm4_1::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000072b60.c) |
| 0x739f0 | 554 | [strategy_comm4_1::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_comm4_1/decompiled_repaired/00000000000739f0.c) |
| 0x72fd0 | 264 | [strategy_comm4_1::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000072fd0.c) |
| 0x72ec0 | 264 | [strategy_comm4_1::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000072ec0.c) |
| 0x737a0 | 586 | [strategy_comm4_1::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_comm4_1/decompiled_repaired/00000000000737a0.c) |
| 0x72e30 | 141 | [strategy_comm4_1::signal_trigger::SignalTrigger::point_signal_trigger_pv4](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000072e30.c) |
| 0x730e0 | 1717 | [strategy_comm4_1::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_comm4_1/decompiled_repaired/00000000000730e0.c) |
| 0x72da0 | 137 | [strategy_comm4_1::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000072da0.c) |
| 0x74190 | 152 | [strategy_comm4_1::signal_trigger::dynamic_threshold](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000074190.c) |
| 0x73c20 | 1378 | [_ZN16strategy_comm4_114signal_trigger17enum_rate_counter17h11fb9a90182a0820E.llvm.14061952965871823163](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000073c20.c) |
| 0x72770 | 1001 | [strategy_comm4_1::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000072770.c) |
| 0x50360 | 315 | [strategy_comm4_1::high_taker_rate](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000050360.c) |
| 0x77800 | 658 | [strategy_comm4_1::vol_spread_ratio::VolSpreadRatio::update](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000077800.c) |
| 0x504a0 | 250 | [strategy_comm4_1::taker_fillable_cum](../analysis/libstrategy_comm4_1/decompiled_repaired/00000000000504a0.c) |
| 0x4fdf0 | 1377 | [strategy_comm4_1::live_pending_counts](../analysis/libstrategy_comm4_1/decompiled_repaired/000000000004fdf0.c) |
| 0x4f590 | 2134 | [strategy_comm4_1::cancel_order_use_range](../analysis/libstrategy_comm4_1/decompiled_repaired/000000000004f590.c) |
| 0x55c90 | 27 | [strategy_comm4_1::place](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000055c90.c) |
| 0x505a0 | 738 | [<strategy_comm4_1::StrategyComm41 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_comm4_1/decompiled_repaired/00000000000505a0.c) |
| 0x55990 | 475 | [<strategy_comm4_1::StrategyComm41 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000055990.c) |
| 0x55b70 | 280 | [<strategy_comm4_1::StrategyComm41 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000055b70.c) |
| 0x50890 | 20734 | [<strategy_comm4_1::StrategyComm41 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_comm4_1/decompiled_repaired/0000000000050890.c) |
| 0x6d690 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_comm4_1/decompiled_repaired/000000000006d690.c) |
| 0x6d6a0 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_comm4_1/decompiled_repaired/000000000006d6a0.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：56项

数组文件偏移 `0xe9c30`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `high_taker_half_spread`
12. `taker_mult_max`
13. `taker_cover_k`
14. `taker_skip_half_spread_bp`
15. `trade_slippery`
16. `close_position_block_ms`
17. `touch_gate`
18. `touch_gate_timeout_ms`
19. `max_single_add_vol`
20. `max_single_add_amt`
21. `max_single_net_vol`
22. `max_single_net_amt`
23. `max_single_close_vol`
24. `max_single_close_amt`
25. `long_open_threshold`
26. `long_close_threshold`
27. `short_open_threshold`
28. `short_close_threshold`
29. `low_long_open_threshold`
30. `low_long_close_threshold`
31. `low_short_open_threshold`
32. `low_short_close_threshold`
33. `dyn_score_position_ts_threshold_s`
34. `dyn_score_max_position_ts_s`
35. `dyn_score_delta_score`
36. `use_dynamic_volspread_ratio`
37. `market_volatility_ms`
38. `rolling_windows_ms`
39. `split_high_low_ratio_threshold`
40. `low_action`
41. `maker_order_max_pending_time_ms`
42. `max_maker_pending_vol_on_depth`
43. `maker_ticks_inside`
44. `maker_cancel_range_levels`
45. `enable_phases`
46. `invert_phase`
47. `watcher_strategy_name`
48. `watcher_account_name`
49. `enter_phase2`
50. `exit_phase2`
51. `enter_phase3`
52. `exit_phase3`
53. `min_trades_for_upgrade`
54. `phase1`
55. `phase2`
56. `phase3`

### 字段组2：15项

数组文件偏移 `0xea278`。

1. `long_open_threshold`
2. `long_close_threshold`
3. `short_open_threshold`
4. `short_close_threshold`
5. `max_single_net_vol`
6. `max_single_net_amt`
7. `max_single_add_vol`
8. `max_single_add_amt`
9. `high_taker_half_spread`
10. `taker_mult_max`
11. `taker_cover_k`
12. `taker_skip_half_spread_bp`
13. `taker_rate_baseline`
14. `max_taker_rate`
15. `low_action`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_comm4_1/assembly.txt)、[符号](../analysis/libstrategy_comm4_1/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_comm4_1/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_comm4_1/核心伪代码.c)。
