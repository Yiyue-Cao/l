# libstrategy_tm6.so

SHA-256：`49a117a7d89fb5a1be9dcd9be24493af02da2ea230d1a7c52d7e587f5558b1d4`；大小：1,118,568字节。

## 策略逻辑

在 tm 类信号交易流程中增加与 sm4 对应的 SignalPairsTree、RollingmsQueue，以及 pair_rolling_window_ms、pair_target_holding_period_ms、score_thresholds_delta/num。主回调选择最近配对的中位数阈值，并发布 threshold_long_open/close、threshold_short_open/close；on_depth 提供 rolling_pnl 发布路径。由此可作为消费发布阈值的 sos6 的组件候选，但仅凭接口匹配不能断言本次加密任务配置实际把两者接在一起。 更精确地说，选择的是“配对时长中位数最接近目标持有期的候选阈值”：对每个候选j计算m_j=median(配对时长)，取argmin_j abs(m_j-target)。不是对阈值本身求中位数。时长中位数对偶数样本取中间两项平均，奇数取中间一项；比较使用严格小于，等距时保留遍历中先遇到的候选。无有效候选时有原始阈值回退，空树还有unwrap失败分支。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x54bf0 | 1605 | [strategy_tm6::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_tm6/decompiled_repaired/0000000000054bf0.c) |
| 0x55e00 | 513 | [strategy_tm6::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_tm6/decompiled_repaired/0000000000055e00.c) |
| 0x553e0 | 264 | [strategy_tm6::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_tm6/decompiled_repaired/00000000000553e0.c) |
| 0x552d0 | 264 | [strategy_tm6::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_tm6/decompiled_repaired/00000000000552d0.c) |
| 0x55bc0 | 561 | [strategy_tm6::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_tm6/decompiled_repaired/0000000000055bc0.c) |
| 0x554f0 | 1729 | [strategy_tm6::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_tm6/decompiled_repaired/00000000000554f0.c) |
| 0x55240 | 137 | [strategy_tm6::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_tm6/decompiled_repaired/0000000000055240.c) |
| 0x54aa0 | 326 | [strategy_tm6::signal_trigger::SignalTrigger::new](../analysis/libstrategy_tm6/decompiled_repaired/0000000000054aa0.c) |
| 0x56010 | 1364 | [_ZN12strategy_tm614signal_trigger17enum_rate_counter17h4700a1e9bbed136eE.llvm.9466522774482311751](../analysis/libstrategy_tm6/decompiled_repaired/0000000000056010.c) |
| 0x5e030 | 404 | [_ZN12strategy_tm617signal_pairs_tree15SignalPairStats28get_pairs_time_sec_ms_median17h4a9fe67d7a117850E.llvm.17305594220767975752](../analysis/libstrategy_tm6/decompiled_repaired/000000000005e030.c) |
| 0x5f7d0 | 1553 | [strategy_tm6::signal_pairs_tree::SignalPairsTree::debug_string](../analysis/libstrategy_tm6/decompiled_repaired/000000000005f7d0.c) |
| 0x5f570 | 595 | [strategy_tm6::signal_pairs_tree::SignalPairsTree::find_nearest_pair_median_threshold](../analysis/libstrategy_tm6/decompiled_repaired/000000000005f570.c) |
| 0x5e1d0 | 1656 | [strategy_tm6::signal_pairs_tree::SignalPairsTree::new](../analysis/libstrategy_tm6/decompiled_repaired/000000000005e1d0.c) |
| 0x5e850 | 3354 | [strategy_tm6::signal_pairs_tree::SignalPairsTree::update](../analysis/libstrategy_tm6/decompiled_repaired/000000000005e850.c) |
| 0x5dea0 | 386 | [strategy_tm6::signal_pairs_tree::RollingmsQueue<T>::update](../analysis/libstrategy_tm6/decompiled_repaired/000000000005dea0.c) |
| 0x47d60 | 2110 | [<strategy_tm6::StrategyTM6 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_tm6/decompiled_repaired/0000000000047d60.c) |
| 0x4aa90 | 708 | [<strategy_tm6::StrategyTM6 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_tm6/decompiled_repaired/000000000004aa90.c) |
| 0x4ad60 | 280 | [<strategy_tm6::StrategyTM6 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_tm6/decompiled_repaired/000000000004ad60.c) |
| 0x485a0 | 9443 | [<strategy_tm6::StrategyTM6 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_tm6/decompiled_repaired/00000000000485a0.c) |
| 0x61820 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_tm6/decompiled_repaired/0000000000061820.c) |
| 0x61830 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_tm6/decompiled_repaired/0000000000061830.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：34项

数组文件偏移 `0xd13f0`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `trade_slippery`
12. `close_position_block_ms`
13. `max_single_add_vol`
14. `max_single_add_amt`
15. `max_single_net_vol`
16. `max_single_net_amt`
17. `max_single_close_vol`
18. `max_single_close_amt`
19. `long_open_threshold`
20. `long_close_threshold`
21. `short_open_threshold`
22. `short_close_threshold`
23. `dyn_score_position_ts_threshold_s`
24. `dyn_score_max_position_ts_s`
25. `dyn_score_delta_score`
26. `dyn_pending_position_ts_threshold_s`
27. `dyn_pending_max_position_ts_s`
28. `dyn_pending_order_max_pending_time_ms`
29. `dyn_pending_delta_max_pending_ts_ms`
30. `pair_rolling_window_ms`
31. `pair_target_holding_period_ms`
32. `score_thresholds_delta`
33. `score_thresholds_num`
34. `rolling_window_ms`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_tm6/assembly.txt)、[符号](../analysis/libstrategy_tm6/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_tm6/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_tm6/核心伪代码.c)。
