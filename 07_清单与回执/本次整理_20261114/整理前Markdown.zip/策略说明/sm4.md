# libstrategy_sm4.so

SHA-256：`4502ae763732f8da98f4e45b8585024b66c72a1aa1c5728b495583c7ceffbd44`；大小：1,193,512字节。

## 策略逻辑

在 sm1 报价/盘口量限制基础上引入 SignalPairsTree。pair_rolling_window_ms 控制样本存续，pair_target_holding_period_ms 指定目标配对间隔，score_thresholds_delta/num 构造候选阈值网格。树的 new/update/find_nearest_pair_median_threshold 与 RollingmsQueue::update 构成滚动配对与阈值选择模块，选出的阈值随后进入报价流程。该模块是在线状态依赖；不能把每个tick独立重算且忽略队列顺序。具体计数、中位数和最近目标边界见函数伪代码与汇编，不应仅凭名称将其解释为经过收益最大化训练的阈值。 更精确地说，选择的是“配对时长中位数最接近目标持有期的候选阈值”：对每个候选j计算m_j=median(配对时长)，取argmin_j abs(m_j-target)。不是对阈值本身求中位数。时长中位数对偶数样本取中间两项平均，奇数取中间一项；比较使用严格小于，等距时保留遍历中先遇到的候选。无有效候选时有原始阈值回退，空树还有unwrap失败分支。 apply_book_vol_cap按执行类型分流：主动分支累加最多五档限价内对手量，并可施加max_single_taker_vol；被动分支用本方前三档有效挂量的平均值并可施加max_maker_pending_vol_on_depth。book_vol_cap是否启用影响盘口约束，不能假设每个配置都会开启。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x3ec90 | 922 | [strategy_sm4::cancel_side](../analysis/libstrategy_sm4/decompiled_repaired/000000000003ec90.c) |
| 0x3ebc0 | 87 | [strategy_sm4::default_pv1](../analysis/libstrategy_sm4/decompiled_repaired/000000000003ebc0.c) |
| 0x63b60 | 404 | [_ZN12strategy_sm417signal_pairs_tree15SignalPairStats28get_pairs_time_sec_ms_median17hd03f3837d95f7339E.llvm.4719369549894925764](../analysis/libstrategy_sm4/decompiled_repaired/0000000000063b60.c) |
| 0x65300 | 1553 | [strategy_sm4::signal_pairs_tree::SignalPairsTree::debug_string](../analysis/libstrategy_sm4/decompiled_repaired/0000000000065300.c) |
| 0x650a0 | 595 | [strategy_sm4::signal_pairs_tree::SignalPairsTree::find_nearest_pair_median_threshold](../analysis/libstrategy_sm4/decompiled_repaired/00000000000650a0.c) |
| 0x63d00 | 1656 | [strategy_sm4::signal_pairs_tree::SignalPairsTree::new](../analysis/libstrategy_sm4/decompiled_repaired/0000000000063d00.c) |
| 0x64380 | 3354 | [strategy_sm4::signal_pairs_tree::SignalPairsTree::update](../analysis/libstrategy_sm4/decompiled_repaired/0000000000064380.c) |
| 0x639d0 | 386 | [strategy_sm4::signal_pairs_tree::RollingmsQueue<T>::update](../analysis/libstrategy_sm4/decompiled_repaired/00000000000639d0.c) |
| 0x3fa10 | 720 | [strategy_sm4::apply_book_vol_cap](../analysis/libstrategy_sm4/decompiled_repaired/000000000003fa10.c) |
| 0x3f4a0 | 1377 | [strategy_sm4::live_pending_counts](../analysis/libstrategy_sm4/decompiled_repaired/000000000003f4a0.c) |
| 0x3ec20 | 98 | [strategy_sm4::default_point_trigger](../analysis/libstrategy_sm4/decompiled_repaired/000000000003ec20.c) |
| 0x3f030 | 1121 | [strategy_sm4::cancel_order_use_range](../analysis/libstrategy_sm4/decompiled_repaired/000000000003f030.c) |
| 0x91850 | 588 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_sm4/decompiled_repaired/0000000000091850.c) |
| 0x92680 | 555 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_sm4/decompiled_repaired/0000000000092680.c) |
| 0x91c70 | 265 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_sm4/decompiled_repaired/0000000000091c70.c) |
| 0x91b60 | 265 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_sm4/decompiled_repaired/0000000000091b60.c) |
| 0x92430 | 587 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_sm4/decompiled_repaired/0000000000092430.c) |
| 0x91d80 | 1702 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_sm4/decompiled_repaired/0000000000091d80.c) |
| 0x91aa0 | 178 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::point_signal_trigger_pv3_spread](../analysis/libstrategy_sm4/decompiled_repaired/0000000000091aa0.c) |
| 0x91780 | 199 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::new](../analysis/libstrategy_sm4/decompiled_repaired/0000000000091780.c) |
| 0x92e30 | 152 | [strategy_signal_maker_common::signal_trigger::dynamic_threshold](../analysis/libstrategy_sm4/decompiled_repaired/0000000000092e30.c) |
| 0x928b0 | 1394 | [strategy_signal_maker_common::signal_trigger::enum_rate_counter](../analysis/libstrategy_sm4/decompiled_repaired/00000000000928b0.c) |
| 0x91520 | 598 | [strategy_signal_maker_common::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_sm4/decompiled_repaired/0000000000091520.c) |
| 0x92ed0 | 63 | [strategy_signal_maker_common::signal_trigger::dynamic_pending_ts_ms](../analysis/libstrategy_sm4/decompiled_repaired/0000000000092ed0.c) |
| 0x8f910 | 135 | [strategy_signal_maker_common::get_quote_price::get_quote_vol](../analysis/libstrategy_sm4/decompiled_repaired/000000000008f910.c) |
| 0x8f9a0 | 1978 | [strategy_signal_maker_common::get_quote_price::get_quote_price](../analysis/libstrategy_sm4/decompiled_repaired/000000000008f9a0.c) |
| 0x3fce0 | 2161 | [<strategy_sm4::StrategySM4 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_sm4/decompiled_repaired/000000000003fce0.c) |
| 0x40560 | 11554 | [<strategy_sm4::StrategySM4 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_sm4/decompiled_repaired/0000000000040560.c) |
| 0x686f0 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_sm4/decompiled_repaired/00000000000686f0.c) |
| 0x68700 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_sm4/decompiled_repaired/0000000000068700.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：39项

数组文件偏移 `0xdf488`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `taker_rate_baseline`
9. `max_taker_rate`
10. `trade_slippery`
11. `close_position_block_ms`
12. `max_single_add_vol`
13. `max_single_add_amt`
14. `max_single_net_vol`
15. `max_single_net_amt`
16. `max_single_close_vol`
17. `max_single_close_amt`
18. `long_open_threshold`
19. `long_close_threshold`
20. `short_open_threshold`
21. `short_close_threshold`
22. `dyn_score_position_ts_threshold_s`
23. `dyn_score_max_position_ts_s`
24. `dyn_score_delta_score`
25. `dyn_pending_position_ts_threshold_s`
26. `dyn_pending_max_position_ts_s`
27. `dyn_pending_delta_max_pending_ts_ms`
28. `order_max_pending_time_ms`
29. `max_maker_pending_vol_on_depth`
30. `max_maker_limit_rate_bias_from_mid`
31. `pair_rolling_window_ms`
32. `pair_target_holding_period_ms`
33. `score_thresholds_delta`
34. `score_thresholds_num`
35. `signal_all`
36. `touch_gate`
37. `touch_gate_timeout_ms`
38. `book_vol_cap`
39. `max_single_taker_vol`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_sm4/assembly.txt)、[符号](../analysis/libstrategy_sm4/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_sm4/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_sm4/核心伪代码.c)。
