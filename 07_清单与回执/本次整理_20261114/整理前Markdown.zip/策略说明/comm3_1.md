# libstrategy_comm3_1.so

SHA-256：`a42e121da5e3710bfb3d6026a57c45db830a75fb292a5bbb14b5ba99a16de5f4`；大小：1,141,456字节。

## 策略逻辑

保留 comm3 的 LOW/HIGH 分组与 maker 路径，新增 high_taker_half_spread、taker_mult_max、taker_cover_k 和 high_taker_rate。该函数以半价差比例为基准，用信号超过动作阈值的程度调节主动单覆盖幅度：excess=max(abs(score)/abs(threshold)-1,0)，mult=1+(mult_max-1)*tanh(excess/2)，cover=(abs(score)-abs(threshold))*cover_k/half_spread_bp，正常分支 rate=half_spread_ratio*max(min(cover,mult),0)。非正价格和、非正半价差、过小阈值及 mult_max<=1 有单独回退分支。它不是简单固定多打若干 tick。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x38e50 | 61 | [strategy_comm3_1::Comm3Params::signal_mode](../analysis/libstrategy_comm3_1/decompiled_repaired/0000000000038e50.c) |
| 0x38fa0 | 47 | [strategy_comm3_1::Comm3Params::low_action_enum](../analysis/libstrategy_comm3_1/decompiled_repaired/0000000000038fa0.c) |
| 0x38e90 | 266 | [strategy_comm3_1::Comm3Params::signal_trigger_mode](../analysis/libstrategy_comm3_1/decompiled_repaired/0000000000038e90.c) |
| 0x5bfc0 | 572 | [strategy_comm3_1::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005bfc0.c) |
| 0x5cd90 | 554 | [strategy_comm3_1::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005cd90.c) |
| 0x5c3d0 | 167 | [strategy_comm3_1::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c3d0.c) |
| 0x5c320 | 167 | [strategy_comm3_1::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c320.c) |
| 0x5cb40 | 586 | [strategy_comm3_1::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005cb40.c) |
| 0x5c290 | 141 | [strategy_comm3_1::signal_trigger::SignalTrigger::point_signal_trigger_pv4](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c290.c) |
| 0x5c480 | 1717 | [strategy_comm3_1::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c480.c) |
| 0x5c200 | 137 | [strategy_comm3_1::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c200.c) |
| 0x5d530 | 152 | [strategy_comm3_1::signal_trigger::dynamic_threshold](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005d530.c) |
| 0x5cfc0 | 1378 | [_ZN16strategy_comm3_114signal_trigger17enum_rate_counter17hb2b1659f9016b723E.llvm.12839419423354967770](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005cfc0.c) |
| 0x5bbd0 | 1001 | [strategy_comm3_1::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005bbd0.c) |
| 0x39da0 | 296 | [strategy_comm3_1::high_taker_rate](../analysis/libstrategy_comm3_1/decompiled_repaired/0000000000039da0.c) |
| 0x5ec30 | 658 | [strategy_comm3_1::vol_spread_ratio::VolSpreadRatio::update](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000005ec30.c) |
| 0x39830 | 1377 | [strategy_comm3_1::live_pending_counts](../analysis/libstrategy_comm3_1/decompiled_repaired/0000000000039830.c) |
| 0x38fd0 | 2134 | [strategy_comm3_1::cancel_order_use_range](../analysis/libstrategy_comm3_1/decompiled_repaired/0000000000038fd0.c) |
| 0x3da20 | 27 | [strategy_comm3_1::place](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000003da20.c) |
| 0x39ed0 | 840 | [<strategy_comm3_1::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_comm3_1/decompiled_repaired/0000000000039ed0.c) |
| 0x3d720 | 475 | [<strategy_comm3_1::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000003d720.c) |
| 0x3d900 | 280 | [<strategy_comm3_1::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000003d900.c) |
| 0x3a220 | 13560 | [<strategy_comm3_1::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_comm3_1/decompiled_repaired/000000000003a220.c) |
| 0x62fc0 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_comm3_1/decompiled_repaired/0000000000062fc0.c) |
| 0x62fd0 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_comm3_1/decompiled_repaired/0000000000062fd0.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：43项

数组文件偏移 `0xd6240`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `high_taker_half_spread`
12. `taker_mult_max`
13. `taker_cover_k`
14. `trade_slippery`
15. `close_position_block_ms`
16. `touch_gate`
17. `touch_gate_timeout_ms`
18. `max_single_add_vol`
19. `max_single_add_amt`
20. `max_single_net_vol`
21. `max_single_net_amt`
22. `max_single_close_vol`
23. `max_single_close_amt`
24. `long_open_threshold`
25. `long_close_threshold`
26. `short_open_threshold`
27. `short_close_threshold`
28. `low_long_open_threshold`
29. `low_long_close_threshold`
30. `low_short_open_threshold`
31. `low_short_close_threshold`
32. `dyn_score_position_ts_threshold_s`
33. `dyn_score_max_position_ts_s`
34. `dyn_score_delta_score`
35. `use_dynamic_volspread_ratio`
36. `market_volatility_ms`
37. `rolling_windows_ms`
38. `split_high_low_ratio_threshold`
39. `low_action`
40. `maker_order_max_pending_time_ms`
41. `max_maker_pending_vol_on_depth`
42. `maker_ticks_inside`
43. `maker_cancel_range_levels`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_comm3_1/assembly.txt)、[符号](../analysis/libstrategy_comm3_1/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_comm3_1/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_comm3_1/核心伪代码.c)。
