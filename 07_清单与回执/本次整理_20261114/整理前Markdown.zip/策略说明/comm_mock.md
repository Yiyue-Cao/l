# libstrategy_comm_mock.so

SHA-256：`31084cd688c5938de4b978ead4580bd3b82fe014d699850dead0036e7b1d8c15`；大小：1,151,176字节。

## 策略逻辑

参数表与 comm3_2 一致，但事件状态明显不同：除了 on_signal，on_order 与 on_depth 也有实质业务逻辑。on_order 根据订单回报维护内部交易/收益状态；on_depth 结合 position、contract_mult、mid_price，发布 pnl_rel、pnl_unrel、pnl、amt、pos、price 等观测值，供 watcher 型策略读取。place 存在显式 IOC 分支，其余分支为带 target 或普通 IAP。它是带观察/发布职责的交易策略版本，不能凭 mock 名字认定为空实现，也不能在未接 SDK 的情况下把发布值直接当作账户最终净收益。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x391f0 | 61 | [strategy_comm_mock::Comm3Params::signal_mode](../analysis/libstrategy_comm_mock/decompiled_repaired/00000000000391f0.c) |
| 0x39340 | 47 | [strategy_comm_mock::Comm3Params::low_action_enum](../analysis/libstrategy_comm_mock/decompiled_repaired/0000000000039340.c) |
| 0x39230 | 266 | [strategy_comm_mock::Comm3Params::signal_trigger_mode](../analysis/libstrategy_comm_mock/decompiled_repaired/0000000000039230.c) |
| 0x5e470 | 572 | [strategy_comm_mock::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005e470.c) |
| 0x5f300 | 554 | [strategy_comm_mock::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005f300.c) |
| 0x5e8e0 | 264 | [strategy_comm_mock::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005e8e0.c) |
| 0x5e7d0 | 264 | [strategy_comm_mock::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005e7d0.c) |
| 0x5f0b0 | 586 | [strategy_comm_mock::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005f0b0.c) |
| 0x5e740 | 141 | [strategy_comm_mock::signal_trigger::SignalTrigger::point_signal_trigger_pv4](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005e740.c) |
| 0x5e9f0 | 1717 | [strategy_comm_mock::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005e9f0.c) |
| 0x5e6b0 | 137 | [strategy_comm_mock::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005e6b0.c) |
| 0x5faa0 | 152 | [strategy_comm_mock::signal_trigger::dynamic_threshold](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005faa0.c) |
| 0x5f530 | 1378 | [_ZN18strategy_comm_mock14signal_trigger17enum_rate_counter17h8b1360ee3ad6c1afE.llvm.9348514807243868232](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005f530.c) |
| 0x5e080 | 1001 | [strategy_comm_mock::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005e080.c) |
| 0x3a140 | 315 | [strategy_comm_mock::high_taker_rate](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000003a140.c) |
| 0x5b020 | 658 | [strategy_comm_mock::vol_spread_ratio::VolSpreadRatio::update](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005b020.c) |
| 0x39bd0 | 1377 | [strategy_comm_mock::live_pending_counts](../analysis/libstrategy_comm_mock/decompiled_repaired/0000000000039bd0.c) |
| 0x39370 | 2134 | [strategy_comm_mock::cancel_order_use_range](../analysis/libstrategy_comm_mock/decompiled_repaired/0000000000039370.c) |
| 0x3f360 | 37 | [strategy_comm_mock::place](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000003f360.c) |
| 0x3a280 | 840 | [<strategy_comm_mock::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000003a280.c) |
| 0x3e120 | 4375 | [<strategy_comm_mock::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000003e120.c) |
| 0x3d8d0 | 2114 | [<strategy_comm_mock::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_order](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000003d8d0.c) |
| 0x3f240 | 280 | [<strategy_comm_mock::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000003f240.c) |
| 0x3a5d0 | 13053 | [<strategy_comm_mock::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000003a5d0.c) |
| 0x5c4b0 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005c4b0.c) |
| 0x5c4c0 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_comm_mock/decompiled_repaired/000000000005c4c0.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：44项

数组文件偏移 `0xd8338`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `high_taker_half_spread`
12. `taker_mult_max`
13. `taker_cover_k`
14. `taker_skip_half_spread_bp`
15. `trade_slippery`
16. `close_position_block_ms`
17. `max_single_add_vol`
18. `max_single_add_amt`
19. `max_single_net_vol`
20. `max_single_net_amt`
21. `max_single_close_vol`
22. `max_single_close_amt`
23. `long_open_threshold`
24. `long_close_threshold`
25. `short_open_threshold`
26. `short_close_threshold`
27. `low_long_open_threshold`
28. `low_long_close_threshold`
29. `low_short_open_threshold`
30. `low_short_close_threshold`
31. `dyn_score_position_ts_threshold_s`
32. `dyn_score_max_position_ts_s`
33. `dyn_score_delta_score`
34. `use_dynamic_volspread_ratio`
35. `market_volatility_ms`
36. `rolling_windows_ms`
37. `publish_window_ms`
38. `use_ioc`
39. `split_high_low_ratio_threshold`
40. `low_action`
41. `maker_order_max_pending_time_ms`
42. `max_maker_pending_vol_on_depth`
43. `maker_ticks_inside`
44. `maker_cancel_range_levels`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_comm_mock/assembly.txt)、[符号](../analysis/libstrategy_comm_mock/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_comm_mock/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_comm_mock/核心伪代码.c)。
