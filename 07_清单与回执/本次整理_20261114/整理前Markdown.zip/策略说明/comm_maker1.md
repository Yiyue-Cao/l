# libstrategy_comm_maker1.so

SHA-256：`465184d5fbf8af1a34568fe9b708305ac1ec0cc63480774c055b6b7e4ba8e4b9`；大小：1,139,424字节。

## 策略逻辑

保留 comm 的 PV/窗口/波动价差机制，但将双侧目标量和报价决策分离：compute_target_vol_buy/sell 分别计算买卖需求；decide_quote 调用 get_quote_price 或走指定 maker 路径；cancel_side、cancel_order_use_range、live_pending_counts 管理旧单与新单互斥。get_quote_price 对四种开平动作分别计算信号相对阈值的剩余空间，将其与半价差比较，选择主动价或被动价；主动覆盖幅度受上下界约束。decide_quote 对被动报价再施加与最优价和 maker_ticks_inside 相关的约束，并按价格步长取整。因此不能把文件名 maker 理解为所有返回分支都必定被动成交。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x475c0 | 840 | [<strategy_comm_maker1::StrategyCommMaker1 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_comm_maker1/decompiled_repaired/00000000000475c0.c) |
| 0x49dc0 | 598 | [<strategy_comm_maker1::StrategyCommMaker1 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000049dc0.c) |
| 0x4a020 | 280 | [<strategy_comm_maker1::StrategyCommMaker1 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_comm_maker1/decompiled_repaired/000000000004a020.c) |
| 0x47910 | 9382 | [<strategy_comm_maker1::StrategyCommMaker1 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000047910.c) |
| 0x46840 | 922 | [strategy_comm_maker1::cancel_side](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000046840.c) |
| 0x4a600 | 524 | [strategy_comm_maker1::decide_quote](../analysis/libstrategy_comm_maker1/decompiled_repaired/000000000004a600.c) |
| 0x60f80 | 572 | [strategy_comm_maker1::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000060f80.c) |
| 0x61e40 | 554 | [strategy_comm_maker1::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000061e40.c) |
| 0x61420 | 259 | [strategy_comm_maker1::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000061420.c) |
| 0x61310 | 259 | [strategy_comm_maker1::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000061310.c) |
| 0x61bf0 | 586 | [strategy_comm_maker1::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000061bf0.c) |
| 0x61530 | 1717 | [strategy_comm_maker1::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000061530.c) |
| 0x61250 | 182 | [strategy_comm_maker1::signal_trigger::SignalTrigger::point_signal_trigger_pv4_band](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000061250.c) |
| 0x611c0 | 137 | [strategy_comm_maker1::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_comm_maker1/decompiled_repaired/00000000000611c0.c) |
| 0x625e0 | 152 | [strategy_comm_maker1::signal_trigger::dynamic_threshold](../analysis/libstrategy_comm_maker1/decompiled_repaired/00000000000625e0.c) |
| 0x62070 | 1378 | [_ZN20strategy_comm_maker114signal_trigger17enum_rate_counter17h7893d28320393014E.llvm.3918936404547024942](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000062070.c) |
| 0x60b90 | 1001 | [strategy_comm_maker1::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000060b90.c) |
| 0x5e990 | 1978 | [strategy_comm_maker1::get_quote_price::get_quote_price](../analysis/libstrategy_comm_maker1/decompiled_repaired/000000000005e990.c) |
| 0x466c0 | 61 | [strategy_comm_maker1::CommMaker1Params::signal_mode](../analysis/libstrategy_comm_maker1/decompiled_repaired/00000000000466c0.c) |
| 0x46810 | 47 | [strategy_comm_maker1::CommMaker1Params::low_action_enum](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000046810.c) |
| 0x46700 | 266 | [strategy_comm_maker1::CommMaker1Params::signal_trigger_mode](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000046700.c) |
| 0x5e6f0 | 658 | [strategy_comm_maker1::vol_spread_ratio::VolSpreadRatio::update](../analysis/libstrategy_comm_maker1/decompiled_repaired/000000000005e6f0.c) |
| 0x47050 | 1377 | [strategy_comm_maker1::live_pending_counts](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000047050.c) |
| 0x46be0 | 1121 | [strategy_comm_maker1::cancel_order_use_range](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000046be0.c) |
| 0x4a140 | 588 | [strategy_comm_maker1::compute_target_vol_buy](../analysis/libstrategy_comm_maker1/decompiled_repaired/000000000004a140.c) |
| 0x4a390 | 617 | [strategy_comm_maker1::compute_target_vol_sell](../analysis/libstrategy_comm_maker1/decompiled_repaired/000000000004a390.c) |
| 0x4a810 | 27 | [strategy_comm_maker1::place](../analysis/libstrategy_comm_maker1/decompiled_repaired/000000000004a810.c) |
| 0x58950 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000058950.c) |
| 0x58960 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_comm_maker1/decompiled_repaired/0000000000058960.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：40项

数组文件偏移 `0xd54e0`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `trade_slippery`
12. `close_position_block_ms`
13. `max_single_add_vol`
14. `max_single_add_amt`
15. `max_single_net_vol`
16. `max_single_net_amt`
17. `max_single_close_vol`
18. `max_single_close_amt`
19. `long_open_threshold`
20. `long_close_threshold`
21. `short_open_threshold`
22. `short_close_threshold`
23. `low_long_open_threshold`
24. `low_long_close_threshold`
25. `low_short_open_threshold`
26. `low_short_close_threshold`
27. `dyn_score_position_ts_threshold_s`
28. `dyn_score_max_position_ts_s`
29. `dyn_score_delta_score`
30. `use_dynamic_volspread_ratio`
31. `market_volatility_ms`
32. `rolling_windows_ms`
33. `split_high_low_ratio_threshold`
34. `max_maker_limit_rate_bias_from_mid`
35. `order_max_pending_time_ms`
36. `maker_alpha_imb_delta`
37. `maker_vol_depth_window_ms`
38. `maker_ticks_inside`
39. `maker_cancel_range_levels`
40. `low_action`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_comm_maker1/assembly.txt)、[符号](../analysis/libstrategy_comm_maker1/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_comm_maker1/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_comm_maker1/核心伪代码.c)。
