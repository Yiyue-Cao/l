# libstrategy_sos5.so

SHA-256：`567ba8f4e88b5e260159311eb31f119455ef8e4215bdb07a5c08186198fb08ac`；大小：1,164,592字节。

## 策略逻辑

三 section 的策略编排版本。每段 SectionParams 可配置 insts/ranks、signal_all、trade_mode、四阈值、增仓与净仓限制及 trade_code；watcher 的发布收益触发段间切换。phase_thresholds 支持 fixed_rmb 和 live_basket_bp 两种阈值口径，后者要求正 reference notional、正 phase_threshold_bp、phase_high_multiplier>1；基础人民币阈值与篮子名义金额和bp比例有关。phase_basket_notional 从可用品种报价形成参考规模，phase_mid_jump_reject_rate、phase_max_spread_bp 过滤异常报价，phase_default_reference_notional 提供配置后备值。另有 order_book_1_2_gap、sos_taker_rate、sos_add_vol 和 place_order_by_mode。 live_basket_bp以B=reference_notional*phase_threshold_bp/10000生成五个转换门槛，按字段顺序为(B,h*B,-B,h*B,B)，h为phase_high_multiplier；fixed_rmb直接采用配置的五个值，代码也接受fixed别名。place_order_by_mode明确识别字符串IOC和IAP，其他值回退到SDK全局模式，而不是无条件拒绝。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x49050 | 1830 | [strategy_sos5::SoS5Params::phase_thresholds](../analysis/libstrategy_sos5/decompiled_repaired/0000000000049050.c) |
| 0x49780 | 266 | [strategy_sos5::SoS5Params::signal_trigger_mode](../analysis/libstrategy_sos5/decompiled_repaired/0000000000049780.c) |
| 0x6a5e0 | 1845 | [strategy_sos5::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_sos5/decompiled_repaired/000000000006a5e0.c) |
| 0x6b8e0 | 554 | [strategy_sos5::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_sos5/decompiled_repaired/000000000006b8e0.c) |
| 0x6aec0 | 264 | [strategy_sos5::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_sos5/decompiled_repaired/000000000006aec0.c) |
| 0x6adb0 | 264 | [strategy_sos5::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_sos5/decompiled_repaired/000000000006adb0.c) |
| 0x6b690 | 586 | [strategy_sos5::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_sos5/decompiled_repaired/000000000006b690.c) |
| 0x6afd0 | 1717 | [strategy_sos5::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_sos5/decompiled_repaired/000000000006afd0.c) |
| 0x6ad20 | 137 | [strategy_sos5::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_sos5/decompiled_repaired/000000000006ad20.c) |
| 0x6c080 | 152 | [strategy_sos5::signal_trigger::dynamic_threshold](../analysis/libstrategy_sos5/decompiled_repaired/000000000006c080.c) |
| 0x6bb10 | 1378 | [_ZN13strategy_sos514signal_trigger17enum_rate_counter17h52e1c88565e9250aE.llvm.14864376446662127556](../analysis/libstrategy_sos5/decompiled_repaired/000000000006bb10.c) |
| 0x48f80 | 98 | [strategy_sos5::default_watcher_key](../analysis/libstrategy_sos5/decompiled_repaired/0000000000048f80.c) |
| 0x4e940 | 338 | [strategy_sos5::place_order_by_mode](../analysis/libstrategy_sos5/decompiled_repaired/000000000004e940.c) |
| 0x4e6a0 | 662 | [strategy_sos5::phase_basket_notional](../analysis/libstrategy_sos5/decompiled_repaired/000000000004e6a0.c) |
| 0x48ff0 | 95 | [strategy_sos5::default_phase_threshold_mode](../analysis/libstrategy_sos5/decompiled_repaired/0000000000048ff0.c) |
| 0x49890 | 2396 | [<strategy_sos5::StrategySoS5 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_sos5/decompiled_repaired/0000000000049890.c) |
| 0x4dba0 | 2102 | [<strategy_sos5::StrategySoS5 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_sos5/decompiled_repaired/000000000004dba0.c) |
| 0x4e3e0 | 697 | [<strategy_sos5::StrategySoS5 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_sos5/decompiled_repaired/000000000004e3e0.c) |
| 0x4a1f0 | 14764 | [<strategy_sos5::StrategySoS5 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_sos5/decompiled_repaired/000000000004a1f0.c) |
| 0x69a10 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_sos5/decompiled_repaired/0000000000069a10.c) |
| 0x69a20 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_sos5/decompiled_repaired/0000000000069a20.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：41项

数组文件偏移 `0xdbab8`。

1. `watcher_strategy_name`
2. `watcher_account_name`
3. `watcher_key`
4. `section1_to_2_pnl`
5. `section1_to_3_pnl`
6. `section2_to_1_pnl`
7. `section2_to_3_pnl`
8. `section3_to_1_pnl`
9. `phase_threshold_mode`
10. `phase_threshold_bp`
11. `phase_high_multiplier`
12. `phase_default_reference_notional`
13. `phase_mid_jump_reject_rate`
14. `phase_max_spread_bp`
15. `order_book_1_2_gap`
16. `sos_taker_rate`
17. `sos_add_vol`
18. `section1`
19. `section2`
20. `section3`
21. `signal_mode`
22. `pv1_alpha`
23. `cost_alpha`
24. `signal_trigger_mode`
25. `vote_rate`
26. `quantile`
27. `signal_windows_s`
28. `score_taker_rate_alpha`
29. `taker_rate_baseline`
30. `max_taker_rate`
31. `trade_slippery`
32. `close_position_block_ms`
33. `max_single_close_vol`
34. `max_single_close_amt`
35. `dyn_score_position_ts_threshold_s`
36. `dyn_score_max_position_ts_s`
37. `dyn_score_delta_score`
38. `dyn_pending_position_ts_threshold_s`
39. `dyn_pending_max_position_ts_s`
40. `dyn_pending_order_max_pending_time_ms`
41. `dyn_pending_delta_max_pending_ts_ms`

### 字段组2：13项

数组文件偏移 `0xdc2e8`。

1. `insts`
2. `ranks`
3. `signal_all`
4. `trade_mode`
5. `long_open_threshold`
6. `long_close_threshold`
7. `short_open_threshold`
8. `short_close_threshold`
9. `max_single_add_vol`
10. `max_single_net_vol`
11. `max_single_add_amt`
12. `max_single_net_amt`
13. `trade_code`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_sos5/assembly.txt)、[符号](../analysis/libstrategy_sos5/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_sos5/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_sos5/核心伪代码.c)。
