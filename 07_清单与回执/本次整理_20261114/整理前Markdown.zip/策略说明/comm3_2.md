# libstrategy_comm3_2.so

SHA-256：`f9bc9b095a9c37be884662abab55be5098ef6298ae69e3ff8cfa0222d6bab8c9`；大小：1,141,224字节。

## 策略逻辑

在 comm3_1 的 high_taker_rate 上加入 taker_skip_half_spread_bp。函数先检查半价差是否超过正的限制值，超过时返回调用者给定的回退值，再进入原来的 tanh 覆盖计算；因此该参数的具体跳过效果须结合主回调使用返回值的方式，不能仅看参数名理解为全策略停机。其余配置字段与 comm3_1 相比只多这一项。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x38d80 | 61 | [strategy_comm3_2::Comm3Params::signal_mode](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000038d80.c) |
| 0x38ed0 | 47 | [strategy_comm3_2::Comm3Params::low_action_enum](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000038ed0.c) |
| 0x38dc0 | 266 | [strategy_comm3_2::Comm3Params::signal_trigger_mode](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000038dc0.c) |
| 0x62d80 | 572 | [strategy_comm3_2::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000062d80.c) |
| 0x63b50 | 554 | [strategy_comm3_2::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000063b50.c) |
| 0x63190 | 167 | [strategy_comm3_2::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000063190.c) |
| 0x630e0 | 167 | [strategy_comm3_2::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_comm3_2/decompiled_repaired/00000000000630e0.c) |
| 0x63900 | 586 | [strategy_comm3_2::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000063900.c) |
| 0x63050 | 141 | [strategy_comm3_2::signal_trigger::SignalTrigger::point_signal_trigger_pv4](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000063050.c) |
| 0x63240 | 1717 | [strategy_comm3_2::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000063240.c) |
| 0x62fc0 | 137 | [strategy_comm3_2::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000062fc0.c) |
| 0x642f0 | 152 | [strategy_comm3_2::signal_trigger::dynamic_threshold](../analysis/libstrategy_comm3_2/decompiled_repaired/00000000000642f0.c) |
| 0x63d80 | 1378 | [_ZN16strategy_comm3_214signal_trigger17enum_rate_counter17h6c3412650fa35c6eE.llvm.17298346514359621430](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000063d80.c) |
| 0x62990 | 1001 | [strategy_comm3_2::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000062990.c) |
| 0x39cd0 | 315 | [strategy_comm3_2::high_taker_rate](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000039cd0.c) |
| 0x5d4e0 | 658 | [strategy_comm3_2::vol_spread_ratio::VolSpreadRatio::update](../analysis/libstrategy_comm3_2/decompiled_repaired/000000000005d4e0.c) |
| 0x39760 | 1377 | [strategy_comm3_2::live_pending_counts](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000039760.c) |
| 0x38f00 | 2134 | [strategy_comm3_2::cancel_order_use_range](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000038f00.c) |
| 0x3d9f0 | 27 | [strategy_comm3_2::place](../analysis/libstrategy_comm3_2/decompiled_repaired/000000000003d9f0.c) |
| 0x39e10 | 840 | [<strategy_comm3_2::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000039e10.c) |
| 0x3d6f0 | 475 | [<strategy_comm3_2::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_comm3_2/decompiled_repaired/000000000003d6f0.c) |
| 0x3d8d0 | 280 | [<strategy_comm3_2::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_comm3_2/decompiled_repaired/000000000003d8d0.c) |
| 0x3a160 | 13700 | [<strategy_comm3_2::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_comm3_2/decompiled_repaired/000000000003a160.c) |
| 0x60e70 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000060e70.c) |
| 0x60e80 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_comm3_2/decompiled_repaired/0000000000060e80.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：44项

数组文件偏移 `0xd6510`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `high_taker_half_spread`
12. `taker_mult_max`
13. `taker_cover_k`
14. `taker_skip_half_spread_bp`
15. `trade_slippery`
16. `close_position_block_ms`
17. `touch_gate`
18. `touch_gate_timeout_ms`
19. `max_single_add_vol`
20. `max_single_add_amt`
21. `max_single_net_vol`
22. `max_single_net_amt`
23. `max_single_close_vol`
24. `max_single_close_amt`
25. `long_open_threshold`
26. `long_close_threshold`
27. `short_open_threshold`
28. `short_close_threshold`
29. `low_long_open_threshold`
30. `low_long_close_threshold`
31. `low_short_open_threshold`
32. `low_short_close_threshold`
33. `dyn_score_position_ts_threshold_s`
34. `dyn_score_max_position_ts_s`
35. `dyn_score_delta_score`
36. `use_dynamic_volspread_ratio`
37. `market_volatility_ms`
38. `rolling_windows_ms`
39. `split_high_low_ratio_threshold`
40. `low_action`
41. `maker_order_max_pending_time_ms`
42. `max_maker_pending_vol_on_depth`
43. `maker_ticks_inside`
44. `maker_cancel_range_levels`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_comm3_2/assembly.txt)、[符号](../analysis/libstrategy_comm3_2/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_comm3_2/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_comm3_2/核心伪代码.c)。
