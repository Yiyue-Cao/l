# libstrategy_comm3.so

SHA-256：`a664823a3b46d413cf06dd8766e10c457c7a78f581f8259cf7d3a2ebb6c25ac2`；大小：1,135,664字节。

## 策略逻辑

在 comm2 的外部信号触发框架上，加入低波动/价差组的独立四阈值、low_action 及被动挂单。low_action_enum 区分 skip/maker/通常执行；skip 的作用对象应以主回调动作分支为准，不等于关闭整个策略。cancel_order_use_range 先处理反向订单，再处理超出报价保留范围的同向订单，记录已请求撤单 ID；live_pending_counts 计数时排除这些 ID，避免把已撤请求当作有效挂单。maker 受 maker_ticks_inside、maker_cancel_range_levels、maker_order_max_pending_time_ms 和 max_maker_pending_vol_on_depth 控制。place 辅助函数根据 timeout 选择带 target 或普通 IAP 接口。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x38b60 | 61 | [strategy_comm3::Comm3Params::signal_mode](../analysis/libstrategy_comm3/decompiled_repaired/0000000000038b60.c) |
| 0x38cb0 | 47 | [strategy_comm3::Comm3Params::low_action_enum](../analysis/libstrategy_comm3/decompiled_repaired/0000000000038cb0.c) |
| 0x38ba0 | 266 | [strategy_comm3::Comm3Params::signal_trigger_mode](../analysis/libstrategy_comm3/decompiled_repaired/0000000000038ba0.c) |
| 0x59e70 | 572 | [strategy_comm3::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_comm3/decompiled_repaired/0000000000059e70.c) |
| 0x5ac40 | 554 | [strategy_comm3::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_comm3/decompiled_repaired/000000000005ac40.c) |
| 0x5a280 | 167 | [strategy_comm3::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_comm3/decompiled_repaired/000000000005a280.c) |
| 0x5a1d0 | 167 | [strategy_comm3::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_comm3/decompiled_repaired/000000000005a1d0.c) |
| 0x5a9f0 | 586 | [strategy_comm3::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_comm3/decompiled_repaired/000000000005a9f0.c) |
| 0x5a140 | 141 | [strategy_comm3::signal_trigger::SignalTrigger::point_signal_trigger_pv4](../analysis/libstrategy_comm3/decompiled_repaired/000000000005a140.c) |
| 0x5a330 | 1717 | [strategy_comm3::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_comm3/decompiled_repaired/000000000005a330.c) |
| 0x5a0b0 | 137 | [strategy_comm3::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_comm3/decompiled_repaired/000000000005a0b0.c) |
| 0x5b3e0 | 152 | [strategy_comm3::signal_trigger::dynamic_threshold](../analysis/libstrategy_comm3/decompiled_repaired/000000000005b3e0.c) |
| 0x5ae70 | 1378 | [_ZN14strategy_comm314signal_trigger17enum_rate_counter17h905b0f882511e003E.llvm.5776159170460620602](../analysis/libstrategy_comm3/decompiled_repaired/000000000005ae70.c) |
| 0x59a80 | 1001 | [strategy_comm3::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_comm3/decompiled_repaired/0000000000059a80.c) |
| 0x60dc0 | 658 | [strategy_comm3::vol_spread_ratio::VolSpreadRatio::update](../analysis/libstrategy_comm3/decompiled_repaired/0000000000060dc0.c) |
| 0x39540 | 1377 | [strategy_comm3::live_pending_counts](../analysis/libstrategy_comm3/decompiled_repaired/0000000000039540.c) |
| 0x38ce0 | 2134 | [strategy_comm3::cancel_order_use_range](../analysis/libstrategy_comm3/decompiled_repaired/0000000000038ce0.c) |
| 0x3d440 | 27 | [strategy_comm3::place](../analysis/libstrategy_comm3/decompiled_repaired/000000000003d440.c) |
| 0x39ab0 | 840 | [<strategy_comm3::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_comm3/decompiled_repaired/0000000000039ab0.c) |
| 0x3d140 | 475 | [<strategy_comm3::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_comm3/decompiled_repaired/000000000003d140.c) |
| 0x3d320 | 280 | [<strategy_comm3::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_comm3/decompiled_repaired/000000000003d320.c) |
| 0x39e00 | 13113 | [<strategy_comm3::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_comm3/decompiled_repaired/0000000000039e00.c) |
| 0x61f20 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_comm3/decompiled_repaired/0000000000061f20.c) |
| 0x61f30 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_comm3/decompiled_repaired/0000000000061f30.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：40项

数组文件偏移 `0xd5070`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `trade_slippery`
12. `close_position_block_ms`
13. `touch_gate`
14. `touch_gate_timeout_ms`
15. `max_single_add_vol`
16. `max_single_add_amt`
17. `max_single_net_vol`
18. `max_single_net_amt`
19. `max_single_close_vol`
20. `max_single_close_amt`
21. `long_open_threshold`
22. `long_close_threshold`
23. `short_open_threshold`
24. `short_close_threshold`
25. `low_long_open_threshold`
26. `low_long_close_threshold`
27. `low_short_open_threshold`
28. `low_short_close_threshold`
29. `dyn_score_position_ts_threshold_s`
30. `dyn_score_max_position_ts_s`
31. `dyn_score_delta_score`
32. `use_dynamic_volspread_ratio`
33. `market_volatility_ms`
34. `rolling_windows_ms`
35. `split_high_low_ratio_threshold`
36. `low_action`
37. `maker_order_max_pending_time_ms`
38. `max_maker_pending_vol_on_depth`
39. `maker_ticks_inside`
40. `maker_cancel_range_levels`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_comm3/assembly.txt)、[符号](../analysis/libstrategy_comm3/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_comm3/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_comm3/核心伪代码.c)。
