# libstrategy_comm5.so

SHA-256：`a778c872369f31f436a1ba7b4c996934492b45bc6f2faa8860de6f42455accdb`；大小：1,311,384字节。

## 策略逻辑

与既有深入还原库逐字节相同，详见 comm5_verified_reference/策略逻辑还原说明.md。承接 comm4_1 的阶段/执行机制，新增 XS 截面仓位分配：从 daily_pnl_path 读取 xs_date 之前的历史收益，做截断、指数衰减加权、品种排名和分档倍率，再经 eff_amts 作用于金额限制。P2/P3 的正 size_mult 优先用全局 max_single_net_amt 乘阶段倍率，不能简单认为阶段绝对金额总是优先。缺少足够样本、边界重叠等情况有倍率1回退。此版本已有15,092组合成计算核对，但不是完整订单事件回放。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x3b520 | 208 | [strategy_comm5::next_phase](../analysis/libstrategy_comm5/decompiled_repaired/000000000003b520.c) |
| 0x3b390 | 266 | [strategy_comm5::xs_inst_of](../analysis/libstrategy_comm5/decompiled_repaired/000000000003b390.c) |
| 0x3b000 | 61 | [strategy_comm5::Comm5Params::signal_mode](../analysis/libstrategy_comm5/decompiled_repaired/000000000003b000.c) |
| 0x3b040 | 266 | [strategy_comm5::Comm5Params::signal_trigger_mode](../analysis/libstrategy_comm5/decompiled_repaired/000000000003b040.c) |
| 0x3b150 | 573 | [strategy_comm5::Comm5Params::effective](../analysis/libstrategy_comm5/decompiled_repaired/000000000003b150.c) |
| 0x3c600 | 670 | [strategy_comm5::StrategyComm5::xs_mult](../analysis/libstrategy_comm5/decompiled_repaired/000000000003c600.c) |
| 0x82900 | 572 | [strategy_comm5::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_comm5/decompiled_repaired/0000000000082900.c) |
| 0x83790 | 513 | [strategy_comm5::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_comm5/decompiled_repaired/0000000000083790.c) |
| 0x82d70 | 264 | [strategy_comm5::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_comm5/decompiled_repaired/0000000000082d70.c) |
| 0x82c60 | 264 | [strategy_comm5::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_comm5/decompiled_repaired/0000000000082c60.c) |
| 0x83550 | 561 | [strategy_comm5::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_comm5/decompiled_repaired/0000000000083550.c) |
| 0x82bd0 | 141 | [strategy_comm5::signal_trigger::SignalTrigger::point_signal_trigger_pv4](../analysis/libstrategy_comm5/decompiled_repaired/0000000000082bd0.c) |
| 0x82e80 | 1729 | [strategy_comm5::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_comm5/decompiled_repaired/0000000000082e80.c) |
| 0x82b40 | 137 | [strategy_comm5::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_comm5/decompiled_repaired/0000000000082b40.c) |
| 0x827b0 | 326 | [strategy_comm5::signal_trigger::SignalTrigger::new](../analysis/libstrategy_comm5/decompiled_repaired/00000000000827b0.c) |
| 0x83f00 | 152 | [strategy_comm5::signal_trigger::dynamic_threshold](../analysis/libstrategy_comm5/decompiled_repaired/0000000000083f00.c) |
| 0x839a0 | 1364 | [_ZN14strategy_comm514signal_trigger17enum_rate_counter17hb51fcb9e7a9a6c40E.llvm.1301231569978033549](../analysis/libstrategy_comm5/decompiled_repaired/00000000000839a0.c) |
| 0x823c0 | 1001 | [strategy_comm5::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_comm5/decompiled_repaired/00000000000823c0.c) |
| 0x3c3c0 | 315 | [strategy_comm5::high_taker_rate](../analysis/libstrategy_comm5/decompiled_repaired/000000000003c3c0.c) |
| 0x81770 | 658 | [strategy_comm5::vol_spread_ratio::VolSpreadRatio::update](../analysis/libstrategy_comm5/decompiled_repaired/0000000000081770.c) |
| 0x3c500 | 250 | [strategy_comm5::taker_fillable_cum](../analysis/libstrategy_comm5/decompiled_repaired/000000000003c500.c) |
| 0x3be50 | 1377 | [strategy_comm5::live_pending_counts](../analysis/libstrategy_comm5/decompiled_repaired/000000000003be50.c) |
| 0x3b5f0 | 2134 | [strategy_comm5::cancel_order_use_range](../analysis/libstrategy_comm5/decompiled_repaired/000000000003b5f0.c) |
| 0x44b80 | 27 | [strategy_comm5::place](../analysis/libstrategy_comm5/decompiled_repaired/0000000000044b80.c) |
| 0x3b4a0 | 118 | [strategy_comm5::eff_amts](../analysis/libstrategy_comm5/decompiled_repaired/000000000003b4a0.c) |
| 0x3c8a0 | 10858 | [<strategy_comm5::StrategyComm5 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_comm5/decompiled_repaired/000000000003c8a0.c) |
| 0x44880 | 475 | [<strategy_comm5::StrategyComm5 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_comm5/decompiled_repaired/0000000000044880.c) |
| 0x44a60 | 280 | [<strategy_comm5::StrategyComm5 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_comm5/decompiled_repaired/0000000000044a60.c) |
| 0x3f310 | 21860 | [<strategy_comm5::StrategyComm5 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_comm5/decompiled_repaired/000000000003f310.c) |
| 0x7b620 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_comm5/decompiled_repaired/000000000007b620.c) |
| 0x7b630 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_comm5/decompiled_repaired/000000000007b630.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：71项

数组文件偏移 `0xfb8d8`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `score_taker_rate_alpha`
9. `taker_rate_baseline`
10. `max_taker_rate`
11. `high_taker_half_spread`
12. `taker_mult_max`
13. `taker_cover_k`
14. `taker_skip_half_spread_bp`
15. `trade_slippery`
16. `close_position_block_ms`
17. `touch_gate`
18. `touch_gate_timeout_ms`
19. `max_single_add_vol`
20. `max_single_add_amt`
21. `max_single_net_vol`
22. `max_single_net_amt`
23. `max_single_close_vol`
24. `max_single_close_amt`
25. `long_open_threshold`
26. `long_close_threshold`
27. `short_open_threshold`
28. `short_close_threshold`
29. `low_long_open_threshold`
30. `low_long_close_threshold`
31. `low_short_open_threshold`
32. `low_short_close_threshold`
33. `dyn_score_position_ts_threshold_s`
34. `dyn_score_max_position_ts_s`
35. `dyn_score_delta_score`
36. `use_dynamic_volspread_ratio`
37. `market_volatility_ms`
38. `rolling_windows_ms`
39. `split_high_low_ratio_threshold`
40. `low_action`
41. `maker_order_max_pending_time_ms`
42. `max_maker_pending_vol_on_depth`
43. `maker_ticks_inside`
44. `maker_cancel_range_levels`
45. `enable_phases`
46. `invert_phase`
47. `watcher_strategy_name`
48. `watcher_account_name`
49. `enter_phase2`
50. `exit_phase2`
51. `enter_phase3`
52. `exit_phase3`
53. `min_trades_for_upgrade`
54. `phase1`
55. `phase2`
56. `phase3`
57. `enable_xs`
58. `daily_pnl_path`
59. `xs_date`
60. `ew_lags`
61. `ew_half_life_days`
62. `xs_q3`
63. `xs_q2`
64. `xs_qb`
65. `xs_mult3`
66. `xs_mult2`
67. `xs_mult_skip`
68. `xs_pnl_clip`
69. `xs_min_pool`
70. `phase2_size_mult`
71. `phase3_size_mult`

### 字段组2：15项

数组文件偏移 `0xfc050`。

1. `long_open_threshold`
2. `long_close_threshold`
3. `short_open_threshold`
4. `short_close_threshold`
5. `max_single_net_vol`
6. `max_single_net_amt`
7. `max_single_add_vol`
8. `max_single_add_amt`
9. `high_taker_half_spread`
10. `taker_mult_max`
11. `taker_cover_k`
12. `taker_skip_half_spread_bp`
13. `taker_rate_baseline`
14. `max_taker_rate`
15. `low_action`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_comm5/assembly.txt)、[符号](../analysis/libstrategy_comm5/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_comm5/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_comm5/核心伪代码.c)。
