# libstrategy_sos6.so

SHA-256：`77c2bf03431db0f38d4bb05953c7dae5d44f97511a7bca37b0eb06c63d0d32e0`；大小：1,134,224字节。

## 策略逻辑

与 sos5 同样配置三个 SectionParams 并依 watcher 收益状态切换，但字段为 watcher_pnl_key（默认构造字符串 rolling_pnl），没有 sos5 的 live_basket_bp 参数组与篮子估值函数。新增 apply_threshold_delta，主回调读取 threshold_long_open/close、threshold_short_open/close 等发布信息并应用阈值调整。由此它依赖 watcher 同时提供状态和阈值信息，不能把它当成 sos5 单纯改号版本。下单仍通过 place_order_by_mode 分流，四阈值与 section 的 trade_mode 共同决定执行。 place_order_by_mode与sos5同样识别IOC/IAP及全局配置回退。 apply_threshold_delta的确切结构是：delta=watcher四阈值-section1原始四阈值；三个section的有效阈值分别等于各自原始阈值+delta。因此保留section间原有差值，并非把三个section都直接覆盖成watcher值。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x4c0d0 | 163 | [strategy_sos6::StrategySoS6::apply_threshold_delta](../analysis/libstrategy_sos6/decompiled_repaired/000000000004c0d0.c) |
| 0x5e2c0 | 1845 | [strategy_sos6::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_sos6/decompiled_repaired/000000000005e2c0.c) |
| 0x5f5c0 | 554 | [strategy_sos6::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_sos6/decompiled_repaired/000000000005f5c0.c) |
| 0x5eba0 | 264 | [strategy_sos6::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_sos6/decompiled_repaired/000000000005eba0.c) |
| 0x5ea90 | 264 | [strategy_sos6::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_sos6/decompiled_repaired/000000000005ea90.c) |
| 0x5f370 | 586 | [strategy_sos6::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_sos6/decompiled_repaired/000000000005f370.c) |
| 0x5ecb0 | 1717 | [strategy_sos6::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_sos6/decompiled_repaired/000000000005ecb0.c) |
| 0x5ea00 | 137 | [strategy_sos6::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](../analysis/libstrategy_sos6/decompiled_repaired/000000000005ea00.c) |
| 0x5f7f0 | 1378 | [_ZN13strategy_sos614signal_trigger17enum_rate_counter17hd3ab24ddaa71514fE.llvm.5674171606368244516](../analysis/libstrategy_sos6/decompiled_repaired/000000000005f7f0.c) |
| 0x477d0 | 98 | [strategy_sos6::default_pnl_key](../analysis/libstrategy_sos6/decompiled_repaired/00000000000477d0.c) |
| 0x4c180 | 338 | [strategy_sos6::place_order_by_mode](../analysis/libstrategy_sos6/decompiled_repaired/000000000004c180.c) |
| 0x47840 | 2083 | [<strategy_sos6::StrategySoS6 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_sos6/decompiled_repaired/0000000000047840.c) |
| 0x4bfb0 | 280 | [<strategy_sos6::StrategySoS6 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](../analysis/libstrategy_sos6/decompiled_repaired/000000000004bfb0.c) |
| 0x48070 | 16187 | [<strategy_sos6::StrategySoS6 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_sos6/decompiled_repaired/0000000000048070.c) |
| 0x65da0 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_sos6/decompiled_repaired/0000000000065da0.c) |
| 0x65db0 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_sos6/decompiled_repaired/0000000000065db0.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：35项

数组文件偏移 `0xd52e8`。

1. `watcher_strategy_name`
2. `watcher_account_name`
3. `watcher_pnl_key`
4. `section1_to_2_pnl`
5. `section1_to_3_pnl`
6. `section2_to_1_pnl`
7. `section2_to_3_pnl`
8. `section3_to_1_pnl`
9. `order_book_1_2_gap`
10. `sos_taker_rate`
11. `sos_add_vol`
12. `section1`
13. `section2`
14. `section3`
15. `signal_mode`
16. `pv1_alpha`
17. `cost_alpha`
18. `signal_trigger_mode`
19. `vote_rate`
20. `quantile`
21. `signal_windows_s`
22. `score_taker_rate_alpha`
23. `taker_rate_baseline`
24. `max_taker_rate`
25. `trade_slippery`
26. `close_position_block_ms`
27. `max_single_close_vol`
28. `max_single_close_amt`
29. `dyn_score_position_ts_threshold_s`
30. `dyn_score_max_position_ts_s`
31. `dyn_score_delta_score`
32. `dyn_pending_position_ts_threshold_s`
33. `dyn_pending_max_position_ts_s`
34. `dyn_pending_order_max_pending_time_ms`
35. `dyn_pending_delta_max_pending_ts_ms`

### 字段组2：13项

数组文件偏移 `0xd5788`。

1. `insts`
2. `ranks`
3. `signal_all`
4. `trade_mode`
5. `long_open_threshold`
6. `long_close_threshold`
7. `short_open_threshold`
8. `short_close_threshold`
9. `max_single_add_vol`
10. `max_single_net_vol`
11. `max_single_add_amt`
12. `max_single_net_amt`
13. `trade_code`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_sos6/assembly.txt)、[符号](../analysis/libstrategy_sos6/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_sos6/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_sos6/核心伪代码.c)。
