# libstrategy_sm3.so

SHA-256：`fae00455457a8cbf18a8d048211a5a7192c1554fcb1c94d43754dabebc527cc5`；大小：1,138,184字节。

## 策略逻辑

一次性报价决策分支，核心为 get_quote_price_one_shot，使用 maker_signal_abtype_u 与 maker_signal_threshold。配置保留 PV 信号倍率、成本倍率、四阈值、动态持仓阈值、maker/taker 数量约束和 touch gate，但没有 sm1 的 signal_trigger_mode/vote_rate/quantile/signal_windows_s。主回调取得主信号及 maker 辅助信号后，用 one-shot 函数形成报价，再管理旧单和发单。这里的 one-shot 指函数路径，不代表策略生命周期只允许一次下单。 apply_book_vol_cap按执行类型分流：主动分支累加最多五档限价内对手量，并可施加max_single_taker_vol；被动分支用本方前三档有效挂量的平均值并可施加max_maker_pending_vol_on_depth。book_vol_cap是否启用影响盘口约束，不能假设每个配置都会开启。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x3ba30 | 922 | [strategy_sm3::cancel_side](../analysis/libstrategy_sm3/decompiled_repaired/000000000003ba30.c) |
| 0x3b9d0 | 87 | [strategy_sm3::default_pv1](../analysis/libstrategy_sm3/decompiled_repaired/000000000003b9d0.c) |
| 0x3c7b0 | 720 | [strategy_sm3::apply_book_vol_cap](../analysis/libstrategy_sm3/decompiled_repaired/000000000003c7b0.c) |
| 0x3c240 | 1377 | [strategy_sm3::live_pending_counts](../analysis/libstrategy_sm3/decompiled_repaired/000000000003c240.c) |
| 0x3bdd0 | 1121 | [strategy_sm3::cancel_order_use_range](../analysis/libstrategy_sm3/decompiled_repaired/000000000003bdd0.c) |
| 0x87da0 | 588 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_sm3/decompiled_repaired/0000000000087da0.c) |
| 0x87ff0 | 178 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::point_signal_trigger_pv3_spread](../analysis/libstrategy_sm3/decompiled_repaired/0000000000087ff0.c) |
| 0x87cd0 | 199 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::new](../analysis/libstrategy_sm3/decompiled_repaired/0000000000087cd0.c) |
| 0x880b0 | 152 | [strategy_signal_maker_common::signal_trigger::dynamic_threshold](../analysis/libstrategy_sm3/decompiled_repaired/00000000000880b0.c) |
| 0x87a70 | 598 | [strategy_signal_maker_common::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_sm3/decompiled_repaired/0000000000087a70.c) |
| 0x88150 | 63 | [strategy_signal_maker_common::signal_trigger::dynamic_pending_ts_ms](../analysis/libstrategy_sm3/decompiled_repaired/0000000000088150.c) |
| 0x84d30 | 135 | [strategy_signal_maker_common::get_quote_price::get_quote_vol](../analysis/libstrategy_sm3/decompiled_repaired/0000000000084d30.c) |
| 0x84dc0 | 8287 | [strategy_signal_maker_common::get_quote_price::get_quote_price_one_shot](../analysis/libstrategy_sm3/decompiled_repaired/0000000000084dc0.c) |
| 0x3ca80 | 825 | [<strategy_sm3::StrategySM3 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_sm3/decompiled_repaired/000000000003ca80.c) |
| 0x40260 | 352 | [<strategy_sm3::StrategySM3 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_sm3/decompiled_repaired/0000000000040260.c) |
| 0x3cdc0 | 13460 | [<strategy_sm3::StrategySM3 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_sm3/decompiled_repaired/000000000003cdc0.c) |
| 0x57a90 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_sm3/decompiled_repaired/0000000000057a90.c) |
| 0x57aa0 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_sm3/decompiled_repaired/0000000000057aa0.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：33项

数组文件偏移 `0xd4100`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `taker_rate_baseline`
5. `max_taker_rate`
6. `trade_slippery`
7. `close_position_block_ms`
8. `max_single_add_vol`
9. `max_single_add_amt`
10. `max_single_net_vol`
11. `max_single_net_amt`
12. `max_single_close_vol`
13. `max_single_close_amt`
14. `long_open_threshold`
15. `long_close_threshold`
16. `short_open_threshold`
17. `short_close_threshold`
18. `dyn_score_position_ts_threshold_s`
19. `dyn_score_max_position_ts_s`
20. `dyn_score_delta_score`
21. `dyn_pending_position_ts_threshold_s`
22. `dyn_pending_max_position_ts_s`
23. `dyn_pending_delta_max_pending_ts_ms`
24. `order_max_pending_time_ms`
25. `max_maker_pending_vol_on_depth`
26. `max_maker_limit_rate_bias_from_mid`
27. `maker_signal_abtype_u`
28. `maker_signal_threshold`
29. `signal_all`
30. `touch_gate`
31. `touch_gate_timeout_ms`
32. `book_vol_cap`
33. `max_single_taker_vol`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_sm3/assembly.txt)、[符号](../analysis/libstrategy_sm3/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_sm3/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_sm3/核心伪代码.c)。
