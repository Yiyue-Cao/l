# libstrategy_sm1.so

SHA-256：`064a30ed6083edddc2925050877c1806e954b56a126c8645f3cddd63dea95a82`；大小：1,124,480字节。

## 策略逻辑

信号驱动报价基础版。既有 signal_mode/pv1_alpha/cost_alpha 和点/窗口触发，也有 get_quote_price、get_quote_vol、apply_book_vol_cap。触发动作确定后，报价函数比较信号相对开平阈值的优势与盘口半价差，选择主动或被动执行；数量同时受仓位、金额、盘口量、单次 taker 手数和 maker 待成交上限限制。cancel_side 与 cancel_order_use_range 管理方向和报价范围；touch gate 限制最优价不变期间的重复触发。默认字符串构造函数为 PV1 和 PointTrigger，但其余参数默认数值不能由名称猜测。 apply_book_vol_cap按执行类型分流：主动分支累加最多五档限价内对手量，并可施加max_single_taker_vol；被动分支用本方前三档有效挂量的平均值并可施加max_maker_pending_vol_on_depth。book_vol_cap是否启用影响盘口约束，不能假设每个配置都会开启。

## 事件入口与关键计算

地址为ELF虚拟地址；Ghidra项目中的地址另加0x100000。下表保留业务符号，不将序列化、析构和FFI包装函数计为独立策略逻辑。

| 地址 | 机器码字节 | 函数及伪代码 |
|---|---:|---|
| 0x458b0 | 922 | [strategy_sm1::cancel_side](../analysis/libstrategy_sm1/decompiled_repaired/00000000000458b0.c) |
| 0x457e0 | 87 | [strategy_sm1::default_pv1](../analysis/libstrategy_sm1/decompiled_repaired/00000000000457e0.c) |
| 0x46630 | 720 | [strategy_sm1::apply_book_vol_cap](../analysis/libstrategy_sm1/decompiled_repaired/0000000000046630.c) |
| 0x460c0 | 1377 | [strategy_sm1::live_pending_counts](../analysis/libstrategy_sm1/decompiled_repaired/00000000000460c0.c) |
| 0x45840 | 98 | [strategy_sm1::default_point_trigger](../analysis/libstrategy_sm1/decompiled_repaired/0000000000045840.c) |
| 0x45c50 | 1121 | [strategy_sm1::cancel_order_use_range](../analysis/libstrategy_sm1/decompiled_repaired/0000000000045c50.c) |
| 0x841d0 | 588 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::update_score](../analysis/libstrategy_sm1/decompiled_repaired/00000000000841d0.c) |
| 0x85000 | 555 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_rsi_trigger](../analysis/libstrategy_sm1/decompiled_repaired/0000000000085000.c) |
| 0x845f0 | 265 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_std_trigger](../analysis/libstrategy_sm1/decompiled_repaired/00000000000845f0.c) |
| 0x844e0 | 265 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_mean_trigger](../analysis/libstrategy_sm1/decompiled_repaired/00000000000844e0.c) |
| 0x84db0 | 587 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_sharpe_trigger](../analysis/libstrategy_sm1/decompiled_repaired/0000000000084db0.c) |
| 0x84700 | 1702 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_quantile_trigger](../analysis/libstrategy_sm1/decompiled_repaired/0000000000084700.c) |
| 0x84420 | 178 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::point_signal_trigger_pv3_spread](../analysis/libstrategy_sm1/decompiled_repaired/0000000000084420.c) |
| 0x84100 | 199 | [strategy_signal_maker_common::signal_trigger::SignalTrigger::new](../analysis/libstrategy_sm1/decompiled_repaired/0000000000084100.c) |
| 0x857b0 | 152 | [strategy_signal_maker_common::signal_trigger::dynamic_threshold](../analysis/libstrategy_sm1/decompiled_repaired/00000000000857b0.c) |
| 0x85230 | 1394 | [strategy_signal_maker_common::signal_trigger::enum_rate_counter](../analysis/libstrategy_sm1/decompiled_repaired/0000000000085230.c) |
| 0x83ea0 | 598 | [strategy_signal_maker_common::signal_trigger::TsQuantileCalculator::update](../analysis/libstrategy_sm1/decompiled_repaired/0000000000083ea0.c) |
| 0x85850 | 63 | [strategy_signal_maker_common::signal_trigger::dynamic_pending_ts_ms](../analysis/libstrategy_sm1/decompiled_repaired/0000000000085850.c) |
| 0x82290 | 135 | [strategy_signal_maker_common::get_quote_price::get_quote_vol](../analysis/libstrategy_sm1/decompiled_repaired/0000000000082290.c) |
| 0x82320 | 1978 | [strategy_signal_maker_common::get_quote_price::get_quote_price](../analysis/libstrategy_sm1/decompiled_repaired/0000000000082320.c) |
| 0x46900 | 848 | [<strategy_sm1::StrategySM1 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](../analysis/libstrategy_sm1/decompiled_repaired/0000000000046900.c) |
| 0x49620 | 352 | [<strategy_sm1::StrategySM1 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](../analysis/libstrategy_sm1/decompiled_repaired/0000000000049620.c) |
| 0x46c50 | 10692 | [<strategy_sm1::StrategySM1 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](../analysis/libstrategy_sm1/decompiled_repaired/0000000000046c50.c) |
| 0x518a0 | 6 | [fb_strategy_sdk_abi_version](../analysis/libstrategy_sm1/decompiled_repaired/00000000000518a0.c) |
| 0x518b0 | 73 | [fb_strategy_sdk_version_str](../analysis/libstrategy_sm1/decompiled_repaired/00000000000518b0.c) |

## 配置字段

以下来自ELF重定位后的Serde字段名切片数组，保留原顺序；不是从名称拼接猜分词。字段存在表示反序列化结构支持它，不表示本次任务实际启用它。除comm5参考文档外，本批未逐字段探测默认值，因此不填猜测默认值。

### 字段组1：35项

数组文件偏移 `0xd18c0`。

1. `signal_mode`
2. `pv1_alpha`
3. `cost_alpha`
4. `signal_trigger_mode`
5. `vote_rate`
6. `quantile`
7. `signal_windows_s`
8. `taker_rate_baseline`
9. `max_taker_rate`
10. `trade_slippery`
11. `close_position_block_ms`
12. `max_single_add_vol`
13. `max_single_add_amt`
14. `max_single_net_vol`
15. `max_single_net_amt`
16. `max_single_close_vol`
17. `max_single_close_amt`
18. `long_open_threshold`
19. `long_close_threshold`
20. `short_open_threshold`
21. `short_close_threshold`
22. `dyn_score_position_ts_threshold_s`
23. `dyn_score_max_position_ts_s`
24. `dyn_score_delta_score`
25. `dyn_pending_position_ts_threshold_s`
26. `dyn_pending_max_position_ts_s`
27. `dyn_pending_delta_max_pending_ts_ms`
28. `order_max_pending_time_ms`
29. `max_maker_pending_vol_on_depth`
30. `max_maker_limit_rate_bias_from_mid`
31. `signal_all`
32. `touch_gate`
33. `touch_gate_timeout_ms`
34. `book_vol_cap`
35. `max_single_taker_vol`

## 复核重点

必须保留回调先后、持仓与挂单状态、浮点取整顺序及错误回退。反编译变量名param/local不是原字段名；未经调用点和汇编确认，不应直接把指针偏移赋予经济含义。自动导出成功仅表示有伪代码，不表示分支语义均已动态验收。

证据：[完整汇编](../analysis/libstrategy_sm1/assembly.txt)、[符号](../analysis/libstrategy_sm1/symbols.txt)、[跳转表修复清单](../analysis/libstrategy_sm1/repairs.tsv)、[业务函数合并伪代码](../analysis/libstrategy_sm1/核心伪代码.c)。
