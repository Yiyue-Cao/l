# libstrategy_comm3_1.so：数学化还原与逐分支说明

保留 comm3 的 LOW maker 体系；HIGH 主动幅度新增信号超额、tanh 放大和半价差覆盖上限。这里的基础量是价格的相对半价差，不是买卖盘数量不平衡。

对应原件：`libstrategy_comm3_1.so`，SHA-256 `a42e121da5e3710bfb3d6026a57c45db830a75fb292a5bbb14b5ba99a16de5f4`。本文为 2026-11-14 新建的逐库数学说明，旧自然语言版保留，若有冲突以本页列出的原始函数与本轮证据为准。

## 记号、输入与可复现边界

设买一价为 $b$，卖一价为 $a$，中价 $m=(a+b)/2$；持仓 $q>0$ 表示多仓，$q<0$ 表示空仓；合约乘数为 $M$。价格步长与数量步长分别为 $\tau_p,\tau_v$。百分比、比例与 bp 不混用：$1\mathrm{bp}=10^{-4}$。`round` 表示本库调用的浮点四舍五入（中点远离零），不是 Python 的 ties-to-even。

外部信号、账户持仓、盘口和交易时间通过 SDK 输入。文中“输入主值/次值”只指信号事件的数值槽；未取得上游预测器源码时，不能把它改名为某个特定 alpha 或宣称这里重新训练了模型。本文公式首先针对有限实数、正价格与正合约乘数；NaN/Inf 的硬件比较分支不应拿普通实数代数擅自合并。

确定性分三层：**机器码实测**表示下面列出的原始 ELF 函数通过合成输入检查；**静态确定**表示已从本库反编译、常量或指令确定控制关系；**尚未闭合**表示明确缺少原始配置、SDK 语义或逐事件状态验收。配置缺省值不代表历史实验启用了该值。

## 四动作不是四个可交换判断

阈值向量按内存顺序定义为

$$T=(L_o,L_c,S_o,S_c).$$

有限输入的分类器严格按以下顺序执行：

$$A(x,T)=\begin{cases}
0\ (开多),&x\ge L_o,\\
3\ (平空),&x<L_o\land x\ge S_c,\\
2\ (开空),&x<L_o\land x<S_c\land x\le S_o,\\
1\ (平多),&x<L_o\land x<S_c\land x>S_o\land x\le L_c,\\
4\ (无动作),&\text{其余}.
\end{cases}$$

先判断开多，再平空，再开空，最后平多。即使配置了交叠阈值也不排序、不纠正。例如四阈值全为零且 $x=0$，结果是开多，不是无动作。动作确定后还要受仓位、盘口、撤单与账户接口约束；“开多”可能先买回空仓，不能把整个订单量记作新增多仓。

错误/无结果与无动作也不能合并：若触发器返回错误变体，调用者走错误/提前返回分支；枚举 4 是成功计算出的“不交易”。

## 点触发的精确公式

调用点触发前，当前信号已写入触发器 `+0x38`，四阈值位于 `+0x40,+0x48,+0x50,+0x58`。令成本倍率为 $\alpha_c$，传入价差尺度为 $h$，PV1 的成本项是

$$c=\alpha_c|h|,\qquad x=\begin{cases}\max(s-c,0),&s>0,\\\min(s+c,0),&s\le0.\end{cases}$$

输出是 $(A(x,T),1)$，第二项是固定票值 1。这里先扣成本、向零截断，再比较阈值；不能改成直接把全部阈值平移，也不能把正负信号都写成 $s-c$。

例如 $T=(3,-1,-3,1)$，$s=4,c=1$ 得 $x=3$，触发开多；$s=-4,c=1$ 得 $x=-3$，触发开空；$s=0.5,c=1$ 得 $x=0$，落在无动作区。例子是合成边界说明。

商品信号模式还有两条独立路径：`PV2` 使用事件次值，`PV4` 对主值作 $\operatorname{sign}(s_0)|s_0|^{1/K_1}$，通常路径使用 $s_0\cdot\text{pv1_alpha}$。模式名大小写敏感；未匹配的字符串落入默认路径。PV4 点触发的成本改为

$$c=(|h|+\text{fee\_bp})\alpha_c.$$

原始函数浮点实参顺序为 `cost_alpha, fee_bp, spread_bp`；错误交换费用与价差会改变负值和绝对值运算，不能只依据自动反编译的参数名。

## 持仓年龄动态阈值

令 $h_p$ 为传入的持仓秒数，$t_0,t_1,\Delta$ 分别对应 `dyn_score_position_ts_threshold_s`、`dyn_score_max_position_ts_s`、`dyn_score_delta_score`。

$$d=\begin{cases}
0,&t_0<0\lor t_1<0\lor h_p<t_0\lor |\Delta|\le10^{-9},\\
\left|\Delta\min\left(\frac{h_p-t_0}{\max(t_1-t_0,10^{-6})},1\right)\right|,&\text{其余}.
\end{cases}$$

$$T'=(L_o-d,L_c+d,S_o+d,S_c-d).$$

四个门槛均变化，且负的 $\Delta$ 也产生非负 $d$。$t_1\le t_0$ 不会报错，而使用 $10^{-6}$ 的分母下限。$h_p=t_0$ 时增量为零；超过终点后饱和。以上是独立 `dynamic_threshold` 的行为，不能套到 LF4/TM5/TM6/SoS6 的内联旧逻辑上。

## 时间窗口触发与投票

每个窗口维护 $(t_i,s_i)$ 队列及 $N,\sum s_i,\sum s_i^2,\sum_{s_i>0}s_i,\sum_{s_i\le0}s_i$。插入当前点后，删除所有 $t-t_i>W$ 的旧点；恰好位于 $t-W$ 的点保留。更新按加减旧值进行，不能随意改为重新求和后声称浮点逐位等价。

$$\mu=\frac{\sum s_i}{N},\qquad \sigma=\sqrt{\max(\sum s_i^2/\max(N,1)-\mu^2,0)}.$$

均值触发把 $\mu$ 送入四阈值比较。Sharpe 触发使用 $\mu/\sigma$，$|\sigma|\le10^{-6}$ 时取零；这是信号窗口统计量，不是策略收益夏普。RSI 使用信号正负值的累计量，令 $P=\sum_{s_i>0}s_i,N_-=\sum_{s_i\le0}s_i$：

$$R=\begin{cases}100-\frac{100}{P/|N_-|+1},&|N_-|>10^{-6},\\50,&\text{其余}.\end{cases}$$

特别注意：`update` 写入和、平方和和均值，但不会自动重算所有版本的 `std_cache`。`WindowsStdTrigger` 读的是缓存槽，不能无条件用上式即时标准差替代；Sharpe 分支另有重算行为。信号带同样需要保留缓存的实际更新顺序。

分位数按有序观测的整数下标取值，使用 $\lfloor qN\rfloor$ 与 $\lfloor(1-q)N\rfloor$，不是线性插值；端点越界可返回错误。多窗口先形成各自候选动作，再计票，最高票比例必须**严格大于** `vote_rate`。并列候选涉及 HashMap 遍历，不应凭业务偏好增加“多头优先”或“平仓优先”。本节是对应窗口函数的静态说明；本轮新增的全库实测不包括每一种窗口的完整状态序列。

## 波动/半价差统计不是订单簿不平衡

此库 `VolSpreadRatio::update` 的三项浮点输入是毫秒时间、买价、卖价。短窗口 $W_v$ 保存中价，长窗口 $W_r$ 保存收益变化与半价差样本。

$$m_t=(a_t+b_t)/2,\quad H_t=\frac{\operatorname{round}(10^5(a_t-b_t)/(a_t+b_t))}{10}.$$

短窗口淘汰条件为 $t-t_i>W_v$。不足两个点、最旧点覆盖时长 $<W_v/2$ 或旧中价不为正时，返回 `None`，不能把它当成零。满足条件后：

$$r_t=\frac{\operatorname{round}(10^5(m_t/m_{old}-1))}{10},\quad V_t=\frac{\operatorname{std}_{pop}(r_i)}{\operatorname{mean}(H_i)}.$$

只有收益样本数大于 1 且平均半价差为正才返回 `Some(V_t)`。两个队列采用同样的左边界保留规则。此式分子是跨短窗口的中价收益变化标准差，分母是半价差均值；不是逐 tick 成交量、振幅、买卖委托数量比，也不是成交额。

有限值路径的分组条件为

$$LOW=\text{use_dynamic_volspread_ratio}\land\operatorname{Some}(V_t)\land V_t\le\text{split_high_low_ratio_threshold}.$$

其余为 HIGH。关闭动态统计、暖启动返回 None、收益样本不足，都明确回退 HIGH；等于分界值属于 LOW。这是逐库主回调的分支证据，不是对 None 载荷作数值比较。

K1 表的键为 SDK `signal_parameter_id` 返回的信号参数 ID，**不是品种名**。ID 获取失败时使用 0；在选定 LOW/HIGH 表中查不到键时，K1 回退 1。本轮分别初始化并读取九个库的内嵌常量表，每库 LOW 188 项、HIGH 183 项；九份表当前内容一致，这是逐库提取后的比较结论，并非依据版本名假设。完整数值见本页附表。

## HIGH 主动幅度的可计算定义

令信号为 $s$，相应动作门槛为 $\theta$，传入半价差 bp 为 $H$，上限倍数为 $U$，覆盖系数为 $k$。函数的 $a,b$ 是价格，不是盘口量。

$$r_0=\max\left(\frac{a-b}{a+b},0\right),\quad e=\max(|s|/|\theta|-1,0),$$
$$u=1+(U-1)\tanh(e/2),\quad v=(|s|-|\theta|)k/H,$$
$$r=r_0\max(\min(v,u),0).$$

控制顺序同样属于公式：若 $a+b\le0$ 返回 0；若 $H\le0$、$U\le1$ 或 $|\theta|<10^{-9}$，返回 $r_0$。仅其他情况下计算 $e,u,v$。因此 $s=\theta$ 时未必返回基础幅度，正常计算路径的覆盖项为零。此函数输出价格比例，之后仍可能被调用者的基准幅度、最大幅度和步长处理；不能把它的结果直接当成成交比例。

## LOW 路由、maker 价格与撤单

四个 `low_*_threshold` 都是 `Option<f64>`：缺省 `None` 继承相应普通阈值；`Some(0)` 是真正的零，不等于继承。`low_action` 的字符串分支区分默认主动路径、`skip` 和 `maker`。它控制执行方式，不删除该时点已经发生的统计更新。

comm 型 maker 的未取整价格是

$$p_b=\min(b+n\tau_p,a-\tau_p),\qquad p_s=\max(a-n\tau_p,b+\tau_p),$$

其中 $n=\text{maker_ticks_inside}$。这是按价格步长计算的公式，与 SM1/SM4 内部硬编码 0.2 的报价函数不同。

撤单集合分两遍形成：先撤相反买卖方向，再撤同向但相对目标过时的订单。令 $R=\text{maker_cancel_range_levels}\cdot\tau_p$，买单在 $p<p_b-R$ 时撤，卖单在 $p>p_s+R$ 时撤；等号保留。已经请求撤销的 ID 去重，不重复计入仍然存活的订单。同方向仍有存活在途单时，新单受阻。撤单请求并不代表成交或撤单回报已经完成。

maker 盘口数量尺度取本方前三个有效价格档的数量均值；无效价格档不作为有效分母。正的 maker 数量上限进一步截断，非正值是否关闭该上限由所在调用分支决定，不能与负风险额度“无限大”的规则混同。

## comm3.1 的边界与例子

此版本 HIGH 函数接收 7 个浮点实参，没有后续版本的 `taker_skip_half_spread_bp` 与提前返回实参。$U=1$ 会直接退回基础半价差比例；$U>1$ 才进入双重 cap。若 $|s|<|\theta|$，覆盖项可能为负，最外层截断将幅度置零。

例如 $a=100.1,b=99.9,H=10,\theta=2,s=4,U=3,k=1$：$r_0=0.001$，$e=1$，$u=1+2\tanh(0.5)$，$v=0.2$，因此返回 $0.0002$。虽然设置最大放大倍数 3，这一例子真正生效的是成本覆盖 cap 0.2。

该函数改变主动价格偏移，不直接决定手数、成交概率或是否下单。LOW maker 仍使用另一套报价和撤单规则；不能将 HIGH 的 $r$ 套在 LOW maker 的 tick 内插公式上。

## 数量、金额与订单请求的层次

所有数量计算都必须区分当前净持仓 $q$、本次有符号请求 $v$、在途预占和最终成交量。对使用金额上限的分支，金额换算以实际选择的订单价格 $p$ 和合约乘数 $M$ 进行，数学上为 $A/(pM)$；原指令常按 `(A/p)/M` 连续除法，逐位复现不能随意改为先乘分母。

负的风险额度在相应限额分支转换为 $+\infty$；零是真实约束。`max_single_add_vol/amt` 约束新增部分，`max_single_net_vol/amt` 约束方向净敞口，`max_single_close_vol/amt` 约束旧反向仓位的平仓部分。开仓动作可以把“新方向允许增量”和“允许平掉的反向旧仓”相加；纯平仓动作不应允许越过零仓继续反向开仓。具体分支中的 `max(amount/(pM),1)` 会形成至少一手的中间额度，但最后仍受其他 cap 和数量步长限制。

实际订单前还有 SDK `margin_filter`、`impact_block_check`、交易时段、允许合约/信号和在途订单检查。它们是可见的调用边界，不能用“所有条件都通过”代替未知历史账户状态。价格与数量最终经过 `round_with_step_f64`；本文保留函数调用及 mode，而不把所有 mode 都武断解释为向下取整。IOC、IAP 或带 target 的 IAP 请求如何被撮合，属于通用引擎和账户模型。

因此复现输出应先比较 `(动作、报价类型、请求价、请求量、撤单ID序列、状态更新)`；仅比较最终收益曲线无法证明这些分支相同。

## 本库内嵌 K1 全表

键为信号参数 ID；表中“缺失→1”表示该组没有此键，主回调使用默认 1。

| signal_parameter_id | LOW K1 | HIGH K1 |
|---:|---:|---:|
| 6225 | 0.3 | 0.7 |
| 6271 | 0.3 | 1.3 |
| 6272 | 0.3 | 1.3 |
| 6273 | 0.2 | 1.2 |
| 6274 | 0.2 | 1.0 |
| 6275 | 0.2 | 0.9 |
| 6276 | 0.2 | 0.9 |
| 6277 | 0.2 | 0.8 |
| 6278 | 1.0 | 1.0 |
| 6279 | 1.0 | 1.0 |
| 6280 | 1.0 | 1.0 |
| 6281 | 1.0 | 1.0 |
| 6282 | 1.0 | 1.0 |
| 6283 | 1.0 | 1.0 |
| 6284 | 1.0 | 1.0 |
| 6285 | 1.0 | 1.0 |
| 6286 | 1.0 | 1.0 |
| 6287 | 1.0 | 1.0 |
| 6288 | 1.0 | 1.0 |
| 6289 | 1.0 | 1.0 |
| 62788 | 0.4 | 1.6 |
| 62789 | 0.3 | 1.6 |
| 62790 | 0.3 | 1.4 |
| 62791 | 0.2 | 1.3 |
| 62792 | 0.2 | 1.1 |
| 62793 | 0.2 | 1.0 |
| 62794 | 0.2 | 0.9 |
| 62800 | 0.2 | 1.2 |
| 62801 | 0.2 | 1.0 |
| 62802 | 0.3 | 1.0 |
| 62803 | 0.3 | 0.9 |
| 62810 | 0.2 | 缺失→1 |
| 62811 | 0.2 | 缺失→1 |
| 62812 | 0.3 | 缺失→1 |
| 62813 | 0.3 | 缺失→1 |
| 62814 | 0.4 | 缺失→1 |
| 62820 | 0.3 | 1.1 |
| 62821 | 0.3 | 1.0 |
| 62822 | 0.3 | 0.9 |
| 62823 | 0.4 | 0.8 |
| 62824 | 0.5 | 0.7 |
| 62825 | 0.6 | 0.7 |
| 62900 | 0.3 | 1.2 |
| 62901 | 0.3 | 1.0 |
| 62902 | 0.3 | 1.0 |
| 62903 | 0.3 | 0.9 |
| 62904 | 0.4 | 0.8 |
| 62905 | 0.5 | 0.7 |
| 82000 | 0.3 | 1.2 |
| 82001 | 0.3 | 1.1 |
| 82002 | 0.3 | 1.0 |
| 82003 | 0.4 | 0.9 |
| 82004 | 0.5 | 0.8 |
| 82005 | 0.6 | 0.8 |
| 628100 | 0.3 | 1.1 |
| 628110 | 0.3 | 1.0 |
| 628120 | 0.3 | 0.9 |
| 628130 | 0.4 | 0.8 |
| 628140 | 0.5 | 0.7 |
| 628150 | 0.6 | 0.7 |
| 628300 | 0.4 | 1.5 |
| 628310 | 0.4 | 1.4 |
| 628320 | 0.3 | 1.2 |
| 628330 | 0.3 | 1.0 |
| 628340 | 0.3 | 0.9 |
| 628350 | 0.3 | 0.8 |
| 628360 | 0.3 | 0.7 |
| 628370 | 0.3 | 0.7 |
| 628800 | 0.4 | 1.4 |
| 628810 | 0.4 | 1.3 |
| 628820 | 0.3 | 1.1 |
| 628830 | 0.3 | 1.0 |
| 628840 | 0.2 | 0.8 |
| 628850 | 0.2 | 0.7 |
| 628860 | 0.3 | 0.7 |
| 628870 | 0.3 | 0.6 |
| 628880 | 0.4 | 0.6 |
| 628890 | 0.5 | 0.7 |
| 629000 | 0.3 | 1.0 |
| 629010 | 0.3 | 1.0 |
| 629020 | 0.3 | 0.9 |
| 629030 | 0.4 | 0.8 |
| 629040 | 0.5 | 0.7 |
| 629050 | 0.6 | 0.7 |
| 629200 | 0.3 | 1.1 |
| 629210 | 0.3 | 1.0 |
| 629220 | 0.3 | 0.9 |
| 629230 | 0.4 | 0.8 |
| 629240 | 0.5 | 0.7 |
| 629250 | 0.6 | 0.7 |
| 629260 | 0.7 | 0.7 |
| 629270 | 0.8 | 0.7 |
| 629280 | 0.9 | 0.8 |
| 629290 | 0.9 | 0.8 |
| 629400 | 0.2 | 1.1 |
| 629410 | 0.2 | 1.0 |
| 629420 | 0.3 | 0.9 |
| 629430 | 0.3 | 0.8 |
| 629440 | 0.4 | 0.7 |
| 629450 | 0.6 | 0.7 |
| 629460 | 0.7 | 0.7 |
| 629470 | 0.8 | 0.7 |
| 629480 | 0.9 | 0.8 |
| 629490 | 1.0 | 0.8 |
| 629600 | 0.4 | 1.5 |
| 629610 | 0.4 | 1.4 |
| 629620 | 0.3 | 1.2 |
| 629630 | 0.3 | 1.1 |
| 629640 | 0.3 | 0.9 |
| 629650 | 0.3 | 0.8 |
| 629660 | 0.3 | 0.7 |
| 629670 | 0.4 | 0.7 |
| 629680 | 0.4 | 0.7 |
| 629690 | 0.5 | 0.7 |
| 820000 | 0.3 | 1.2 |
| 820010 | 0.3 | 1.0 |
| 820020 | 0.3 | 0.9 |
| 820030 | 0.4 | 0.8 |
| 820040 | 0.5 | 0.7 |
| 820050 | 0.6 | 0.7 |
| 820500 | 0.4 | 1.5 |
| 820510 | 0.4 | 1.4 |
| 820520 | 0.3 | 1.2 |
| 820530 | 0.3 | 1.0 |
| 820540 | 0.3 | 0.9 |
| 820550 | 0.3 | 0.8 |
| 820560 | 0.4 | 0.7 |
| 820570 | 0.4 | 0.7 |
| 820800 | 0.3 | 1.0 |
| 820810 | 0.3 | 0.9 |
| 820820 | 0.3 | 0.8 |
| 820830 | 0.4 | 0.7 |
| 820840 | 0.5 | 0.7 |
| 820850 | 0.6 | 0.7 |
| 820860 | 0.7 | 0.7 |
| 820870 | 0.8 | 0.7 |
| 820880 | 0.9 | 0.8 |
| 820890 | 1.0 | 0.8 |
| 821000 | 0.3 | 1.1 |
| 821010 | 0.3 | 1.0 |
| 821020 | 0.3 | 0.9 |
| 821030 | 0.4 | 0.8 |
| 821040 | 0.5 | 0.7 |
| 821050 | 0.6 | 0.7 |
| 821060 | 0.7 | 0.7 |
| 821070 | 0.8 | 0.7 |
| 821080 | 0.9 | 0.8 |
| 821090 | 1.0 | 0.8 |
| 821300 | 0.4 | 1.7 |
| 821310 | 0.4 | 1.5 |
| 821320 | 0.3 | 1.3 |
| 821330 | 0.3 | 1.2 |
| 821340 | 0.3 | 1.0 |
| 821350 | 0.3 | 0.9 |
| 821360 | 0.3 | 0.8 |
| 821370 | 0.4 | 0.7 |
| 821380 | 0.4 | 0.7 |
| 821390 | 0.5 | 0.7 |
| 821500 | 0.4 | 1.7 |
| 821510 | 0.3 | 1.5 |
| 821520 | 0.3 | 1.3 |
| 821530 | 0.2 | 1.1 |
| 821540 | 0.2 | 1.0 |
| 821550 | 0.2 | 0.8 |
| 821560 | 0.3 | 0.8 |
| 821570 | 0.3 | 0.7 |
| 821580 | 0.4 | 0.7 |
| 821590 | 0.5 | 0.7 |
| 822100 | 0.2 | 1.1 |
| 822110 | 0.3 | 1.0 |
| 822120 | 0.3 | 0.9 |
| 822130 | 0.3 | 0.8 |
| 822140 | 0.4 | 0.7 |
| 822150 | 0.6 | 0.7 |
| 822160 | 0.7 | 0.7 |
| 822170 | 0.9 | 0.7 |
| 822180 | 1.0 | 0.8 |
| 822190 | 1.1 | 0.8 |
| 822300 | 0.3 | 1.1 |
| 822310 | 0.3 | 1.0 |
| 822320 | 0.3 | 0.9 |
| 822330 | 0.4 | 0.8 |
| 822340 | 0.5 | 0.7 |
| 822350 | 0.6 | 0.7 |
| 822360 | 0.7 | 0.7 |
| 822370 | 0.8 | 0.7 |
| 822380 | 0.9 | 0.8 |
| 822390 | 1.0 | 0.8 |

[该 so 独立提取的原始数值](数学化还原_20261114/libstrategy_comm3_1.k1_maps.json)。

## 本库全部配置字段：真实解析默认值与状态偏移

下表来自直接加载原始 `.so` 后调用其 `on_begin` 解析器；浮点字段用两个不同标记值匹配同一位置。偏移相对于策略对象起点，不是 ELF 文件偏移。Option 的 None 载荷不读取为默认数值。日志 SDK 为 no-op，其余 SDK 调用会 abort，未调用交易回调。

| 字段 | 解析值/默认状态 | 对象偏移 |
|---|---|---|
| `signal_mode` | "" | `0x40` |
| `pv1_alpha` | 1.0 | `0xa0` |
| `cost_alpha` | 1.0 | `0xa8` |
| `signal_trigger_mode` | "" | `0x58` |
| `vote_rate` | 0.1 | `0xb0` |
| `quantile` | 0.9 | `0xb8` |
| `signal_windows_s` | [] | `0x70` |
| `score_taker_rate_alpha` | 0.0 | `0xc0` |
| `taker_rate_baseline` | 0.0 | `0xc8` |
| `max_taker_rate` | 0.0 | `0xd0` |
| `high_taker_half_spread` | false | `0x1a0` |
| `taker_mult_max` | 1.0 | `0xd8` |
| `taker_cover_k` | 1.0 | `0xe0` |
| `trade_slippery` | 0.0 | `0xe8` |
| `close_position_block_ms` | 0.0 | `0xf0` |
| `touch_gate` | true | `0x1a1` |
| `touch_gate_timeout_ms` | 5000.0 | `0xf8` |
| `max_single_add_vol` | 1.0 | `0x100` |
| `max_single_add_amt` | 0.0 | `0x108` |
| `max_single_net_vol` | 1.0 | `0x110` |
| `max_single_net_amt` | 0.0 | `0x118` |
| `max_single_close_vol` | 0.0 | `0x120` |
| `max_single_close_amt` | 0.0 | `0x128` |
| `long_open_threshold` | 0.0 | `0x130` |
| `long_close_threshold` | 0.0 | `0x138` |
| `short_open_threshold` | 0.0 | `0x140` |
| `short_close_threshold` | 0.0 | `0x148` |
| `low_long_open_threshold` | None（缺省继承/无值） | `0x8` |
| `low_long_close_threshold` | None（缺省继承/无值） | `0x18` |
| `low_short_open_threshold` | None（缺省继承/无值） | `0x28` |
| `low_short_close_threshold` | None（缺省继承/无值） | `0x38` |
| `dyn_score_position_ts_threshold_s` | 0.0 | `0x150` |
| `dyn_score_max_position_ts_s` | 0.0 | `0x158` |
| `dyn_score_delta_score` | 0.0 | `0x160` |
| `use_dynamic_volspread_ratio` | false | `0x1a2` |
| `market_volatility_ms` | 60000.0 | `0x168` |
| `rolling_windows_ms` | 1200000.0 | `0x170` |
| `split_high_low_ratio_threshold` | 0.0 | `0x178` |
| `low_action` | "" | `0x88` |
| `maker_order_max_pending_time_ms` | 0.0 | `0x180` |
| `max_maker_pending_vol_on_depth` | 0.0 | `0x188` |
| `maker_ticks_inside` | 1.0 | `0x190` |
| `maker_cancel_range_levels` | 3 | `0x198` |

原始回执：[顶层解析](数学化还原_20261114/libstrategy_comm3_1.config_layout.json)；[字段数组](analysis/libstrategy_comm3_1/config_field_arrays.json)。默认字段是类型/初始化证据，不能代替历史加密配置的明文。

## 本轮机器码核验及其覆盖范围

| 原始函数/模型 | 案例数 | 通过 | 证据 |
|---|---:|---:|---|
| `point_signal_trigger_pv4` | 1200 | 1200 | [回执](数学化还原_20261114/libstrategy_comm3_1.leaf_validation.json) |
| `point_signal_trigger_pv1_spread` | 1200 | 1200 | [回执](数学化还原_20261114/libstrategy_comm3_1.leaf_validation.json) |
| `dynamic_threshold` | 288 | 288 | [回执](数学化还原_20261114/libstrategy_comm3_1.leaf_validation.json) |
| `high_taker_rate` | 1200 | 1200 | [回执](数学化还原_20261114/libstrategy_comm3_1.leaf_validation.json) |
| `VolSpreadRatio::update` | 500 | 500 | [回执](数学化还原_20261114/libstrategy_comm3_1.state_kernel_validation.json) |

本页上述新增检查合计 **4388/4388**。这是原始 ELF 叶函数/指定状态函数的合成输入检查，不能扩写为整个策略或全部历史订单的等价验收。点触发与枚举用精确比较；浮点核验容差和逐位比较范围写在脚本/回执中。

## 逐事件复现应保存的状态与尚未闭合项

每次回调记录输入时间、合约/信号标识、原信号值、盘口、SDK 持仓与在途信息；再记录变换信号、有效阈值、动作、报价类型、候选价量、撤单集合以及状态写回。对本库出现的窗口、阶段、配对树、目标任务或门控缓存，还必须记录其回调前后状态。上一个事件即使没有下单，也可能已经修改这些状态。

本轮未取得历史加密配置明文，未启动历史市场回测，未完成全部 SDK 撮合/费用/账户回报的逐事件等价重放。自动反编译的 Rust Option、复合返回值和 SIMD 临时变量不可靠；已纠正部分以本页公式与机器码探测为准，剩余不确定性在本库专属章节明确列出。本文不是能替换原 so 的完整插件源码。

## 本库业务函数证据索引

地址统一使用未重定位 ELF 虚拟地址；Ghidra C 中的 `001xxxxx` 是项目加载基址后的地址，两者不要混淆。下列索引使每个计算/回调都可回到本库证据，不用其他库的同名函数替代。

- [strategy_comm3_1::Comm3Params::signal_mode](analysis/libstrategy_comm3_1/decompiled_repaired/0000000000038e50.c)（ELF `0x38e50`，61 字节）。
- [strategy_comm3_1::Comm3Params::low_action_enum](analysis/libstrategy_comm3_1/decompiled_repaired/0000000000038fa0.c)（ELF `0x38fa0`，47 字节）。
- [strategy_comm3_1::Comm3Params::signal_trigger_mode](analysis/libstrategy_comm3_1/decompiled_repaired/0000000000038e90.c)（ELF `0x38e90`，266 字节）。
- [strategy_comm3_1::signal_trigger::SignalTrigger::update_score](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005bfc0.c)（ELF `0x5bfc0`，572 字节）。
- [strategy_comm3_1::signal_trigger::SignalTrigger::windows_rsi_trigger](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005cd90.c)（ELF `0x5cd90`，554 字节）。
- [strategy_comm3_1::signal_trigger::SignalTrigger::windows_std_trigger](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c3d0.c)（ELF `0x5c3d0`，167 字节）。
- [strategy_comm3_1::signal_trigger::SignalTrigger::windows_mean_trigger](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c320.c)（ELF `0x5c320`，167 字节）。
- [strategy_comm3_1::signal_trigger::SignalTrigger::windows_sharpe_trigger](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005cb40.c)（ELF `0x5cb40`，586 字节）。
- [strategy_comm3_1::signal_trigger::SignalTrigger::point_signal_trigger_pv4](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c290.c)（ELF `0x5c290`，141 字节）。
- [strategy_comm3_1::signal_trigger::SignalTrigger::windows_quantile_trigger](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c480.c)（ELF `0x5c480`，1717 字节）。
- [strategy_comm3_1::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005c200.c)（ELF `0x5c200`，137 字节）。
- [strategy_comm3_1::signal_trigger::dynamic_threshold](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005d530.c)（ELF `0x5d530`，152 字节）。
- [_ZN16strategy_comm3_114signal_trigger17enum_rate_counter17hb2b1659f9016b723E.llvm.12839419423354967770](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005cfc0.c)（ELF `0x5cfc0`，1378 字节）。
- [strategy_comm3_1::signal_trigger::TsQuantileCalculator::update](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005bbd0.c)（ELF `0x5bbd0`，1001 字节）。
- [strategy_comm3_1::high_taker_rate](analysis/libstrategy_comm3_1/decompiled_repaired/0000000000039da0.c)（ELF `0x39da0`，296 字节）。
- [strategy_comm3_1::vol_spread_ratio::VolSpreadRatio::update](analysis/libstrategy_comm3_1/decompiled_repaired/000000000005ec30.c)（ELF `0x5ec30`，658 字节）。
- [strategy_comm3_1::live_pending_counts](analysis/libstrategy_comm3_1/decompiled_repaired/0000000000039830.c)（ELF `0x39830`，1377 字节）。
- [strategy_comm3_1::cancel_order_use_range](analysis/libstrategy_comm3_1/decompiled_repaired/0000000000038fd0.c)（ELF `0x38fd0`，2134 字节）。
- [strategy_comm3_1::place](analysis/libstrategy_comm3_1/decompiled_repaired/000000000003da20.c)（ELF `0x3da20`，27 字节）。
- [<strategy_comm3_1::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](analysis/libstrategy_comm3_1/decompiled_repaired/0000000000039ed0.c)（ELF `0x39ed0`，840 字节）。
- [<strategy_comm3_1::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](analysis/libstrategy_comm3_1/decompiled_repaired/000000000003d720.c)（ELF `0x3d720`，475 字节）。
- [<strategy_comm3_1::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](analysis/libstrategy_comm3_1/decompiled_repaired/000000000003d900.c)（ELF `0x3d900`，280 字节）。
- [<strategy_comm3_1::StrategyComm3 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](analysis/libstrategy_comm3_1/decompiled_repaired/000000000003a220.c)（ELF `0x3a220`，13560 字节）。
- [fb_strategy_sdk_abi_version](analysis/libstrategy_comm3_1/decompiled_repaired/0000000000062fc0.c)（ELF `0x62fc0`，6 字节）。
- [fb_strategy_sdk_version_str](analysis/libstrategy_comm3_1/decompiled_repaired/0000000000062fd0.c)（ELF `0x62fd0`，73 字节）。

[完整反汇编](analysis/libstrategy_comm3_1/assembly.txt)；[核心伪代码集合](analysis/libstrategy_comm3_1/核心伪代码.c)；[原自然语言说明](自然语言详解_20261114/12_comm3_1.md)。
