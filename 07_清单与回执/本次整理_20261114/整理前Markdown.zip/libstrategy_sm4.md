# libstrategy_sm4.so：数学化还原与逐分支说明

在 sm1 报价体系上并行维护多个阈值候选的虚拟开平配对，按配对时长中位数与目标时长的距离选择四阈值。

对应原件：`libstrategy_sm4.so`，SHA-256 `4502ae763732f8da98f4e45b8585024b66c72a1aa1c5728b495583c7ceffbd44`。本文为 2026-11-14 新建的逐库数学说明，旧自然语言版保留，若有冲突以本页列出的原始函数与本轮证据为准。

## 记号、输入与可复现边界

设买一价为 $b$，卖一价为 $a$，中价 $m=(a+b)/2$；持仓 $q>0$ 表示多仓，$q<0$ 表示空仓；合约乘数为 $M$。价格步长与数量步长分别为 $\tau_p,\tau_v$。百分比、比例与 bp 不混用：$1\mathrm{bp}=10^{-4}$。`round` 表示本库调用的浮点四舍五入（中点远离零），不是 Python 的 ties-to-even。

外部信号、账户持仓、盘口和交易时间通过 SDK 输入。文中“输入主值/次值”只指信号事件的数值槽；未取得上游预测器源码时，不能把它改名为某个特定 alpha 或宣称这里重新训练了模型。本文公式首先针对有限实数、正价格与正合约乘数；NaN/Inf 的硬件比较分支不应拿普通实数代数擅自合并。

确定性分三层：**机器码实测**表示下面列出的原始 ELF 函数通过合成输入检查；**静态确定**表示已从本库反编译、常量或指令确定控制关系；**尚未闭合**表示明确缺少原始配置、SDK 语义或逐事件状态验收。配置缺省值不代表历史实验启用了该值。

## 四动作不是四个可交换判断

阈值向量按内存顺序定义为

$$T=(L_o,L_c,S_o,S_c).$$

有限输入的分类器严格按以下顺序执行：

$$A(x,T)=\begin{cases}
0\ (开多),&x\ge L_o,\\
3\ (平空),&x<L_o\land x\ge S_c,\\
2\ (开空),&x<L_o\land x<S_c\land x\le S_o,\\
1\ (平多),&x<L_o\land x<S_c\land x>S_o\land x\le L_c,\\
4\ (无动作),&\text{其余}.
\end{cases}$$

先判断开多，再平空，再开空，最后平多。即使配置了交叠阈值也不排序、不纠正。例如四阈值全为零且 $x=0$，结果是开多，不是无动作。动作确定后还要受仓位、盘口、撤单与账户接口约束；“开多”可能先买回空仓，不能把整个订单量记作新增多仓。

错误/无结果与无动作也不能合并：若触发器返回错误变体，调用者走错误/提前返回分支；枚举 4 是成功计算出的“不交易”。

## 信号带触发：不能替换为普通信号扣成本

触发器除最后信号 $s$ 外，还保存 `+0x80` 的 $B_+$ 和 `+0x88` 的 $B_-$。`update_score` 的赋值为

$$B_+=s+k_+\sigma_c,\qquad B_-=s-k_-\sigma_c,$$

同时另存 $\mu+k_+\sigma_c$ 和 $\mu-k_-\sigma_c$。$\mu,\sigma_c$ 来自被选窗口；$\sigma_c$ 明确是缓存字段，不能无条件假定本次回调重算了真实标准差。指定窗口键缺失或没有窗口时，相关赋值分支不发生；没有指定键时使用 HashMap 中取到的窗口，不得擅自解释为最短窗口。

成本项为 $c=\min(\alpha_c|h|,c_{cap})$。触发值是

$$x=\begin{cases}\max(B_-+c,0),&s>0,\\\min(B_+-c,0),&s\le0.\end{cases}$$

再返回 $(A(x,T),1)$。注意正信号分支是**下界加成本**，负信号分支是**上界减成本**，与普通 PV1 的方向不同。这不是本文的经济学设计，而是本库原始函数的条件和加减号。若把 $B_\pm$ 直接设为 $s$，也不能据此删掉 `min` 成本上限或改变加减号。

## 持仓年龄动态阈值

令 $h_p$ 为传入的持仓秒数，$t_0,t_1,\Delta$ 分别对应 `dyn_score_position_ts_threshold_s`、`dyn_score_max_position_ts_s`、`dyn_score_delta_score`。

$$d=\begin{cases}
0,&t_0<0\lor t_1<0\lor h_p<t_0\lor |\Delta|\le10^{-9},\\
\left|\Delta\min\left(\frac{h_p-t_0}{\max(t_1-t_0,10^{-6})},1\right)\right|,&\text{其余}.
\end{cases}$$

$$T'=(L_o-d,L_c+d,S_o+d,S_c-d).$$

四个门槛均变化，且负的 $\Delta$ 也产生非负 $d$。$t_1\le t_0$ 不会报错，而使用 $10^{-6}$ 的分母下限。$h_p=t_0$ 时增量为零；超过终点后饱和。以上是独立 `dynamic_threshold` 的行为，不能套到 LF4/TM5/TM6/SoS6 的内联旧逻辑上。

## 时间窗口触发与投票

每个窗口维护 $(t_i,s_i)$ 队列及 $N,\sum s_i,\sum s_i^2,\sum_{s_i>0}s_i,\sum_{s_i\le0}s_i$。插入当前点后，删除所有 $t-t_i>W$ 的旧点；恰好位于 $t-W$ 的点保留。更新按加减旧值进行，不能随意改为重新求和后声称浮点逐位等价。

$$\mu=\frac{\sum s_i}{N},\qquad \sigma=\sqrt{\max(\sum s_i^2/\max(N,1)-\mu^2,0)}.$$

均值触发把 $\mu$ 送入四阈值比较。Sharpe 触发使用 $\mu/\sigma$，$|\sigma|\le10^{-6}$ 时取零；这是信号窗口统计量，不是策略收益夏普。RSI 使用信号正负值的累计量，令 $P=\sum_{s_i>0}s_i,N_-=\sum_{s_i\le0}s_i$：

$$R=\begin{cases}100-\frac{100}{P/|N_-|+1},&|N_-|>10^{-6},\\50,&\text{其余}.\end{cases}$$

特别注意：`update` 写入和、平方和和均值，但不会自动重算所有版本的 `std_cache`。`WindowsStdTrigger` 读的是缓存槽，不能无条件用上式即时标准差替代；Sharpe 分支另有重算行为。信号带同样需要保留缓存的实际更新顺序。

分位数按有序观测的整数下标取值，使用 $\lfloor qN\rfloor$ 与 $\lfloor(1-q)N\rfloor$，不是线性插值；端点越界可返回错误。多窗口先形成各自候选动作，再计票，最高票比例必须**严格大于** `vote_rate`。并列候选涉及 HashMap 遍历，不应凭业务偏好增加“多头优先”或“平仓优先”。本节是对应窗口函数的静态说明；本轮新增的全库实测不包括每一种窗口的完整状态序列。

## Taker / Maker / Mid 的报价分段

令输入两侧信号值为 $s_-,s_+$，并定义动作超额（先四舍五入至 0.01）：

$$E=\operatorname{round}_{0.01}\begin{cases}s_+-L_o,&A=0,\\L_c-s_-,&A=1,\\S_o-s_-,&A=2,\\s_+-S_c,&A=3.\end{cases}$$

报价函数内部半价差（四舍五入至 0.1 bp）为

$$H=\operatorname{round}_{0.1}\left(\frac{a-b}{m}\frac{10^4}{2}\right).$$

若 $E>H$，类型为 Taker(0)，$r=\max(r_{base},\min(r_{max},10^{-4}(E-H)))$，买价 $a(1+r)$、卖价 $b(1-r)$。先 `min` 后 `max`，基准值大于上限时最终可以超过所谓上限，不能调换顺序。

若 $E\le H$ 且 $E\le0$，类型为 Maker(1)，本库实测**买卖两边都返回**

$$p=\min(b+0.2,a-0.2).$$

0.2 是 ELF 中的常量，不是传入 tick；卖出分支也执行 `min`，不能按常见 maker 直觉改成 `max`。当价差小于 0.4 时该辅助函数可能报到买一以下，后续步长与订单接口才处理最终请求。

若 $0<E\le H$，类型为 Mid(2)，$p=m$。因此在等号 $E=H>0$ 时仍是 Mid，不是 Taker。以上为 SM1/SM4 原始函数直接调用比对通过的分段；不套用到带附加 B 分支的 SM3/SM3.1。

## Rust 复合返回值与盘口数量上限

`get_quote_vol` 的 `RAX=1` 表示存在返回值，真正数量从 `XMM0` 返回。设原请求为 $v$，传入 cap 为 $C$，布尔开关为 $g$：

$$V(v,Q,g,C)=\begin{cases}
v,&Q=0,\\
\operatorname{sign}(v)\min(|v|,C),&Q\in\{1,2\}\land g,\\
v,&Q\in\{1,2\}\land\neg g,\\
0,&Q=3\ (Skip).
\end{cases}$$

这解释了为何反编译 C 中连续出现 `return 1` 不能推断每次只下一手。随后 `apply_book_vol_cap` 的主动分支使用报价覆盖的对手五档累计量；当 `book_vol_cap=false` 时该盘口 cap 视为无限，但正的 `max_single_taker_vol` 仍可截断。被动类型 1/2 在 `book_vol_cap=false` 时直接返回原请求，因而该函数内部的 maker 盘口 cap 与进一步 maker cap 都不会执行；启用时采用本方前三档有效价格数量均值，并结合正 maker cap 限制。最后保留买卖符号并按数量步长处理。

## 阈值候选树、虚拟开平配对与中位数选择

这是对信号阈值的虚拟配对统计，不是对实际成交订单计算持仓收益。每个候选 $j$ 和合约 $c$ 保存独立状态 $U$（未开）、$L(t_o,s_o)$（虚拟多）、$S(t_o,s_o)$（虚拟空）。未开状态先判断 $s\ge L_o$ 建立多记录，否则判断 $s\le S_o$ 建立空记录；已有多记录在 $s\le L_c$ 时闭合，已有空记录在 $s\ge S_c$ 时闭合。先处理已有记录的闭合，再执行未开状态检查，因此同一输入可能闭合后重新建立一条记录；不能擅自加“本事件不再开”的限制。闭合记录进入毫秒滚动队列，记录开闭时刻和信号值；未闭合记录不能伪装成零时长样本。

候选按配置 $\delta=\text{score_thresholds_delta}$、$n=\text{score_thresholds_num}$ 建立。除原始 $T_0$ 外，每个 $i=1,\dots,n$ 生成两组，经本库 round 精度处理：

$$T_{i,+}=(L_o+i\delta,L_c-i\delta,S_o-i\delta,S_c+i\delta),$$
$$T_{i,-}=(L_o-i\delta,L_c+i\delta,S_o+i\delta,S_c-i\delta).$$

正向组同时拉大开平跨度，负向组缩小跨度；不是简单给全部阈值加同一个数。键 0 为原始组，后续正负组按插入顺序获得正整数键。

令窗口中完成配对的时长集合为 $D_j$。空集返回 None；排序后奇数样本取中间项，偶数样本取中间两项平均。目标时长为 $H_*$，选择

$$j^*=\arg\min_{j:D_j\ne\varnothing}|\operatorname{median}(D_j)-H_*|.$$

实际实现有额外门槛：先查键 0；键 0 本身没有有效中位数时直接回退原始阈值，**不会**继续寻找其他已经有样本的候选。键 0 不存在则进入 unwrap 错误路径。键 0 有样本才遍历候选，用严格更小 `<` 更新最优，因此同距离不会覆盖先遇到的键。BTreeMap 的有序遍历与 HashMap 的随机遍历不可混淆。

更新、选择、实际交易是三个状态层次。候选得到的虚拟配对中位数接近目标，不表示真实成交平均持仓时长等于目标；盘口、在途订单、保证金和成交失败都可造成差异。此部分已追到候选构建、update、median 与选择函数；完整多合约事件回放仍未验收。

## SM4 的自适应对象与默认候选数

自适应的是四个动作阈值，不是信号模型系数或每个品种的收益排名。默认 `score_thresholds_delta=0.2`、`score_thresholds_num=2`，因此原始组加两对正负变体共 5 组；配对滚动窗口 1200000ms、目标持仓时长 60000ms。

`score_thresholds_num` 在本库是位于 `+0x1b8` 的 32 位整数，紧邻 `touch_gate/book_vol_cap` 两个字节。按 64 位整数读取会把布尔位混入，得到错误候选数；本轮重新按 u32 探测已纠正。

选出的四阈值进入 SM 型触发与报价层，价格函数仍是本页实测的 SM1/SM4 三段规则；数量层仍有 Taker/Maker/Mid 的 cap 差异。即使配对候选树与 TM6 相同，SM4 的订单价格类型与 TM6 主动路径不同，不能把两者整个库视为等价。

## 数量、金额与订单请求的层次

所有数量计算都必须区分当前净持仓 $q$、本次有符号请求 $v$、在途预占和最终成交量。对使用金额上限的分支，金额换算以实际选择的订单价格 $p$ 和合约乘数 $M$ 进行，数学上为 $A/(pM)$；原指令常按 `(A/p)/M` 连续除法，逐位复现不能随意改为先乘分母。

负的风险额度在相应限额分支转换为 $+\infty$；零是真实约束。`max_single_add_vol/amt` 约束新增部分，`max_single_net_vol/amt` 约束方向净敞口，`max_single_close_vol/amt` 约束旧反向仓位的平仓部分。开仓动作可以把“新方向允许增量”和“允许平掉的反向旧仓”相加；纯平仓动作不应允许越过零仓继续反向开仓。具体分支中的 `max(amount/(pM),1)` 会形成至少一手的中间额度，但最后仍受其他 cap 和数量步长限制。

实际订单前还有 SDK `margin_filter`、`impact_block_check`、交易时段、允许合约/信号和在途订单检查。它们是可见的调用边界，不能用“所有条件都通过”代替未知历史账户状态。价格与数量最终经过 `round_with_step_f64`；本文保留函数调用及 mode，而不把所有 mode 都武断解释为向下取整。IOC、IAP 或带 target 的 IAP 请求如何被撮合，属于通用引擎和账户模型。

因此复现输出应先比较 `(动作、报价类型、请求价、请求量、撤单ID序列、状态更新)`；仅比较最终收益曲线无法证明这些分支相同。

## 本库全部配置字段：真实解析默认值与状态偏移

下表来自直接加载原始 `.so` 后调用其 `on_begin` 解析器；浮点字段用两个不同标记值匹配同一位置。偏移相对于策略对象起点，不是 ELF 文件偏移。Option 的 None 载荷不读取为默认数值。日志 SDK 为 no-op，其余 SDK 调用会 abort，未调用交易回调。

| 字段 | 解析值/默认状态 | 对象偏移 |
|---|---|---|
| `signal_mode` | "PV1" | `0x58` |
| `pv1_alpha` | 1.0 | `0xb8` |
| `cost_alpha` | 1.0 | `0xc0` |
| `signal_trigger_mode` | "PointTrigger" | `0x70` |
| `vote_rate` | 0.1 | `0xc8` |
| `quantile` | 0.9 | `0xd0` |
| `signal_windows_s` | [] | `0x88` |
| `taker_rate_baseline` | 0.0 | `0xd8` |
| `max_taker_rate` | 0.0 | `0xe0` |
| `trade_slippery` | 0.0 | `0xe8` |
| `close_position_block_ms` | 0.0 | `0xf0` |
| `max_single_add_vol` | -1.0 | `0xf8` |
| `max_single_add_amt` | -1.0 | `0x100` |
| `max_single_net_vol` | -1.0 | `0x108` |
| `max_single_net_amt` | -1.0 | `0x110` |
| `max_single_close_vol` | -1.0 | `0x118` |
| `max_single_close_amt` | -1.0 | `0x120` |
| `long_open_threshold` | 0.0 / 0.0 | `0x8`, `0x128` |
| `long_close_threshold` | 0.0 / 0.0 | `0x10`, `0x130` |
| `short_open_threshold` | 0.0 / 0.0 | `0x18`, `0x138` |
| `short_close_threshold` | 0.0 / 0.0 | `0x20`, `0x140` |
| `dyn_score_position_ts_threshold_s` | 0.0 | `0x148` |
| `dyn_score_max_position_ts_s` | 0.0 | `0x150` |
| `dyn_score_delta_score` | 0.0 | `0x158` |
| `dyn_pending_position_ts_threshold_s` | 0.0 | `0x160` |
| `dyn_pending_max_position_ts_s` | 0.0 | `0x168` |
| `dyn_pending_delta_max_pending_ts_ms` | 0.0 | `0x170` |
| `order_max_pending_time_ms` | 0.0 | `0x178` |
| `max_maker_pending_vol_on_depth` | 0.0 | `0x180` |
| `max_maker_limit_rate_bias_from_mid` | 0.0 | `0x188` |
| `pair_rolling_window_ms` | 1200000.0 | `0x190` |
| `pair_target_holding_period_ms` | 60000.0 | `0x198` |
| `score_thresholds_delta` | 0.2 | `0x1a0` |
| `score_thresholds_num` | 2 | `0x1b8` |
| `signal_all` | "" | `0xa0` |
| `touch_gate` | true | `0x1bc` |
| `touch_gate_timeout_ms` | 5000.0 | `0x1a8` |
| `book_vol_cap` | true | `0x1bd` |
| `max_single_taker_vol` | 0.0 | `0x1b0` |

原始回执：[顶层解析](数学化还原_20261114/libstrategy_sm4.config_layout.json)；[字段数组](analysis/libstrategy_sm4/config_field_arrays.json)。默认字段是类型/初始化证据，不能代替历史加密配置的明文。

## 本轮机器码核验及其覆盖范围

| 原始函数/模型 | 案例数 | 通过 | 证据 |
|---|---:|---:|---|
| `point_signal_trigger_pv3_spread` | 1200 | 1200 | [回执](数学化还原_20261114/libstrategy_sm4.leaf_validation.json) |
| `dynamic_threshold` | 288 | 288 | [回执](数学化还原_20261114/libstrategy_sm4.leaf_validation.json) |
| 报价价格＋类型分段 | 1200 | 1200 | [回执](数学化还原_20261114/libstrategy_sm4.quote_price_validation.json) |

本页上述新增检查合计 **2688/2688**。这是原始 ELF 叶函数/指定状态函数的合成输入检查，不能扩写为整个策略或全部历史订单的等价验收。点触发与枚举用精确比较；浮点核验容差和逐位比较范围写在脚本/回执中。

[数量返回寄存器矩阵](数学化还原_20261114/libstrategy_sm4.quote_volume_matrix.json)另外覆盖 4 种报价类型、开关两值、正负及零数量，共 40 个组合。

## 逐事件复现应保存的状态与尚未闭合项

每次回调记录输入时间、合约/信号标识、原信号值、盘口、SDK 持仓与在途信息；再记录变换信号、有效阈值、动作、报价类型、候选价量、撤单集合以及状态写回。对本库出现的窗口、阶段、配对树、目标任务或门控缓存，还必须记录其回调前后状态。上一个事件即使没有下单，也可能已经修改这些状态。

本轮未取得历史加密配置明文，未启动历史市场回测，未完成全部 SDK 撮合/费用/账户回报的逐事件等价重放。自动反编译的 Rust Option、复合返回值和 SIMD 临时变量不可靠；已纠正部分以本页公式与机器码探测为准，剩余不确定性在本库专属章节明确列出。本文不是能替换原 so 的完整插件源码。

## 本库业务函数证据索引

地址统一使用未重定位 ELF 虚拟地址；Ghidra C 中的 `001xxxxx` 是项目加载基址后的地址，两者不要混淆。下列索引使每个计算/回调都可回到本库证据，不用其他库的同名函数替代。

- [strategy_sm4::cancel_side](analysis/libstrategy_sm4/decompiled_repaired/000000000003ec90.c)（ELF `0x3ec90`，922 字节）。
- [strategy_sm4::default_pv1](analysis/libstrategy_sm4/decompiled_repaired/000000000003ebc0.c)（ELF `0x3ebc0`，87 字节）。
- [_ZN12strategy_sm417signal_pairs_tree15SignalPairStats28get_pairs_time_sec_ms_median17hd03f3837d95f7339E.llvm.4719369549894925764](analysis/libstrategy_sm4/decompiled_repaired/0000000000063b60.c)（ELF `0x63b60`，404 字节）。
- [strategy_sm4::signal_pairs_tree::SignalPairsTree::debug_string](analysis/libstrategy_sm4/decompiled_repaired/0000000000065300.c)（ELF `0x65300`，1553 字节）。
- [strategy_sm4::signal_pairs_tree::SignalPairsTree::find_nearest_pair_median_threshold](analysis/libstrategy_sm4/decompiled_repaired/00000000000650a0.c)（ELF `0x650a0`，595 字节）。
- [strategy_sm4::signal_pairs_tree::SignalPairsTree::new](analysis/libstrategy_sm4/decompiled_repaired/0000000000063d00.c)（ELF `0x63d00`，1656 字节）。
- [strategy_sm4::signal_pairs_tree::SignalPairsTree::update](analysis/libstrategy_sm4/decompiled_repaired/0000000000064380.c)（ELF `0x64380`，3354 字节）。
- [strategy_sm4::signal_pairs_tree::RollingmsQueue<T>::update](analysis/libstrategy_sm4/decompiled_repaired/00000000000639d0.c)（ELF `0x639d0`，386 字节）。
- [strategy_sm4::apply_book_vol_cap](analysis/libstrategy_sm4/decompiled_repaired/000000000003fa10.c)（ELF `0x3fa10`，720 字节）。
- [strategy_sm4::live_pending_counts](analysis/libstrategy_sm4/decompiled_repaired/000000000003f4a0.c)（ELF `0x3f4a0`，1377 字节）。
- [strategy_sm4::default_point_trigger](analysis/libstrategy_sm4/decompiled_repaired/000000000003ec20.c)（ELF `0x3ec20`，98 字节）。
- [strategy_sm4::cancel_order_use_range](analysis/libstrategy_sm4/decompiled_repaired/000000000003f030.c)（ELF `0x3f030`，1121 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::update_score](analysis/libstrategy_sm4/decompiled_repaired/0000000000091850.c)（ELF `0x91850`，588 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_rsi_trigger](analysis/libstrategy_sm4/decompiled_repaired/0000000000092680.c)（ELF `0x92680`，555 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_std_trigger](analysis/libstrategy_sm4/decompiled_repaired/0000000000091c70.c)（ELF `0x91c70`，265 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_mean_trigger](analysis/libstrategy_sm4/decompiled_repaired/0000000000091b60.c)（ELF `0x91b60`，265 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_sharpe_trigger](analysis/libstrategy_sm4/decompiled_repaired/0000000000092430.c)（ELF `0x92430`，587 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::windows_quantile_trigger](analysis/libstrategy_sm4/decompiled_repaired/0000000000091d80.c)（ELF `0x91d80`，1702 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::point_signal_trigger_pv3_spread](analysis/libstrategy_sm4/decompiled_repaired/0000000000091aa0.c)（ELF `0x91aa0`，178 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::new](analysis/libstrategy_sm4/decompiled_repaired/0000000000091780.c)（ELF `0x91780`，199 字节）。
- [strategy_signal_maker_common::signal_trigger::dynamic_threshold](analysis/libstrategy_sm4/decompiled_repaired/0000000000092e30.c)（ELF `0x92e30`，152 字节）。
- [strategy_signal_maker_common::signal_trigger::enum_rate_counter](analysis/libstrategy_sm4/decompiled_repaired/00000000000928b0.c)（ELF `0x928b0`，1394 字节）。
- [strategy_signal_maker_common::signal_trigger::TsQuantileCalculator::update](analysis/libstrategy_sm4/decompiled_repaired/0000000000091520.c)（ELF `0x91520`，598 字节）。
- [strategy_signal_maker_common::signal_trigger::dynamic_pending_ts_ms](analysis/libstrategy_sm4/decompiled_repaired/0000000000092ed0.c)（ELF `0x92ed0`，63 字节）。
- [strategy_signal_maker_common::get_quote_price::get_quote_vol](analysis/libstrategy_sm4/decompiled_repaired/000000000008f910.c)（ELF `0x8f910`，135 字节）。
- [strategy_signal_maker_common::get_quote_price::get_quote_price](analysis/libstrategy_sm4/decompiled_repaired/000000000008f9a0.c)（ELF `0x8f9a0`，1978 字节）。
- [<strategy_sm4::StrategySM4 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](analysis/libstrategy_sm4/decompiled_repaired/000000000003fce0.c)（ELF `0x3fce0`，2161 字节）。
- [<strategy_sm4::StrategySM4 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](analysis/libstrategy_sm4/decompiled_repaired/0000000000040560.c)（ELF `0x40560`，11554 字节）。
- [fb_strategy_sdk_abi_version](analysis/libstrategy_sm4/decompiled_repaired/00000000000686f0.c)（ELF `0x686f0`，6 字节）。
- [fb_strategy_sdk_version_str](analysis/libstrategy_sm4/decompiled_repaired/0000000000068700.c)（ELF `0x68700`，73 字节）。

[完整反汇编](analysis/libstrategy_sm4/assembly.txt)；[核心伪代码集合](analysis/libstrategy_sm4/核心伪代码.c)；[原自然语言说明](自然语言详解_20261114/24_sm4.md)。
