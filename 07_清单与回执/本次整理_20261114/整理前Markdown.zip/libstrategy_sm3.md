# libstrategy_sm3.so：数学化还原与逐分支说明

使用主信号 A 决定动作，附加信号 B 决定被动报价如何偏移或跳过的一次性决策版本。B 不是简单乘到 A 上。

对应原件：`libstrategy_sm3.so`，SHA-256 `fae00455457a8cbf18a8d048211a5a7192c1554fcb1c94d43754dabebc527cc5`。本文为 2026-11-14 新建的逐库数学说明，旧自然语言版保留，若有冲突以本页列出的原始函数与本轮证据为准。

## 记号、输入与可复现边界

设买一价为 $b$，卖一价为 $a$，中价 $m=(a+b)/2$；持仓 $q>0$ 表示多仓，$q<0$ 表示空仓；合约乘数为 $M$。价格步长与数量步长分别为 $\tau_p,\tau_v$。百分比、比例与 bp 不混用：$1\mathrm{bp}=10^{-4}$。`round` 表示本库调用的浮点四舍五入（中点远离零），不是 Python 的 ties-to-even。

外部信号、账户持仓、盘口和交易时间通过 SDK 输入。文中“输入主值/次值”只指信号事件的数值槽；未取得上游预测器源码时，不能把它改名为某个特定 alpha 或宣称这里重新训练了模型。本文公式首先针对有限实数、正价格与正合约乘数；NaN/Inf 的硬件比较分支不应拿普通实数代数擅自合并。

确定性分三层：**机器码实测**表示下面列出的原始 ELF 函数通过合成输入检查；**静态确定**表示已从本库反编译、常量或指令确定控制关系；**尚未闭合**表示明确缺少原始配置、SDK 语义或逐事件状态验收。配置缺省值不代表历史实验启用了该值。

## 四动作不是四个可交换判断

阈值向量按内存顺序定义为

$$T=(L_o,L_c,S_o,S_c).$$

有限输入的分类器严格按以下顺序执行：

$$A(x,T)=\begin{cases}
0\ (开多),&x\ge L_o,\\
3\ (平空),&x<L_o\land x\ge S_c,\\
2\ (开空),&x<L_o\land x<S_c\land x\le S_o,\\
1\ (平多),&x<L_o\land x<S_c\land x>S_o\land x\le L_c,\\
4\ (无动作),&\text{其余}.
\end{cases}$$

先判断开多，再平空，再开空，最后平多。即使配置了交叠阈值也不排序、不纠正。例如四阈值全为零且 $x=0$，结果是开多，不是无动作。动作确定后还要受仓位、盘口、撤单与账户接口约束；“开多”可能先买回空仓，不能把整个订单量记作新增多仓。

错误/无结果与无动作也不能合并：若触发器返回错误变体，调用者走错误/提前返回分支；枚举 4 是成功计算出的“不交易”。

## 信号带触发：不能替换为普通信号扣成本

触发器除最后信号 $s$ 外，还保存 `+0x80` 的 $B_+$ 和 `+0x88` 的 $B_-$。`update_score` 的赋值为

$$B_+=s+k_+\sigma_c,\qquad B_-=s-k_-\sigma_c,$$

同时另存 $\mu+k_+\sigma_c$ 和 $\mu-k_-\sigma_c$。$\mu,\sigma_c$ 来自被选窗口；$\sigma_c$ 明确是缓存字段，不能无条件假定本次回调重算了真实标准差。指定窗口键缺失或没有窗口时，相关赋值分支不发生；没有指定键时使用 HashMap 中取到的窗口，不得擅自解释为最短窗口。

成本项为 $c=\min(\alpha_c|h|,c_{cap})$。触发值是

$$x=\begin{cases}\max(B_-+c,0),&s>0,\\\min(B_+-c,0),&s\le0.\end{cases}$$

再返回 $(A(x,T),1)$。注意正信号分支是**下界加成本**，负信号分支是**上界减成本**，与普通 PV1 的方向不同。这不是本文的经济学设计，而是本库原始函数的条件和加减号。若把 $B_\pm$ 直接设为 $s$，也不能据此删掉 `min` 成本上限或改变加减号。

## 持仓年龄动态阈值

令 $h_p$ 为传入的持仓秒数，$t_0,t_1,\Delta$ 分别对应 `dyn_score_position_ts_threshold_s`、`dyn_score_max_position_ts_s`、`dyn_score_delta_score`。

$$d=\begin{cases}
0,&t_0<0\lor t_1<0\lor h_p<t_0\lor |\Delta|\le10^{-9},\\
\left|\Delta\min\left(\frac{h_p-t_0}{\max(t_1-t_0,10^{-6})},1\right)\right|,&\text{其余}.
\end{cases}$$

$$T'=(L_o-d,L_c+d,S_o+d,S_c-d).$$

四个门槛均变化，且负的 $\Delta$ 也产生非负 $d$。$t_1\le t_0$ 不会报错，而使用 $10^{-6}$ 的分母下限。$h_p=t_0$ 时增量为零；超过终点后饱和。以上是独立 `dynamic_threshold` 的行为，不能套到 LF4/TM5/TM6/SoS6 的内联旧逻辑上。

## Rust 复合返回值与盘口数量上限

`get_quote_vol` 的 `RAX=1` 表示存在返回值，真正数量从 `XMM0` 返回。设原请求为 $v$，传入 cap 为 $C$，布尔开关为 $g$：

$$V(v,Q,g,C)=\begin{cases}
v,&Q=0,\\
\operatorname{sign}(v)\min(|v|,C),&Q\in\{1,2\}\land g,\\
v,&Q\in\{1,2\}\land\neg g,\\
0,&Q=3\ (Skip).
\end{cases}$$

这解释了为何反编译 C 中连续出现 `return 1` 不能推断每次只下一手。随后 `apply_book_vol_cap` 的主动分支使用报价覆盖的对手五档累计量；当 `book_vol_cap=false` 时该盘口 cap 视为无限，但正的 `max_single_taker_vol` 仍可截断。被动类型 1/2 在 `book_vol_cap=false` 时直接返回原请求，因而该函数内部的 maker 盘口 cap 与进一步 maker cap 都不会执行；启用时采用本方前三档有效价格数量均值，并结合正 maker cap 限制。最后保留买卖符号并按数量步长处理。

## A/B 一次性报价的完整数学分段

A 产生动作，B 由 `maker_signal_abtype_u` 指定来源，并与 `maker_signal_threshold` 比较后形成 $d_B\in\{-1,0,1\}$。缺省 B 来源为 None，状态 `+0x30` 存 Option 哨兵，不是空字符串。

令买侧（动作 0/3）方向 $d=+1$，卖侧（1/2）$d=-1$，方向化 B 为 $z=d\,d_B$。动作超额先 round 至 0.01：

$$E=\operatorname{round}_{0.01}\begin{cases}s_+-L_o,&A=0,\\L_c-s_-,&A=1,\\S_o-s_-,&A=2,\\s_+-S_c,&A=3.\end{cases}$$

半价差 $H=\operatorname{round}_{0.1}(10^4(a-b)/(2m))$。定义本库 maker 候选

$$p_M=\begin{cases}\min(b+0.2,a-0.2),&d=+1,\\\max(a-0.2,b+0.2),&d=-1.\end{cases}$$

这次卖侧是 **max**，与 SM1/SM4 的两侧 min 不同。B 门控后的完整优先级为：

| 优先级 | 条件 | 类型、价格 |
|---|---|---|
| 1 | $z<0$ | Maker，$p_M$；即使 $E>H$ 也不走主动 |
| 2 | $z\ge0$ 且 $E>H$ | Taker，见下式 |
| 3 | 前两项不满足且 $E>0$ | Mid，$m$ |
| 4 | $E\le0$ 且 $z=0$ | Maker，$p_M$ |
| 5 | $E\le0$ 且 $z>0$ | Skip，保留计算出的候选价但数量函数置零 |

主动比例 $r=\max(r_{base},\min(r_{max},10^{-4}(E-H)))$，买价 $a(1+r)$、卖价 $b(1-r)$。最后一行的候选价是

$$p_{skip}=m[1-d\cdot10^{-4}\min(|E|,10^4r_{bias})].$$

该价仍写入返回结构，但类型为 3，不能因为看见一个有效数值价格就以为真的挂了这笔单。这里的全部四动作、B 三态与超额分段已通过 2400 个随机有限值案例；另存 60 个可读边界矩阵。$E=H>0$ 属于 Mid，$E=0,z>0$ 属于 Skip。

顶层没有 SM1 的完整窗口触发参数组，也没有 SM3.1 的 B 缓存寿命、A 等待 barrier、veto scope 等显式配置。B 到达与消费的状态仍须按本库回调顺序保留，不能把 SM3.1 的等待规则添加到这里。

## 数量、金额与订单请求的层次

所有数量计算都必须区分当前净持仓 $q$、本次有符号请求 $v$、在途预占和最终成交量。对使用金额上限的分支，金额换算以实际选择的订单价格 $p$ 和合约乘数 $M$ 进行，数学上为 $A/(pM)$；原指令常按 `(A/p)/M` 连续除法，逐位复现不能随意改为先乘分母。

负的风险额度在相应限额分支转换为 $+\infty$；零是真实约束。`max_single_add_vol/amt` 约束新增部分，`max_single_net_vol/amt` 约束方向净敞口，`max_single_close_vol/amt` 约束旧反向仓位的平仓部分。开仓动作可以把“新方向允许增量”和“允许平掉的反向旧仓”相加；纯平仓动作不应允许越过零仓继续反向开仓。具体分支中的 `max(amount/(pM),1)` 会形成至少一手的中间额度，但最后仍受其他 cap 和数量步长限制。

实际订单前还有 SDK `margin_filter`、`impact_block_check`、交易时段、允许合约/信号和在途订单检查。它们是可见的调用边界，不能用“所有条件都通过”代替未知历史账户状态。价格与数量最终经过 `round_with_step_f64`；本文保留函数调用及 mode，而不把所有 mode 都武断解释为向下取整。IOC、IAP 或带 target 的 IAP 请求如何被撮合，属于通用引擎和账户模型。

因此复现输出应先比较 `(动作、报价类型、请求价、请求量、撤单ID序列、状态更新)`；仅比较最终收益曲线无法证明这些分支相同。

## 本库全部配置字段：真实解析默认值与状态偏移

下表来自直接加载原始 `.so` 后调用其 `on_begin` 解析器；浮点字段用两个不同标记值匹配同一位置。偏移相对于策略对象起点，不是 ELF 文件偏移。Option 的 None 载荷不读取为默认数值。日志 SDK 为 no-op，其余 SDK 调用会 abort，未调用交易回调。

| 字段 | 解析值/默认状态 | 对象偏移 |
|---|---|---|
| `signal_mode` | "PV1" | `0x0` |
| `pv1_alpha` | 1.0 | `0x48` |
| `cost_alpha` | 1.0 | `0x50` |
| `taker_rate_baseline` | 0.0 | `0x58` |
| `max_taker_rate` | 0.0 | `0x60` |
| `trade_slippery` | 0.0 | `0x68` |
| `close_position_block_ms` | 0.0 | `0x70` |
| `max_single_add_vol` | -1.0 | `0x78` |
| `max_single_add_amt` | -1.0 | `0x80` |
| `max_single_net_vol` | -1.0 | `0x88` |
| `max_single_net_amt` | -1.0 | `0x90` |
| `max_single_close_vol` | -1.0 | `0x98` |
| `max_single_close_amt` | -1.0 | `0xa0` |
| `long_open_threshold` | 0.0 | `0xa8` |
| `long_close_threshold` | 0.0 | `0xb0` |
| `short_open_threshold` | 0.0 | `0xb8` |
| `short_close_threshold` | 0.0 | `0xc0` |
| `dyn_score_position_ts_threshold_s` | 0.0 | `0xc8` |
| `dyn_score_max_position_ts_s` | 0.0 | `0xd0` |
| `dyn_score_delta_score` | 0.0 | `0xd8` |
| `dyn_pending_position_ts_threshold_s` | 0.0 | `0xe0` |
| `dyn_pending_max_position_ts_s` | 0.0 | `0xe8` |
| `dyn_pending_delta_max_pending_ts_ms` | 0.0 | `0xf0` |
| `order_max_pending_time_ms` | 0.0 | `0xf8` |
| `max_maker_pending_vol_on_depth` | 0.0 | `0x100` |
| `max_maker_limit_rate_bias_from_mid` | 0.0 | `0x108` |
| `maker_signal_abtype_u` | None（Option 哨兵） | `0x30` |
| `maker_signal_threshold` | 0.0 | `0x110` |
| `signal_all` | "" | `0x18` |
| `touch_gate` | true | `0x128` |
| `touch_gate_timeout_ms` | 5000.0 | `0x118` |
| `book_vol_cap` | true | `0x129` |
| `max_single_taker_vol` | 0.0 | `0x120` |

原始回执：[顶层解析](数学化还原_20261114/libstrategy_sm3.config_layout.json)；[字段数组](analysis/libstrategy_sm3/config_field_arrays.json)。默认字段是类型/初始化证据，不能代替历史加密配置的明文。

## 本轮机器码核验及其覆盖范围

| 原始函数/模型 | 案例数 | 通过 | 证据 |
|---|---:|---:|---|
| `point_signal_trigger_pv3_spread` | 1200 | 1200 | [回执](数学化还原_20261114/libstrategy_sm3.leaf_validation.json) |
| `dynamic_threshold` | 288 | 288 | [回执](数学化还原_20261114/libstrategy_sm3.leaf_validation.json) |
| 报价价格＋类型分段 | 2400 | 2400 | [回执](数学化还原_20261114/libstrategy_sm3.quote_price_validation.json) |

本页上述新增检查合计 **3888/3888**。这是原始 ELF 叶函数/指定状态函数的合成输入检查，不能扩写为整个策略或全部历史订单的等价验收。点触发与枚举用精确比较；浮点核验容差和逐位比较范围写在脚本/回执中。

[数量返回寄存器矩阵](数学化还原_20261114/libstrategy_sm3.quote_volume_matrix.json)另外覆盖 4 种报价类型、开关两值、正负及零数量，共 40 个组合。

## 逐事件复现应保存的状态与尚未闭合项

每次回调记录输入时间、合约/信号标识、原信号值、盘口、SDK 持仓与在途信息；再记录变换信号、有效阈值、动作、报价类型、候选价量、撤单集合以及状态写回。对本库出现的窗口、阶段、配对树、目标任务或门控缓存，还必须记录其回调前后状态。上一个事件即使没有下单，也可能已经修改这些状态。

本轮未取得历史加密配置明文，未启动历史市场回测，未完成全部 SDK 撮合/费用/账户回报的逐事件等价重放。自动反编译的 Rust Option、复合返回值和 SIMD 临时变量不可靠；已纠正部分以本页公式与机器码探测为准，剩余不确定性在本库专属章节明确列出。本文不是能替换原 so 的完整插件源码。

## 本库业务函数证据索引

地址统一使用未重定位 ELF 虚拟地址；Ghidra C 中的 `001xxxxx` 是项目加载基址后的地址，两者不要混淆。下列索引使每个计算/回调都可回到本库证据，不用其他库的同名函数替代。

- [strategy_sm3::cancel_side](analysis/libstrategy_sm3/decompiled_repaired/000000000003ba30.c)（ELF `0x3ba30`，922 字节）。
- [strategy_sm3::default_pv1](analysis/libstrategy_sm3/decompiled_repaired/000000000003b9d0.c)（ELF `0x3b9d0`，87 字节）。
- [strategy_sm3::apply_book_vol_cap](analysis/libstrategy_sm3/decompiled_repaired/000000000003c7b0.c)（ELF `0x3c7b0`，720 字节）。
- [strategy_sm3::live_pending_counts](analysis/libstrategy_sm3/decompiled_repaired/000000000003c240.c)（ELF `0x3c240`，1377 字节）。
- [strategy_sm3::cancel_order_use_range](analysis/libstrategy_sm3/decompiled_repaired/000000000003bdd0.c)（ELF `0x3bdd0`，1121 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::update_score](analysis/libstrategy_sm3/decompiled_repaired/0000000000087da0.c)（ELF `0x87da0`，588 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::point_signal_trigger_pv3_spread](analysis/libstrategy_sm3/decompiled_repaired/0000000000087ff0.c)（ELF `0x87ff0`，178 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::new](analysis/libstrategy_sm3/decompiled_repaired/0000000000087cd0.c)（ELF `0x87cd0`，199 字节）。
- [strategy_signal_maker_common::signal_trigger::dynamic_threshold](analysis/libstrategy_sm3/decompiled_repaired/00000000000880b0.c)（ELF `0x880b0`，152 字节）。
- [strategy_signal_maker_common::signal_trigger::TsQuantileCalculator::update](analysis/libstrategy_sm3/decompiled_repaired/0000000000087a70.c)（ELF `0x87a70`，598 字节）。
- [strategy_signal_maker_common::signal_trigger::dynamic_pending_ts_ms](analysis/libstrategy_sm3/decompiled_repaired/0000000000088150.c)（ELF `0x88150`，63 字节）。
- [strategy_signal_maker_common::get_quote_price::get_quote_vol](analysis/libstrategy_sm3/decompiled_repaired/0000000000084d30.c)（ELF `0x84d30`，135 字节）。
- [strategy_signal_maker_common::get_quote_price::get_quote_price_one_shot](analysis/libstrategy_sm3/decompiled_repaired/0000000000084dc0.c)（ELF `0x84dc0`，8287 字节）。
- [<strategy_sm3::StrategySM3 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](analysis/libstrategy_sm3/decompiled_repaired/000000000003ca80.c)（ELF `0x3ca80`，825 字节）。
- [<strategy_sm3::StrategySM3 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](analysis/libstrategy_sm3/decompiled_repaired/0000000000040260.c)（ELF `0x40260`，352 字节）。
- [<strategy_sm3::StrategySM3 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](analysis/libstrategy_sm3/decompiled_repaired/000000000003cdc0.c)（ELF `0x3cdc0`，13460 字节）。
- [fb_strategy_sdk_abi_version](analysis/libstrategy_sm3/decompiled_repaired/0000000000057a90.c)（ELF `0x57a90`，6 字节）。
- [fb_strategy_sdk_version_str](analysis/libstrategy_sm3/decompiled_repaired/0000000000057aa0.c)（ELF `0x57aa0`，73 字节）。

[完整反汇编](analysis/libstrategy_sm3/assembly.txt)；[核心伪代码集合](analysis/libstrategy_sm3/核心伪代码.c)；[原自然语言说明](自然语言详解_20261114/22_sm3.md)。
