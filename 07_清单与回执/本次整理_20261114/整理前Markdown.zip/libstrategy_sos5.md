# libstrategy_sos5.so：数学化还原与逐分支说明

读取 watcher 发布值，在三个 section 之间切换；section 可携带不同合约、信号和交易模式。支持固定人民币门槛或四股指篮子名义金额派生门槛。

对应原件：`libstrategy_sos5.so`，SHA-256 `567ba8f4e88b5e260159311eb31f119455ef8e4215bdb07a5c08186198fb08ac`。本文为 2026-11-14 新建的逐库数学说明，旧自然语言版保留，若有冲突以本页列出的原始函数与本轮证据为准。

## 记号、输入与可复现边界

设买一价为 $b$，卖一价为 $a$，中价 $m=(a+b)/2$；持仓 $q>0$ 表示多仓，$q<0$ 表示空仓；合约乘数为 $M$。价格步长与数量步长分别为 $\tau_p,\tau_v$。百分比、比例与 bp 不混用：$1\mathrm{bp}=10^{-4}$。`round` 表示本库调用的浮点四舍五入（中点远离零），不是 Python 的 ties-to-even。

外部信号、账户持仓、盘口和交易时间通过 SDK 输入。文中“输入主值/次值”只指信号事件的数值槽；未取得上游预测器源码时，不能把它改名为某个特定 alpha 或宣称这里重新训练了模型。本文公式首先针对有限实数、正价格与正合约乘数；NaN/Inf 的硬件比较分支不应拿普通实数代数擅自合并。

确定性分三层：**机器码实测**表示下面列出的原始 ELF 函数通过合成输入检查；**静态确定**表示已从本库反编译、常量或指令确定控制关系；**尚未闭合**表示明确缺少原始配置、SDK 语义或逐事件状态验收。配置缺省值不代表历史实验启用了该值。

## 四动作不是四个可交换判断

阈值向量按内存顺序定义为

$$T=(L_o,L_c,S_o,S_c).$$

有限输入的分类器严格按以下顺序执行：

$$A(x,T)=\begin{cases}
0\ (开多),&x\ge L_o,\\
3\ (平空),&x<L_o\land x\ge S_c,\\
2\ (开空),&x<L_o\land x<S_c\land x\le S_o,\\
1\ (平多),&x<L_o\land x<S_c\land x>S_o\land x\le L_c,\\
4\ (无动作),&\text{其余}.
\end{cases}$$

先判断开多，再平空，再开空，最后平多。即使配置了交叠阈值也不排序、不纠正。例如四阈值全为零且 $x=0$，结果是开多，不是无动作。动作确定后还要受仓位、盘口、撤单与账户接口约束；“开多”可能先买回空仓，不能把整个订单量记作新增多仓。

错误/无结果与无动作也不能合并：若触发器返回错误变体，调用者走错误/提前返回分支；枚举 4 是成功计算出的“不交易”。

## 点触发的精确公式

调用点触发前，当前信号已写入触发器 `+0x38`，四阈值位于 `+0x40,+0x48,+0x50,+0x58`。令成本倍率为 $\alpha_c$，传入价差尺度为 $h$，PV1 的成本项是

$$c=\alpha_c|h|,\qquad x=\begin{cases}\max(s-c,0),&s>0,\\\min(s+c,0),&s\le0.\end{cases}$$

输出是 $(A(x,T),1)$，第二项是固定票值 1。这里先扣成本、向零截断，再比较阈值；不能改成直接把全部阈值平移，也不能把正负信号都写成 $s-c$。

例如 $T=(3,-1,-3,1)$，$s=4,c=1$ 得 $x=3$，触发开多；$s=-4,c=1$ 得 $x=-3$，触发开空；$s=0.5,c=1$ 得 $x=0$，落在无动作区。例子是合成边界说明。

## 持仓年龄动态阈值

令 $h_p$ 为传入的持仓秒数，$t_0,t_1,\Delta$ 分别对应 `dyn_score_position_ts_threshold_s`、`dyn_score_max_position_ts_s`、`dyn_score_delta_score`。

$$d=\begin{cases}
0,&t_0<0\lor t_1<0\lor h_p<t_0\lor |\Delta|\le10^{-9},\\
\left|\Delta\min\left(\frac{h_p-t_0}{\max(t_1-t_0,10^{-6})},1\right)\right|,&\text{其余}.
\end{cases}$$

$$T'=(L_o-d,L_c+d,S_o+d,S_c-d).$$

四个门槛均变化，且负的 $\Delta$ 也产生非负 $d$。$t_1\le t_0$ 不会报错，而使用 $10^{-6}$ 的分母下限。$h_p=t_0$ 时增量为零；超过终点后饱和。以上是独立 `dynamic_threshold` 的行为，不能套到 LF4/TM5/TM6/SoS6 的内联旧逻辑上。

## 时间窗口触发与投票

每个窗口维护 $(t_i,s_i)$ 队列及 $N,\sum s_i,\sum s_i^2,\sum_{s_i>0}s_i,\sum_{s_i\le0}s_i$。插入当前点后，删除所有 $t-t_i>W$ 的旧点；恰好位于 $t-W$ 的点保留。更新按加减旧值进行，不能随意改为重新求和后声称浮点逐位等价。

$$\mu=\frac{\sum s_i}{N},\qquad \sigma=\sqrt{\max(\sum s_i^2/\max(N,1)-\mu^2,0)}.$$

均值触发把 $\mu$ 送入四阈值比较。Sharpe 触发使用 $\mu/\sigma$，$|\sigma|\le10^{-6}$ 时取零；这是信号窗口统计量，不是策略收益夏普。RSI 使用信号正负值的累计量，令 $P=\sum_{s_i>0}s_i,N_-=\sum_{s_i\le0}s_i$：

$$R=\begin{cases}100-\frac{100}{P/|N_-|+1},&|N_-|>10^{-6},\\50,&\text{其余}.\end{cases}$$

特别注意：`update` 写入和、平方和和均值，但不会自动重算所有版本的 `std_cache`。`WindowsStdTrigger` 读的是缓存槽，不能无条件用上式即时标准差替代；Sharpe 分支另有重算行为。信号带同样需要保留缓存的实际更新顺序。

分位数按有序观测的整数下标取值，使用 $\lfloor qN\rfloor$ 与 $\lfloor(1-q)N\rfloor$，不是线性插值；端点越界可返回错误。多窗口先形成各自候选动作，再计票，最高票比例必须**严格大于** `vote_rate`。并列候选涉及 HashMap 遍历，不应凭业务偏好增加“多头优先”或“平仓优先”。本节是对应窗口函数的静态说明；本轮新增的全库实测不包括每一种窗口的完整状态序列。

## section 状态机：收益之外还有账户符号门控

三个 section 编码为 1、2、3。记 watcher 发布值 $z$，五个转移门槛 $h_{12},h_{13},h_{21},h_{23},h_{31}$。另记主回调从 `free_cash/meta_account` 路径取得、用于正负判断的账户标量为 $C_{acct}$。该 ABI 返回字段尚未完全命名，本文保留可追溯记号，不武断称为仓位或总净值。

| 原状态 | 按优先级判断 | 新状态 |
|---|---|---|
| 1 | $z\ge h_{12}$ 且 $C_{acct}>0$ | 2 |
| 1 | 上条未满足，$z>h_{13}$ 且 $C_{acct}<0$ | 3 |
| 1 | 其余 | 1 |
| 2 | $z<h_{21}$ | 1 |
| 2 | 否则 $z>h_{23}$ 且 $C_{acct}<0$ | 3 |
| 2 | 其余 | 2 |
| 3 | $z<h_{31}$ | 1 |
| 3 | 其余 | 3 |

注意 1→2 使用 `>=`，转入 3 使用 `>`，从 3 回 1 使用 `<`；$C_{acct}=0$ 阻止从 1 升到 2/3，也阻止从 2 进入 3。只画“收益超过门槛就切换”的图会漏掉决定性条件。watcher 发布值缺失时对应回退路径取零，不是自动停止整个策略。

切入/切出 section3 触发额外在途订单处理，先收集和去重撤单 ID，再检查仍存活的订单，然后才允许继续调仓。section 的 `insts/ranks/signal_all/trade_mode/trade_code` 属于交易对象和执行设置，普通四阈值及增仓/净仓手数金额也各自独立。切换 section 不是只换四个浮点数，更不等于一次回调把所有目标仓位都成交完。

## 固定人民币与 live_basket_bp 两种门槛

`phase_threshold_mode` 先去两端空白并转 ASCII 小写。固定模式使用配置五个人民币门槛；`fixed` 和 `fixed_rmb` 属于支持路径。`live_basket_bp` 根据四股指参考篮子形成名义金额：

$$N=300p_{IF}+300p_{IH}+200p_{IM}+200p_{IC}.$$

四个品种键都要能取到参考价；这是每品种一单位合约价格乘乘数的篮子，不是根据账户实际持仓权重加总。篮子无效时调用者可用 `phase_default_reference_notional`，缺省 5000000，而不是缺一种品种就直接按其余三种继续算。

令 $b_p=\text{phase_threshold_bp}$，$h=\text{phase_high_multiplier}$，则

$$B=N b_p/10000,\qquad(h_{12},h_{13},h_{21},h_{23},h_{31})=(B,hB,-B,hB,B).$$

代码要求 $b_p$ 为正有限数、$h>1$ 且有限、参考金额正且有限、推导门槛有效；不满足返回错误。不能因为默认 $b_p=0$ 就假设 live 模式默认有效。

参考价更新还存在 `phase_mid_jump_reject_rate` 与 `phase_max_spread_bp` 的过滤（缺省分别 0.11 和 100）；二者防止异常行情直接扭曲阶段门槛。过滤后的“最后有效价”与当前盘口并非始终相等，因此重放时必须保存参考价缓存，而不是每次从当前四个中价重算并忽略拒收。

## section 迁移与普通交易是两条路径

`sos_taker_rate`、`sos_add_vol`、`order_book_1_2_gap` 用于 section 迁移相关的订单逻辑；常规信号仍使用本 section 四阈值、PV 模式、成本和风险约束。不能把两个参数集强行合并成同一套每信号订单公式。通用 `run_sos5_phase` 的构建/发布参数属于如何组装输入，不能替代 so 内部的实际条件。

本轮已探测三个 section 的 24 个数值字段默认值与偏移。完整参考价拒收、跨 section 撤单和跨合约再平衡轨迹尚未做动态事件验收；相应静态分支已保留到本页函数索引。

## 数量、金额与订单请求的层次

所有数量计算都必须区分当前净持仓 $q$、本次有符号请求 $v$、在途预占和最终成交量。对使用金额上限的分支，金额换算以实际选择的订单价格 $p$ 和合约乘数 $M$ 进行，数学上为 $A/(pM)$；原指令常按 `(A/p)/M` 连续除法，逐位复现不能随意改为先乘分母。

负的风险额度在相应限额分支转换为 $+\infty$；零是真实约束。`max_single_add_vol/amt` 约束新增部分，`max_single_net_vol/amt` 约束方向净敞口，`max_single_close_vol/amt` 约束旧反向仓位的平仓部分。开仓动作可以把“新方向允许增量”和“允许平掉的反向旧仓”相加；纯平仓动作不应允许越过零仓继续反向开仓。具体分支中的 `max(amount/(pM),1)` 会形成至少一手的中间额度，但最后仍受其他 cap 和数量步长限制。

实际订单前还有 SDK `margin_filter`、`impact_block_check`、交易时段、允许合约/信号和在途订单检查。它们是可见的调用边界，不能用“所有条件都通过”代替未知历史账户状态。价格与数量最终经过 `round_with_step_f64`；本文保留函数调用及 mode，而不把所有 mode 都武断解释为向下取整。IOC、IAP 或带 target 的 IAP 请求如何被撮合，属于通用引擎和账户模型。

因此复现输出应先比较 `(动作、报价类型、请求价、请求量、撤单ID序列、状态更新)`；仅比较最终收益曲线无法证明这些分支相同。

## 本库全部配置字段：真实解析默认值与状态偏移

下表来自直接加载原始 `.so` 后调用其 `on_begin` 解析器；浮点字段用两个不同标记值匹配同一位置。偏移相对于策略对象起点，不是 ELF 文件偏移。Option 的 None 载荷不读取为默认数值。日志 SDK 为 no-op，其余 SDK 调用会 abort，未调用交易回调。

SoS 必需的 watcher 名与 section 标识使用探测种子；表中的 `"probe"` 是探测输入，**不是二进制缺省值**。section 的 IF、rank=1、signal_all="0"、IAP 同样是为使解析成立所设种子。

| 字段 | 解析值/默认状态 | 对象偏移 |
|---|---|---|
| `watcher_strategy_name` | "probe" | `0x0` |
| `watcher_account_name` | "probe" | `0x18` |
| `watcher_key` | "rolling_pnl" | `0x30` |
| `section1_to_2_pnl` | 0.0 | `0x288` |
| `section1_to_3_pnl` | 0.0 | `0x290` |
| `section2_to_1_pnl` | 0.0 | `0x298` |
| `section2_to_3_pnl` | 0.0 | `0x2a0` |
| `section3_to_1_pnl` | 0.0 | `0x2a8` |
| `phase_threshold_mode` | "fixed_rmb" | `0x48` |
| `phase_threshold_bp` | 0.0 | `0x2b0` |
| `phase_high_multiplier` | 2.0 | `0x2b8` |
| `phase_default_reference_notional` | 5000000.0 | `0x2c0` |
| `phase_mid_jump_reject_rate` | 0.11 | `0x2c8` |
| `phase_max_spread_bp` | 100.0 | `0x2d0` |
| `order_book_1_2_gap` | 0.0 | `0x2d8` |
| `sos_taker_rate` | 0.0 | `0x2e0` |
| `sos_add_vol` | 0.0 | `0x2e8` |
| `section1` | 嵌套结构，见下表/字段表 | — |
| `section2` | 嵌套结构，见下表/字段表 | — |
| `section3` | 嵌套结构，见下表/字段表 | — |
| `signal_mode` | "" | `0x240` |
| `pv1_alpha` | 1.0 | `0x2f0` |
| `cost_alpha` | 1.0 | `0x2f8` |
| `signal_trigger_mode` | "" | `0x258` |
| `vote_rate` | 0.1 | `0x300` |
| `quantile` | 0.9 | `0x308` |
| `signal_windows_s` | [] | `0x270` |
| `score_taker_rate_alpha` | 0.0 | `0x310` |
| `taker_rate_baseline` | 0.0 | `0x318` |
| `max_taker_rate` | 0.0 | `0x320` |
| `trade_slippery` | 0.0 | `0x328` |
| `close_position_block_ms` | 0.0 | `0x330` |
| `max_single_close_vol` | 0.0 | `0x338` |
| `max_single_close_amt` | 0.0 | `0x340` |
| `dyn_score_position_ts_threshold_s` | 0.0 | `0x348` |
| `dyn_score_max_position_ts_s` | 0.0 | `0x350` |
| `dyn_score_delta_score` | 0.0 | `0x358` |
| `dyn_pending_position_ts_threshold_s` | 0.0 | `0x360` |
| `dyn_pending_max_position_ts_s` | 0.0 | `0x368` |
| `dyn_pending_order_max_pending_time_ms` | 0.0 | `0x370` |
| `dyn_pending_delta_max_pending_ts_ms` | 0.0 | `0x378` |

嵌套数值字段另行覆盖探测：

| 完整字段 | 缺省值 | 对象偏移 |
|---|---|---|
| `section1.long_open_threshold` | 0.0 | `0xc0` |
| `section1.long_close_threshold` | 0.0 | `0xc8` |
| `section1.short_open_threshold` | 0.0 | `0xd0` |
| `section1.short_close_threshold` | 0.0 | `0xd8` |
| `section1.max_single_add_vol` | 0.0 | `0xe0` |
| `section1.max_single_net_vol` | 0.0 | `0xe8` |
| `section1.max_single_add_amt` | 0.0 | `0xf0` |
| `section1.max_single_net_amt` | 0.0 | `0xf8` |
| `section2.long_open_threshold` | 0.0 | `0x160` |
| `section2.long_close_threshold` | 0.0 | `0x168` |
| `section2.short_open_threshold` | 0.0 | `0x170` |
| `section2.short_close_threshold` | 0.0 | `0x178` |
| `section2.max_single_add_vol` | 0.0 | `0x180` |
| `section2.max_single_net_vol` | 0.0 | `0x188` |
| `section2.max_single_add_amt` | 0.0 | `0x190` |
| `section2.max_single_net_amt` | 0.0 | `0x198` |
| `section3.long_open_threshold` | 0.0 | `0x200` |
| `section3.long_close_threshold` | 0.0 | `0x208` |
| `section3.short_open_threshold` | 0.0 | `0x210` |
| `section3.short_close_threshold` | 0.0 | `0x218` |
| `section3.max_single_add_vol` | 0.0 | `0x220` |
| `section3.max_single_net_vol` | 0.0 | `0x228` |
| `section3.max_single_add_amt` | 0.0 | `0x230` |
| `section3.max_single_net_amt` | 0.0 | `0x238` |

原始回执：[顶层解析](数学化还原_20261114/libstrategy_sos5.config_layout.json)；[字段数组](analysis/libstrategy_sos5/config_field_arrays.json)。默认字段是类型/初始化证据，不能代替历史加密配置的明文。

## 本轮机器码核验及其覆盖范围

| 原始函数/模型 | 案例数 | 通过 | 证据 |
|---|---:|---:|---|
| `point_signal_trigger_pv1_spread` | 1200 | 1200 | [回执](数学化还原_20261114/libstrategy_sos5.leaf_validation.json) |
| `dynamic_threshold` | 288 | 288 | [回执](数学化还原_20261114/libstrategy_sos5.leaf_validation.json) |

本页上述新增检查合计 **1488/1488**。这是原始 ELF 叶函数/指定状态函数的合成输入检查，不能扩写为整个策略或全部历史订单的等价验收。点触发与枚举用精确比较；浮点核验容差和逐位比较范围写在脚本/回执中。

## 逐事件复现应保存的状态与尚未闭合项

每次回调记录输入时间、合约/信号标识、原信号值、盘口、SDK 持仓与在途信息；再记录变换信号、有效阈值、动作、报价类型、候选价量、撤单集合以及状态写回。对本库出现的窗口、阶段、配对树、目标任务或门控缓存，还必须记录其回调前后状态。上一个事件即使没有下单，也可能已经修改这些状态。

本轮未取得历史加密配置明文，未启动历史市场回测，未完成全部 SDK 撮合/费用/账户回报的逐事件等价重放。自动反编译的 Rust Option、复合返回值和 SIMD 临时变量不可靠；已纠正部分以本页公式与机器码探测为准，剩余不确定性在本库专属章节明确列出。本文不是能替换原 so 的完整插件源码。

## 本库业务函数证据索引

地址统一使用未重定位 ELF 虚拟地址；Ghidra C 中的 `001xxxxx` 是项目加载基址后的地址，两者不要混淆。下列索引使每个计算/回调都可回到本库证据，不用其他库的同名函数替代。

- [strategy_sos5::SoS5Params::phase_thresholds](analysis/libstrategy_sos5/decompiled_repaired/0000000000049050.c)（ELF `0x49050`，1830 字节）。
- [strategy_sos5::SoS5Params::signal_trigger_mode](analysis/libstrategy_sos5/decompiled_repaired/0000000000049780.c)（ELF `0x49780`，266 字节）。
- [strategy_sos5::signal_trigger::SignalTrigger::update_score](analysis/libstrategy_sos5/decompiled_repaired/000000000006a5e0.c)（ELF `0x6a5e0`，1845 字节）。
- [strategy_sos5::signal_trigger::SignalTrigger::windows_rsi_trigger](analysis/libstrategy_sos5/decompiled_repaired/000000000006b8e0.c)（ELF `0x6b8e0`，554 字节）。
- [strategy_sos5::signal_trigger::SignalTrigger::windows_std_trigger](analysis/libstrategy_sos5/decompiled_repaired/000000000006aec0.c)（ELF `0x6aec0`，264 字节）。
- [strategy_sos5::signal_trigger::SignalTrigger::windows_mean_trigger](analysis/libstrategy_sos5/decompiled_repaired/000000000006adb0.c)（ELF `0x6adb0`，264 字节）。
- [strategy_sos5::signal_trigger::SignalTrigger::windows_sharpe_trigger](analysis/libstrategy_sos5/decompiled_repaired/000000000006b690.c)（ELF `0x6b690`，586 字节）。
- [strategy_sos5::signal_trigger::SignalTrigger::windows_quantile_trigger](analysis/libstrategy_sos5/decompiled_repaired/000000000006afd0.c)（ELF `0x6afd0`，1717 字节）。
- [strategy_sos5::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](analysis/libstrategy_sos5/decompiled_repaired/000000000006ad20.c)（ELF `0x6ad20`，137 字节）。
- [strategy_sos5::signal_trigger::dynamic_threshold](analysis/libstrategy_sos5/decompiled_repaired/000000000006c080.c)（ELF `0x6c080`，152 字节）。
- [_ZN13strategy_sos514signal_trigger17enum_rate_counter17h52e1c88565e9250aE.llvm.14864376446662127556](analysis/libstrategy_sos5/decompiled_repaired/000000000006bb10.c)（ELF `0x6bb10`，1378 字节）。
- [strategy_sos5::default_watcher_key](analysis/libstrategy_sos5/decompiled_repaired/0000000000048f80.c)（ELF `0x48f80`，98 字节）。
- [strategy_sos5::place_order_by_mode](analysis/libstrategy_sos5/decompiled_repaired/000000000004e940.c)（ELF `0x4e940`，338 字节）。
- [strategy_sos5::phase_basket_notional](analysis/libstrategy_sos5/decompiled_repaired/000000000004e6a0.c)（ELF `0x4e6a0`，662 字节）。
- [strategy_sos5::default_phase_threshold_mode](analysis/libstrategy_sos5/decompiled_repaired/0000000000048ff0.c)（ELF `0x48ff0`，95 字节）。
- [<strategy_sos5::StrategySoS5 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](analysis/libstrategy_sos5/decompiled_repaired/0000000000049890.c)（ELF `0x49890`，2396 字节）。
- [<strategy_sos5::StrategySoS5 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](analysis/libstrategy_sos5/decompiled_repaired/000000000004dba0.c)（ELF `0x4dba0`，2102 字节）。
- [<strategy_sos5::StrategySoS5 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](analysis/libstrategy_sos5/decompiled_repaired/000000000004e3e0.c)（ELF `0x4e3e0`，697 字节）。
- [<strategy_sos5::StrategySoS5 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](analysis/libstrategy_sos5/decompiled_repaired/000000000004a1f0.c)（ELF `0x4a1f0`，14764 字节）。
- [fb_strategy_sdk_abi_version](analysis/libstrategy_sos5/decompiled_repaired/0000000000069a10.c)（ELF `0x69a10`，6 字节）。
- [fb_strategy_sdk_version_str](analysis/libstrategy_sos5/decompiled_repaired/0000000000069a20.c)（ELF `0x69a20`，73 字节）。

[完整反汇编](analysis/libstrategy_sos5/assembly.txt)；[核心伪代码集合](analysis/libstrategy_sos5/核心伪代码.c)；[原自然语言说明](自然语言详解_20261114/25_sos5.md)。
