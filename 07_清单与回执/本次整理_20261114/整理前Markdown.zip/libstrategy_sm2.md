# libstrategy_sm2.so：数学化还原与逐分支说明

用正态分布成交概率与报价收益构建买卖效用，分别数值求解最优报价，再比较买卖效用并生成开平动作。

对应原件：`libstrategy_sm2.so`，SHA-256 `7d78c5e4ec850fc13bbf7c374eaeb24857de05276cb0c143c3e84a11cd9bf527`。本文为 2026-11-14 新建的逐库数学说明，旧自然语言版保留，若有冲突以本页列出的原始函数与本轮证据为准。

## 记号、输入与可复现边界

设买一价为 $b$，卖一价为 $a$，中价 $m=(a+b)/2$；持仓 $q>0$ 表示多仓，$q<0$ 表示空仓；合约乘数为 $M$。价格步长与数量步长分别为 $\tau_p,\tau_v$。百分比、比例与 bp 不混用：$1\mathrm{bp}=10^{-4}$。`round` 表示本库调用的浮点四舍五入（中点远离零），不是 Python 的 ties-to-even。

外部信号、账户持仓、盘口和交易时间通过 SDK 输入。文中“输入主值/次值”只指信号事件的数值槽；未取得上游预测器源码时，不能把它改名为某个特定 alpha 或宣称这里重新训练了模型。本文公式首先针对有限实数、正价格与正合约乘数；NaN/Inf 的硬件比较分支不应拿普通实数代数擅自合并。

确定性分三层：**机器码实测**表示下面列出的原始 ELF 函数通过合成输入检查；**静态确定**表示已从本库反编译、常量或指令确定控制关系；**尚未闭合**表示明确缺少原始配置、SDK 语义或逐事件状态验收。配置缺省值不代表历史实验启用了该值。


## 动作编码与四阈值

阈值按 $T=(L_o,L_c,S_o,S_c)$ 保存。动作 0=开多、1=平多、2=开空、3=平空、4=无动作。SM2 先比较两侧效用，随后按被选侧的开仓/平仓门槛判断，完整公式见下文；不能照搬普通 PV1 的单分数分类流程。

## 持仓年龄动态阈值

令 $h_p$ 为传入的持仓秒数，$t_0,t_1,\Delta$ 分别对应 `dyn_score_position_ts_threshold_s`、`dyn_score_max_position_ts_s`、`dyn_score_delta_score`。

$$d=\begin{cases}
0,&t_0<0\lor t_1<0\lor h_p<t_0\lor |\Delta|\le10^{-9},\\
\left|\Delta\min\left(\frac{h_p-t_0}{\max(t_1-t_0,10^{-6})},1\right)\right|,&\text{其余}.
\end{cases}$$

$$T'=(L_o-d,L_c+d,S_o+d,S_c-d).$$

四个门槛均变化，且负的 $\Delta$ 也产生非负 $d$。$t_1\le t_0$ 不会报错，而使用 $10^{-6}$ 的分母下限。$h_p=t_0$ 时增量为零；超过终点后饱和。以上是独立 `dynamic_threshold` 的行为，不能套到 LF4/TM5/TM6/SoS6 的内联旧逻辑上。

## 正态概率、效用与最优报价

设分布位置与尺度为 $u,\sigma$，$\sigma>0$，

$$F(x)=\Phi((x-u)/\sigma)=\tfrac12[1+\operatorname{erf}((x-u)/(\sigma\sqrt2))].$$

`hit_probability` 的布尔方向分支分别返回 $\beta F(x)$ 与 $\beta(1-F(x))$。但 `UtilityRange::get_utility` 直接计算的效用**没有乘 beta**：

$$U_b(q)=F(q)(V_b-q),\qquad U_s(q)=(1-F(q))(q-V_s).$$

$V_b,V_s$ 是分别传给买卖优化器的价值输入。正常内部极值满足令 $z=(q-u)/\sigma$：

$$g_b(z)=z+\Phi(z)/\phi(z)-(V_b-u)/\sigma=0,$$
$$g_s(z)=z-(1-\Phi(z))/\phi(z)-(V_s-u)/\sigma=0,$$

其中 $\phi(z)=e^{-z^2/2}/\sqrt{2\pi}$。最后 $q=u+\sigma z$。原始函数在 `RAX` 返回 Option 标签，报价在 `XMM0`；只看到 `return 1` 不能推断报价恒为 1。

求根区间固定为 $[-10,10]$，最多 100 次迭代，区间长度或残差容限为 $10^{-8}$；不满足两端异号或未收敛进入错误/无结果路径。使用 erf 的尾部消去可能造成极端 $z$ 下较大的代数残差，本轮 60 个原始函数探测已保留实际残差，不能宣称解析最优与机器码逐位一致。

例如 $V=u=0,\sigma=1$ 时，买侧原始报价约为 $-0.7517915247$；这是无量纲合成例子，不是可交易市场价。$V=-8,u=0,\sigma=1$ 的买侧样本产生约 $-8.1115938873$，按双精度 erf 回代的方程残差约 -0.003606，说明极端尾部不能只报告“求根通过”。

## 双侧效用如何选择动作

若 $U_b\ge U_s$，包括相等，优先看买侧：$U_b\ge L_o$ 则开多，否则 $U_b\ge S_c$ 则平空，否则无动作。若 $U_b<U_s$，将卖效用映射为 $x=-U_s$：$x\le S_o$ 则开空，否则 $x\le L_c$ 则平多，否则无动作。输出携带对应侧的 Option 报价。

失败侧效用先设为零，之后仍按上述效用比较；不能改成“先剔除失败侧，再自动选择另一侧”，因为这是不同的控制顺序。报价 Option 还要由调用者检查。

本库虽然有公共信号缓存和动态阈值，不应套用 SM1 的 $E>H$ 三分段报价，更不能把它简写为普通 PV1 扣价差。尚未闭合的是上游怎样构成每次的 $u,\sigma,V_b,V_s$ 的所有模式分支及其与账户执行的完整逐事件一致性；本页保留各输入槽的角色，未猜测上游预测分布一定校准。

## 数量、金额与订单请求的层次

所有数量计算都必须区分当前净持仓 $q$、本次有符号请求 $v$、在途预占和最终成交量。对使用金额上限的分支，金额换算以实际选择的订单价格 $p$ 和合约乘数 $M$ 进行，数学上为 $A/(pM)$；原指令常按 `(A/p)/M` 连续除法，逐位复现不能随意改为先乘分母。

负的风险额度在相应限额分支转换为 $+\infty$；零是真实约束。`max_single_add_vol/amt` 约束新增部分，`max_single_net_vol/amt` 约束方向净敞口，`max_single_close_vol/amt` 约束旧反向仓位的平仓部分。开仓动作可以把“新方向允许增量”和“允许平掉的反向旧仓”相加；纯平仓动作不应允许越过零仓继续反向开仓。具体分支中的 `max(amount/(pM),1)` 会形成至少一手的中间额度，但最后仍受其他 cap 和数量步长限制。

实际订单前还有 SDK `margin_filter`、`impact_block_check`、交易时段、允许合约/信号和在途订单检查。它们是可见的调用边界，不能用“所有条件都通过”代替未知历史账户状态。价格与数量最终经过 `round_with_step_f64`；本文保留函数调用及 mode，而不把所有 mode 都武断解释为向下取整。IOC、IAP 或带 target 的 IAP 请求如何被撮合，属于通用引擎和账户模型。

因此复现输出应先比较 `(动作、报价类型、请求价、请求量、撤单ID序列、状态更新)`；仅比较最终收益曲线无法证明这些分支相同。

## 本库全部配置字段：真实解析默认值与状态偏移

下表来自直接加载原始 `.so` 后调用其 `on_begin` 解析器；浮点字段用两个不同标记值匹配同一位置。偏移相对于策略对象起点，不是 ELF 文件偏移。Option 的 None 载荷不读取为默认数值。日志 SDK 为 no-op，其余 SDK 调用会 abort，未调用交易回调。

| 字段 | 解析值/默认状态 | 对象偏移 |
|---|---|---|
| `signal_mode` | "PV1" | `0x0` |
| `pv1_alpha` | 1.0 | `0x60` |
| `trade_slippery` | 0.0 | `0x68` |
| `close_position_block_ms` | 0.0 | `0x70` |
| `max_single_add_vol` | -1.0 | `0x78` |
| `max_single_add_amt` | -1.0 | `0x80` |
| `max_single_net_vol` | -1.0 | `0x88` |
| `max_single_net_amt` | -1.0 | `0x90` |
| `max_single_close_vol` | -1.0 | `0x98` |
| `max_single_close_amt` | -1.0 | `0xa0` |
| `long_open_threshold` | 0.0 | `0xa8` |
| `long_close_threshold` | 0.0 | `0xb0` |
| `short_open_threshold` | 0.0 | `0xb8` |
| `short_close_threshold` | 0.0 | `0xc0` |
| `dyn_score_position_ts_threshold_s` | 0.0 | `0xc8` |
| `dyn_score_max_position_ts_s` | 0.0 | `0xd0` |
| `dyn_score_delta_score` | 0.0 | `0xd8` |
| `dyn_pending_position_ts_threshold_s` | 0.0 | `0xe0` |
| `dyn_pending_max_position_ts_s` | 0.0 | `0xe8` |
| `dyn_pending_delta_max_pending_ts_ms` | 0.0 | `0xf0` |
| `order_max_pending_time_ms` | 0.0 | `0xf8` |
| `maker_signal_abtype_u` | None（Option 哨兵） | `0x30` |
| `maker_signal_abtype_s` | None（Option 哨兵） | `0x48` |
| `maker_signal_abtype_beta` | 0.0 | `0x100` |
| `signal_all` | "" | `0x18` |
| `touch_gate` | true | `0x120` |
| `touch_gate_timeout_ms` | 5000.0 | `0x108` |
| `book_vol_cap` | true | `0x121` |
| `max_single_taker_vol` | 0.0 | `0x110` |
| `max_maker_pending_vol_on_depth` | 0.0 | `0x118` |

原始回执：[顶层解析](数学化还原_20261114/libstrategy_sm2.config_layout.json)；[字段数组](analysis/libstrategy_sm2/config_field_arrays.json)。默认字段是类型/初始化证据，不能代替历史加密配置的明文。

## 本轮机器码核验及其覆盖范围

| 原始函数/模型 | 案例数 | 通过 | 证据 |
|---|---:|---:|---|
| `dynamic_threshold` | 288 | 288 | [回执](数学化还原_20261114/libstrategy_sm2.leaf_validation.json) |

本页上述新增检查合计 **288/288**。这是原始 ELF 叶函数/指定状态函数的合成输入检查，不能扩写为整个策略或全部历史订单的等价验收。点触发与枚举用精确比较；浮点核验容差和逐位比较范围写在脚本/回执中。

[优化器 60 个原始函数探测](数学化还原_20261114/libstrategy_sm2.optimizer_native_cases.json)记录报价、Option 标签及回代残差；极端尾部残差不为零，未计作“60 个数学模型通过”。

## 逐事件复现应保存的状态与尚未闭合项

每次回调记录输入时间、合约/信号标识、原信号值、盘口、SDK 持仓与在途信息；再记录变换信号、有效阈值、动作、报价类型、候选价量、撤单集合以及状态写回。对本库出现的窗口、阶段、配对树、目标任务或门控缓存，还必须记录其回调前后状态。上一个事件即使没有下单，也可能已经修改这些状态。

本轮未取得历史加密配置明文，未启动历史市场回测，未完成全部 SDK 撮合/费用/账户回报的逐事件等价重放。自动反编译的 Rust Option、复合返回值和 SIMD 临时变量不可靠；已纠正部分以本页公式与机器码探测为准，剩余不确定性在本库专属章节明确列出。本文不是能替换原 so 的完整插件源码。

## 本库业务函数证据索引

地址统一使用未重定位 ELF 虚拟地址；Ghidra C 中的 `001xxxxx` 是项目加载基址后的地址，两者不要混淆。下列索引使每个计算/回调都可回到本库证据，不用其他库的同名函数替代。

- [strategy_sm2::default_pv1](analysis/libstrategy_sm2/decompiled_repaired/0000000000045650.c)（ELF `0x45650`，87 字节）。
- [strategy_sm2::format_utility_tag](analysis/libstrategy_sm2/decompiled_repaired/0000000000048f50.c)（ELF `0x48f50`，501 字节）。
- [strategy_sm2::apply_book_vol_cap_sm2](analysis/libstrategy_sm2/decompiled_repaired/00000000000456b0.c)（ELF `0x456b0`，723 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::update_score](analysis/libstrategy_sm2/decompiled_repaired/00000000000844f0.c)（ELF `0x844f0`，588 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::point_signal_trigger_utility](analysis/libstrategy_sm2/decompiled_repaired/0000000000084740.c)（ELF `0x84740`，175 字节）。
- [strategy_signal_maker_common::signal_trigger::SignalTrigger::new](analysis/libstrategy_sm2/decompiled_repaired/0000000000084420.c)（ELF `0x84420`，199 字节）。
- [strategy_signal_maker_common::signal_trigger::dynamic_threshold](analysis/libstrategy_sm2/decompiled_repaired/00000000000847f0.c)（ELF `0x847f0`，152 字节）。
- [strategy_signal_maker_common::signal_trigger::TsQuantileCalculator::update](analysis/libstrategy_sm2/decompiled_repaired/00000000000841c0.c)（ELF `0x841c0`，598 字节）。
- [strategy_signal_maker_common::signal_trigger::dynamic_pending_ts_ms](analysis/libstrategy_sm2/decompiled_repaired/0000000000084890.c)（ELF `0x84890`，63 字节）。
- [strategy_signal_maker_common::get_quote_price::UtilityRange::get_utility](analysis/libstrategy_sm2/decompiled_repaired/00000000000828c0.c)（ELF `0x828c0`，359 字节）。
- [strategy_signal_maker_common::hit_probability::HitProbability::hit_probability](analysis/libstrategy_sm2/decompiled_repaired/00000000000870b0.c)（ELF `0x870b0`，75 字节）。
- [strategy_signal_maker_common::brentq_option_price::QuotePriceOptimizer::optimal_quote_buy](analysis/libstrategy_sm2/decompiled_repaired/0000000000082dc0.c)（ELF `0x82dc0`，1423 字节）。
- [strategy_signal_maker_common::brentq_option_price::QuotePriceOptimizer::optimal_quote_sell](analysis/libstrategy_sm2/decompiled_repaired/0000000000083350.c)（ELF `0x83350`，1455 字节）。
- [<strategy_sm2::StrategySM2 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](analysis/libstrategy_sm2/decompiled_repaired/0000000000045990.c)（ELF `0x45990`，854 字节）。
- [<strategy_sm2::StrategySM2 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](analysis/libstrategy_sm2/decompiled_repaired/0000000000048df0.c)（ELF `0x48df0`，352 字节）。
- [<strategy_sm2::StrategySM2 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](analysis/libstrategy_sm2/decompiled_repaired/0000000000045cf0.c)（ELF `0x45cf0`，12536 字节）。
- [fb_strategy_sdk_abi_version](analysis/libstrategy_sm2/decompiled_repaired/0000000000054a70.c)（ELF `0x54a70`，6 字节）。
- [fb_strategy_sdk_version_str](analysis/libstrategy_sm2/decompiled_repaired/0000000000054a80.c)（ELF `0x54a80`，73 字节）。

[完整反汇编](analysis/libstrategy_sm2/assembly.txt)；[核心伪代码集合](analysis/libstrategy_sm2/核心伪代码.c)；[原自然语言说明](自然语言详解_20261114/21_sm2.md)。
