# SDK与框架对策略解释的补充

## 为什么策略提出订单后还有一层判断

策略库中看到的place_order_ioc、place_order_iap、publish、position等调用，最终通过SDK/FFI进入框架。它们不是每个策略自己实现的一套交易所。

本次libfuture_backtest.so导出了订单、撤单、盘口、持仓、保证金、发布/读取状态等接口。三个下单包装最终进入公共place_order_impl；该实现还调用框架保证金门控、处理Meta相关状态，再进入Exchange下单路径。因此策略库算出一个候选订单，不等于引擎一定接受。

## 策略限制与框架限制可能同时存在

策略内有单次增仓、净仓、金额等限制；框架层还可以检查保证金或组合约束。run_comm_maker1又会同时覆盖顶层和custom里的若干风险字段。

这形成一个实际需要共同满足的约束链。不能仅从so中的净金额字段推导最终账户敞口，也不能只看到框架资金充足就认定策略会用满资金。任何一层拒绝或收缩请求，都可能改变实际订单。

## 带target的下单接口说明了什么

普通IAP和带target的IAP都进入公共下单实现，但传入不同的控制参数。带target版本还把额外标记向后传递。由此可以确认两条策略调用路径在框架中并没有被无条件合并成完全一样的请求。

具体target是否代表某种保留、跟踪或生命周期处理，必须继续结合公共实现与撮合状态解释。名称本身不能作为完整语义定义。本文不把它擅自解释成一定追踪某个目标仓位或一定保证完成。

## 发布与读取为何支持watcher结构

fb_ctx_publish会取得当前策略与账户身份，并在共享的状态容器中保存对应键值；get_published提供另一侧读取接口。这与comm_mock、tm5/tm6的发布键以及comm4/comm5、sos的watcher读取相衔接。

因此watcher不是报告里人为想象出的关系，它有框架共享状态接口支持。不过，读取何时发生、缺失时如何处理、发布者是否先于消费者运行，仍然会影响同一次事件的结果。仅知道两个组件的键名相同，并不足以忽略事件次序。

## 流动性消耗和共享Exchange

通用契约区分正式腿与不消耗正式流动性的观察腿。矩阵和Meta入口还支持多条正式腿进入同一个Exchange。它们意味着框架有能力让策略共享市场状态，而不是默认每个策略都独享一份无限复制的盘口。

但“共享Exchange”本身仍不是具体撮合算法：先后顺序、可见挂量扣减、maker模拟、延迟和撤单处理需要逐项审查。当前反编译材料已经扩展到这些入口，尚未做完整市场事件回放，所以不会给出未验证的成交等价结论。

## 三个框架可执行文件不能按名称互换

future_backtest_runner和future_backtest_meta_runner都有RunnerCore相关实现，入口分别对应普通运行与Meta组合运行。启动脚本在meta_portfolio_matrix类型下明确选择Meta runner。future_backtest则还保留更广的框架程序入口和内置策略实现。

进一步对普通runner和Meta runner作了字节比对：两者共同的420个具名future_backtest函数，函数体机器码逐个一致。甚至两者main中的六个字节也相同，但不能因此认为入口相同：该指令经全局偏移表跳转，ELF重定位记录在普通runner中指向standard_main，在Meta runner中指向meta_main。

具体地，两者main都在ELF地址0x65c220，访问同一偏移表地址0x18fbc40；普通runner的重定位目标是0x91d270，Meta runner则是0x91d280。这直接证明二者复用公共实现，却通过不同入口选择运行模式。机器码相同还需要结合重定位和上下文解释，不能只比较某个函数的六个字节。

三个完整文件的哈希不同，不能当作同一个文件的不同名字。策略插件与框架内置同名策略也不应未经核对就视为完全相同实现。上述420项仅覆盖两种runner共同的具名框架函数，并非宣称两个完整程序运行等价。

## 现有证据最重要的限制

此次工作执行的是下载、哈希核对、静态反编译和文档整理，没有提交回测，也没有启动这些驱动去生成交易结果。获得了框架函数，并不自动意味着费用、保证金、订单状态机和撮合都已经逐事件验收。

三个框架文件中的run_multi与Account::real_position_update共6个目标，在定向导出和保守模式重试后仍分别遇到反编译进程异常或输入变量重叠错误。其完整汇编与失败原因另行保留，不能将它们计为C伪代码还原成功。因此本文对主循环与持仓更新保持接口层和可追踪局部分支层面的解释，不宣称已经完整恢复整台引擎的事件语义。详见[反编译验收](07_下载清单与反编译验收.md)。

新的材料使“参数怎样进入策略、策略怎样进入引擎、组件怎样交换观察状态”更清晰。下一层若要证明可替换性，应固定具体配置和输入事件，把原程序与重写实现的订单、撤单、成交、账户和发布值逐条比较。

## 可追溯入口

- [公共下单实现](../通用程序_stockidx_20261114/analysis/libfuture_backtest.so/decompiled_repaired/00000000001a8d70.c)。
- [带target的IAP接口](../通用程序_stockidx_20261114/analysis/libfuture_backtest.so/decompiled_repaired/00000000001a8c30.c)。
- [发布接口](../通用程序_stockidx_20261114/analysis/libfuture_backtest.so/decompiled_repaired/00000000001acf60.c)。
- [读取发布值接口](../通用程序_stockidx_20261114/analysis/libfuture_backtest.so/decompiled_repaired/00000000001ad340.c)。
- [普通/Meta runner函数字节及入口重定位比对](../通用程序_stockidx_20261114/runner_common_code_comparison.json)。
- [Exchange下单实现](../通用程序_stockidx_20261114/analysis/libfuture_backtest.so/decompiled_extra/00000000001b46c0.c)。
