# libstrategy_tm5.so：数学化还原与逐分支说明

阈值触发的主动交易腿，同时把符合条件的订单回报收益放入毫秒滚动队列并发布 rolling_pnl。

对应原件：`libstrategy_tm5.so`，SHA-256 `8ef98ebc94e89ad2274a13201ccb43618416a9df18a594dfe9debed63293aba6`。本文为 2026-11-14 新建的逐库数学说明，旧自然语言版保留，若有冲突以本页列出的原始函数与本轮证据为准。

## 记号、输入与可复现边界

设买一价为 $b$，卖一价为 $a$，中价 $m=(a+b)/2$；持仓 $q>0$ 表示多仓，$q<0$ 表示空仓；合约乘数为 $M$。价格步长与数量步长分别为 $\tau_p,\tau_v$。百分比、比例与 bp 不混用：$1\mathrm{bp}=10^{-4}$。`round` 表示本库调用的浮点四舍五入（中点远离零），不是 Python 的 ties-to-even。

外部信号、账户持仓、盘口和交易时间通过 SDK 输入。文中“输入主值/次值”只指信号事件的数值槽；未取得上游预测器源码时，不能把它改名为某个特定 alpha 或宣称这里重新训练了模型。本文公式首先针对有限实数、正价格与正合约乘数；NaN/Inf 的硬件比较分支不应拿普通实数代数擅自合并。

确定性分三层：**机器码实测**表示下面列出的原始 ELF 函数通过合成输入检查；**静态确定**表示已从本库反编译、常量或指令确定控制关系；**尚未闭合**表示明确缺少原始配置、SDK 语义或逐事件状态验收。配置缺省值不代表历史实验启用了该值。

## 四动作不是四个可交换判断

阈值向量按内存顺序定义为

$$T=(L_o,L_c,S_o,S_c).$$

有限输入的分类器严格按以下顺序执行：

$$A(x,T)=\begin{cases}
0\ (开多),&x\ge L_o,\\
3\ (平空),&x<L_o\land x\ge S_c,\\
2\ (开空),&x<L_o\land x<S_c\land x\le S_o,\\
1\ (平多),&x<L_o\land x<S_c\land x>S_o\land x\le L_c,\\
4\ (无动作),&\text{其余}.
\end{cases}$$

先判断开多，再平空，再开空，最后平多。即使配置了交叠阈值也不排序、不纠正。例如四阈值全为零且 $x=0$，结果是开多，不是无动作。动作确定后还要受仓位、盘口、撤单与账户接口约束；“开多”可能先买回空仓，不能把整个订单量记作新增多仓。

错误/无结果与无动作也不能合并：若触发器返回错误变体，调用者走错误/提前返回分支；枚举 4 是成功计算出的“不交易”。

## 点触发的精确公式

调用点触发前，当前信号已写入触发器 `+0x38`，四阈值位于 `+0x40,+0x48,+0x50,+0x58`。令成本倍率为 $\alpha_c$，传入价差尺度为 $h$，PV1 的成本项是

$$c=\alpha_c|h|,\qquad x=\begin{cases}\max(s-c,0),&s>0,\\\min(s+c,0),&s\le0.\end{cases}$$

输出是 $(A(x,T),1)$，第二项是固定票值 1。这里先扣成本、向零截断，再比较阈值；不能改成直接把全部阈值平移，也不能把正负信号都写成 $s-c$。

例如 $T=(3,-1,-3,1)$，$s=4,c=1$ 得 $x=3$，触发开多；$s=-4,c=1$ 得 $x=-3$，触发开空；$s=0.5,c=1$ 得 $x=0$，落在无动作区。例子是合成边界说明。

## 时间窗口触发与投票

每个窗口维护 $(t_i,s_i)$ 队列及 $N,\sum s_i,\sum s_i^2,\sum_{s_i>0}s_i,\sum_{s_i\le0}s_i$。插入当前点后，删除所有 $t-t_i>W$ 的旧点；恰好位于 $t-W$ 的点保留。更新按加减旧值进行，不能随意改为重新求和后声称浮点逐位等价。

$$\mu=\frac{\sum s_i}{N},\qquad \sigma=\sqrt{\max(\sum s_i^2/\max(N,1)-\mu^2,0)}.$$

均值触发把 $\mu$ 送入四阈值比较。Sharpe 触发使用 $\mu/\sigma$，$|\sigma|\le10^{-6}$ 时取零；这是信号窗口统计量，不是策略收益夏普。RSI 使用信号正负值的累计量，令 $P=\sum_{s_i>0}s_i,N_-=\sum_{s_i\le0}s_i$：

$$R=\begin{cases}100-\frac{100}{P/|N_-|+1},&|N_-|>10^{-6},\\50,&\text{其余}.\end{cases}$$

特别注意：`update` 写入和、平方和和均值，但不会自动重算所有版本的 `std_cache`。`WindowsStdTrigger` 读的是缓存槽，不能无条件用上式即时标准差替代；Sharpe 分支另有重算行为。信号带同样需要保留缓存的实际更新顺序。

分位数按有序观测的整数下标取值，使用 $\lfloor qN\rfloor$ 与 $\lfloor(1-q)N\rfloor$，不是线性插值；端点越界可返回错误。多窗口先形成各自候选动作，再计票，最高票比例必须**严格大于** `vote_rate`。并列候选涉及 HashMap 遍历，不应凭业务偏好增加“多头优先”或“平仓优先”。本节是对应窗口函数的静态说明；本轮新增的全库实测不包括每一种窗口的完整状态序列。

## TM5 的收益队列到底累计什么

业务 `on_order` 的回报布局中数量在 `+0x60`，事件秒时刻在 `+0x50`，收益值在 `+0x78`。FFI 包装把外部相应字段拷入这些位置。仅 $|\Delta q|>10^{-5}$ 的回报进入队列，保存

$$(t_j^{ms},P_j)=(1000t_j^{sec},\text{回报收益字段}).$$

行情回调清除 $t-t_j>W$ 的记录，$W=\text{rolling_window_ms}$，然后发布

$$\text{rolling\_pnl}(t)=\sum_{j:t-t_j\le W}P_j.$$

不按绝对数量再加权，不把当前未实现收益自动加进去，也不重新计算复合收益率。时间边界等号保留；默认窗口为 0，意味着下一次不同时间的清理就可能删除旧回报。回报收益的费用口径由 SDK 决定，所以该值不能自动等同于账户扣费净值增量。

## 交易逻辑与 LF4/SM1 的区别

TM5 接收外部主/次信号，用点/窗口触发决定动作，随后走主动报价。它没有 SM1 的独立三类型报价器，也没有 LF4 的 TargetTaskStatus 价格区间和次数状态。`score_taker_rate_alpha` 影响动作信号相对阈值对应的主动比例，而 rolling_pnl 是发布状态，不能在本库里凭空解释成按收益自动调整阈值。

其持仓年龄与挂单超时逻辑在 `on_signal` 内联，应保留旧版分母下限与方向条件，不能套用后续独立四阈值对称函数。六个风险 cap 的缺省也与 SM 系列不同：增仓/净仓手数为 1，相关金额和平仓限额缺省为 0。先看到这些默认值，才能解释同样信号为什么两库可能生成不同请求量。

## 数量、金额与订单请求的层次

所有数量计算都必须区分当前净持仓 $q$、本次有符号请求 $v$、在途预占和最终成交量。对使用金额上限的分支，金额换算以实际选择的订单价格 $p$ 和合约乘数 $M$ 进行，数学上为 $A/(pM)$；原指令常按 `(A/p)/M` 连续除法，逐位复现不能随意改为先乘分母。

负的风险额度在相应限额分支转换为 $+\infty$；零是真实约束。`max_single_add_vol/amt` 约束新增部分，`max_single_net_vol/amt` 约束方向净敞口，`max_single_close_vol/amt` 约束旧反向仓位的平仓部分。开仓动作可以把“新方向允许增量”和“允许平掉的反向旧仓”相加；纯平仓动作不应允许越过零仓继续反向开仓。具体分支中的 `max(amount/(pM),1)` 会形成至少一手的中间额度，但最后仍受其他 cap 和数量步长限制。

实际订单前还有 SDK `margin_filter`、`impact_block_check`、交易时段、允许合约/信号和在途订单检查。它们是可见的调用边界，不能用“所有条件都通过”代替未知历史账户状态。价格与数量最终经过 `round_with_step_f64`；本文保留函数调用及 mode，而不把所有 mode 都武断解释为向下取整。IOC、IAP 或带 target 的 IAP 请求如何被撮合，属于通用引擎和账户模型。

因此复现输出应先比较 `(动作、报价类型、请求价、请求量、撤单ID序列、状态更新)`；仅比较最终收益曲线无法证明这些分支相同。

## 本库全部配置字段：真实解析默认值与状态偏移

下表来自直接加载原始 `.so` 后调用其 `on_begin` 解析器；浮点字段用两个不同标记值匹配同一位置。偏移相对于策略对象起点，不是 ELF 文件偏移。Option 的 None 载荷不读取为默认数值。日志 SDK 为 no-op，其余 SDK 调用会 abort，未调用交易回调。

| 字段 | 解析值/默认状态 | 对象偏移 |
|---|---|---|
| `signal_mode` | "" | `0x28` |
| `pv1_alpha` | 1.0 | `0x70` |
| `cost_alpha` | 1.0 | `0x78` |
| `signal_trigger_mode` | "" | `0x40` |
| `vote_rate` | 0.1 | `0x80` |
| `quantile` | 0.9 | `0x88` |
| `signal_windows_s` | [] | `0x58` |
| `score_taker_rate_alpha` | 0.0 | `0x90` |
| `taker_rate_baseline` | 0.0 | `0x98` |
| `max_taker_rate` | 0.0 | `0xa0` |
| `trade_slippery` | 0.0 | `0xa8` |
| `close_position_block_ms` | 0.0 | `0xb0` |
| `max_single_add_vol` | 1.0 | `0xb8` |
| `max_single_add_amt` | 0.0 | `0xc0` |
| `max_single_net_vol` | 1.0 | `0xc8` |
| `max_single_net_amt` | 0.0 | `0xd0` |
| `max_single_close_vol` | 0.0 | `0xd8` |
| `max_single_close_amt` | 0.0 | `0xe0` |
| `long_open_threshold` | 0.0 | `0xe8` |
| `long_close_threshold` | 0.0 | `0xf0` |
| `short_open_threshold` | 0.0 | `0xf8` |
| `short_close_threshold` | 0.0 | `0x100` |
| `dyn_score_position_ts_threshold_s` | 0.0 | `0x108` |
| `dyn_score_max_position_ts_s` | 0.0 | `0x110` |
| `dyn_score_delta_score` | 0.0 | `0x118` |
| `dyn_pending_position_ts_threshold_s` | 0.0 | `0x120` |
| `dyn_pending_max_position_ts_s` | 0.0 | `0x128` |
| `dyn_pending_order_max_pending_time_ms` | 0.0 | `0x130` |
| `dyn_pending_delta_max_pending_ts_ms` | 0.0 | `0x138` |
| `rolling_window_ms` | 0.0 / 0.0 | `0x20`, `0x140` |

原始回执：[顶层解析](数学化还原_20261114/libstrategy_tm5.config_layout.json)；[字段数组](analysis/libstrategy_tm5/config_field_arrays.json)。默认字段是类型/初始化证据，不能代替历史加密配置的明文。

## 本轮机器码核验及其覆盖范围

| 原始函数/模型 | 案例数 | 通过 | 证据 |
|---|---:|---:|---|
| `point_signal_trigger_pv1_spread` | 1200 | 1200 | [回执](数学化还原_20261114/libstrategy_tm5.leaf_validation.json) |

本页上述新增检查合计 **1200/1200**。这是原始 ELF 叶函数/指定状态函数的合成输入检查，不能扩写为整个策略或全部历史订单的等价验收。点触发与枚举用精确比较；浮点核验容差和逐位比较范围写在脚本/回执中。

## 逐事件复现应保存的状态与尚未闭合项

每次回调记录输入时间、合约/信号标识、原信号值、盘口、SDK 持仓与在途信息；再记录变换信号、有效阈值、动作、报价类型、候选价量、撤单集合以及状态写回。对本库出现的窗口、阶段、配对树、目标任务或门控缓存，还必须记录其回调前后状态。上一个事件即使没有下单，也可能已经修改这些状态。

本轮未取得历史加密配置明文，未启动历史市场回测，未完成全部 SDK 撮合/费用/账户回报的逐事件等价重放。自动反编译的 Rust Option、复合返回值和 SIMD 临时变量不可靠；已纠正部分以本页公式与机器码探测为准，剩余不确定性在本库专属章节明确列出。本文不是能替换原 so 的完整插件源码。

## 本库业务函数证据索引

地址统一使用未重定位 ELF 虚拟地址；Ghidra C 中的 `001xxxxx` 是项目加载基址后的地址，两者不要混淆。下列索引使每个计算/回调都可回到本库证据，不用其他库的同名函数替代。

- [strategy_tm5::signal_trigger::SignalTrigger::update_score](analysis/libstrategy_tm5/decompiled_repaired/000000000004bc30.c)（ELF `0x4bc30`，1845 字节）。
- [strategy_tm5::signal_trigger::SignalTrigger::windows_rsi_trigger](analysis/libstrategy_tm5/decompiled_repaired/000000000004cf30.c)（ELF `0x4cf30`，554 字节）。
- [strategy_tm5::signal_trigger::SignalTrigger::windows_std_trigger](analysis/libstrategy_tm5/decompiled_repaired/000000000004c510.c)（ELF `0x4c510`，264 字节）。
- [strategy_tm5::signal_trigger::SignalTrigger::windows_mean_trigger](analysis/libstrategy_tm5/decompiled_repaired/000000000004c400.c)（ELF `0x4c400`，264 字节）。
- [strategy_tm5::signal_trigger::SignalTrigger::windows_sharpe_trigger](analysis/libstrategy_tm5/decompiled_repaired/000000000004cce0.c)（ELF `0x4cce0`，586 字节）。
- [strategy_tm5::signal_trigger::SignalTrigger::windows_quantile_trigger](analysis/libstrategy_tm5/decompiled_repaired/000000000004c620.c)（ELF `0x4c620`，1717 字节）。
- [strategy_tm5::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](analysis/libstrategy_tm5/decompiled_repaired/000000000004c370.c)（ELF `0x4c370`，137 字节）。
- [strategy_tm5::signal_trigger::SignalTrigger::new](analysis/libstrategy_tm5/decompiled_repaired/000000000004bb00.c)（ELF `0x4bb00`，290 字节）。
- [_ZN12strategy_tm514signal_trigger17enum_rate_counter17h181739a09271ffbbE.llvm.14383927985676670398](analysis/libstrategy_tm5/decompiled_repaired/000000000004d160.c)（ELF `0x4d160`，1378 字节）。
- [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](analysis/libstrategy_tm5/decompiled_repaired/00000000000415c0.c)（ELF `0x415c0`，915 字节）。
- [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](analysis/libstrategy_tm5/decompiled_repaired/0000000000043d80.c)（ELF `0x43d80`，817 字节）。
- [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_order](analysis/libstrategy_tm5/decompiled_repaired/00000000000439e0.c)（ELF `0x439e0`，928 字节）。
- [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](analysis/libstrategy_tm5/decompiled_repaired/00000000000440c0.c)（ELF `0x440c0`，280 字节）。
- [<strategy_tm5::StrategyTM5 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](analysis/libstrategy_tm5/decompiled_repaired/0000000000041960.c)（ELF `0x41960`，8309 字节）。
- [fb_strategy_sdk_abi_version](analysis/libstrategy_tm5/decompiled_repaired/0000000000053e20.c)（ELF `0x53e20`，6 字节）。
- [fb_strategy_sdk_version_str](analysis/libstrategy_tm5/decompiled_repaired/0000000000053e30.c)（ELF `0x53e30`，73 字节）。

[完整反汇编](analysis/libstrategy_tm5/assembly.txt)；[核心伪代码集合](analysis/libstrategy_tm5/核心伪代码.c)；[原自然语言说明](自然语言详解_20261114/27_tm5.md)。
