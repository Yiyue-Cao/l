# libstrategy_lf4.so：数学化还原与逐分支说明

外部信号先建立带价格区间、期限和次数上限的 TargetTaskStatus，后续信号在无在途订单时尝试剩余任务量；行情回调更新已完成量。

对应原件：`libstrategy_lf4.so`，SHA-256 `88e6969f6603fc9864009122b9f1036b732618416a5637847483096012095410`。本文为 2026-11-14 新建的逐库数学说明，旧自然语言版保留，若有冲突以本页列出的原始函数与本轮证据为准。

## 记号、输入与可复现边界

设买一价为 $b$，卖一价为 $a$，中价 $m=(a+b)/2$；持仓 $q>0$ 表示多仓，$q<0$ 表示空仓；合约乘数为 $M$。价格步长与数量步长分别为 $\tau_p,\tau_v$。百分比、比例与 bp 不混用：$1\mathrm{bp}=10^{-4}$。`round` 表示本库调用的浮点四舍五入（中点远离零），不是 Python 的 ties-to-even。

外部信号、账户持仓、盘口和交易时间通过 SDK 输入。文中“输入主值/次值”只指信号事件的数值槽；未取得上游预测器源码时，不能把它改名为某个特定 alpha 或宣称这里重新训练了模型。本文公式首先针对有限实数、正价格与正合约乘数；NaN/Inf 的硬件比较分支不应拿普通实数代数擅自合并。

确定性分三层：**机器码实测**表示下面列出的原始 ELF 函数通过合成输入检查；**静态确定**表示已从本库反编译、常量或指令确定控制关系；**尚未闭合**表示明确缺少原始配置、SDK 语义或逐事件状态验收。配置缺省值不代表历史实验启用了该值。

## 四动作不是四个可交换判断

阈值向量按内存顺序定义为

$$T=(L_o,L_c,S_o,S_c).$$

有限输入的分类器严格按以下顺序执行：

$$A(x,T)=\begin{cases}
0\ (开多),&x\ge L_o,\\
3\ (平空),&x<L_o\land x\ge S_c,\\
2\ (开空),&x<L_o\land x<S_c\land x\le S_o,\\
1\ (平多),&x<L_o\land x<S_c\land x>S_o\land x\le L_c,\\
4\ (无动作),&\text{其余}.
\end{cases}$$

先判断开多，再平空，再开空，最后平多。即使配置了交叠阈值也不排序、不纠正。例如四阈值全为零且 $x=0$，结果是开多，不是无动作。动作确定后还要受仓位、盘口、撤单与账户接口约束；“开多”可能先买回空仓，不能把整个订单量记作新增多仓。

错误/无结果与无动作也不能合并：若触发器返回错误变体，调用者走错误/提前返回分支；枚举 4 是成功计算出的“不交易”。

## 点触发的精确公式

调用点触发前，当前信号已写入触发器 `+0x38`，四阈值位于 `+0x40,+0x48,+0x50,+0x58`。令成本倍率为 $\alpha_c$，传入价差尺度为 $h$，PV1 的成本项是

$$c=\alpha_c|h|,\qquad x=\begin{cases}\max(s-c,0),&s>0,\\\min(s+c,0),&s\le0.\end{cases}$$

输出是 $(A(x,T),1)$，第二项是固定票值 1。这里先扣成本、向零截断，再比较阈值；不能改成直接把全部阈值平移，也不能把正负信号都写成 $s-c$。

例如 $T=(3,-1,-3,1)$，$s=4,c=1$ 得 $x=3$，触发开多；$s=-4,c=1$ 得 $x=-3$，触发开空；$s=0.5,c=1$ 得 $x=0$，落在无动作区。例子是合成边界说明。

## 时间窗口触发与投票

每个窗口维护 $(t_i,s_i)$ 队列及 $N,\sum s_i,\sum s_i^2,\sum_{s_i>0}s_i,\sum_{s_i\le0}s_i$。插入当前点后，删除所有 $t-t_i>W$ 的旧点；恰好位于 $t-W$ 的点保留。更新按加减旧值进行，不能随意改为重新求和后声称浮点逐位等价。

$$\mu=\frac{\sum s_i}{N},\qquad \sigma=\sqrt{\max(\sum s_i^2/\max(N,1)-\mu^2,0)}.$$

均值触发把 $\mu$ 送入四阈值比较。Sharpe 触发使用 $\mu/\sigma$，$|\sigma|\le10^{-6}$ 时取零；这是信号窗口统计量，不是策略收益夏普。RSI 使用信号正负值的累计量，令 $P=\sum_{s_i>0}s_i,N_-=\sum_{s_i\le0}s_i$：

$$R=\begin{cases}100-\frac{100}{P/|N_-|+1},&|N_-|>10^{-6},\\50,&\text{其余}.\end{cases}$$

特别注意：`update` 写入和、平方和和均值，但不会自动重算所有版本的 `std_cache`。`WindowsStdTrigger` 读的是缓存槽，不能无条件用上式即时标准差替代；Sharpe 分支另有重算行为。信号带同样需要保留缓存的实际更新顺序。

分位数按有序观测的整数下标取值，使用 $\lfloor qN\rfloor$ 与 $\lfloor(1-q)N\rfloor$，不是线性插值；端点越界可返回错误。多窗口先形成各自候选动作，再计票，最高票比例必须**严格大于** `vote_rate`。并列候选涉及 HashMap 遍历，不应凭业务偏好增加“多头优先”或“平仓优先”。本节是对应窗口函数的静态说明；本轮新增的全库实测不包括每一种窗口的完整状态序列。

## LF4 的非对称持仓年龄阈值

LF4 不调用本页其他库的四阈值对称 `dynamic_threshold`。`on_signal` 内联计算

$$f=\min\left(\max\left(\frac{h_p-t_0}{\max(t_1-t_0,0.1)},0\right),1\right).$$

开多、开空门槛保持原值。若 $q>10^{-6}$，平多门槛改为 $L_c+f\Delta$，平空门槛不变；否则平多门槛不变，平空门槛改为 $S_c-f\Delta$。这里分母下限为 **0.1 秒**，没有独立新版函数的“负参数关闭”与 $|\Delta|\le10^{-9}$ 早返回；两者不能合并。

挂单时限采用另一组参数：

$$f_p=\min(\max((h_p-t_{p0})/\max(t_{p1}-t_{p0},0.1),0),1),\quad W_{pending}=W_0+f_p\Delta W.$$

先 `margin_filter`，再按此时限调用 `cancel_by_pending_ts`；返回非零的路径提前返回，不继续同一轮下单。然后才做 `impact_block_check`。这里明确的是调用顺序，SDK 返回值的所有错误分类仍由外部接口定义。

## 目标任务的数学状态

按合约保存

$$\mathcal T=(t_0,t_{end},p_{target},v_{target},p_{max},p_{min},n_{max},q_0,v_{done},n_{try},g).$$

新目标的截止时刻 $t_{end}=t_0+\text{max_try_hiter_time_ms}$，目标价格上下界以创建时方向相关盘口价乘 $1\pm\text{price_range_bp}\times10^{-4}$ 形成。`on_depth` 查询实际持仓后写

$$v_{done}=q_{current}-q_0,$$

并复位当前行情的尝试标志。它不是把每次请求量简单累加为已完成量。

每次重试同时要求：买卖两侧在途数量计数均小于 1、$|v_{target}-v_{done}|>10^{-6}$、$n_{try}<n_{max}$、当前时刻严格小于 $t_{end}$、当前行情标志允许，以及价格没有越界。正目标拒绝 $a>p_{max}$，负目标拒绝 $b<p_{min}$；边界相等可通过。通过后请求量为

$$v_{retry}=\operatorname{RoundStep}(v_{target}-v_{done},\tau_v,1).$$

重试限价采用目标的上/下界再按价格步长处理，不是无条件追到最新对手价。次数和期限都使用严格 `<`：刚好到期限、刚好用完次数均不能再重试。

## 手数约束与初始化含义

本库没有增仓/净仓/平仓金额上限字段。设增仓、净仓、平仓手数上限为 $A,N,C$，开多原始目标量为

$$\max(\min(A,N-\max(q,0))+\min(C,\max(-q,0)),0),$$

开空为相应负方向的组合；纯平仓最多消掉当前反向仓。缺省 $A=N=1$，$C$ 为最大有限 double，`max_try_hiter_times=0`、`max_try_hiter_time_ms=0`，所以缺省并不自动启用有持续时间的重试过程。

尚未闭合的点是每一种下单失败、取消和目标替换路径中 `n_try/g` 的完整写回序列；已确定的重试门槛、剩余量计算和行情完成量更新如上，不再只称作“有时间和次数控制”。

## 本库全部配置字段：真实解析默认值与状态偏移

下表来自直接加载原始 `.so` 后调用其 `on_begin` 解析器；浮点字段用两个不同标记值匹配同一位置。偏移相对于策略对象起点，不是 ELF 文件偏移。Option 的 None 载荷不读取为默认数值。日志 SDK 为 no-op，其余 SDK 调用会 abort，未调用交易回调。

| 字段 | 解析值/默认状态 | 对象偏移 |
|---|---|---|
| `signal_mode` | "" | `0x0` |
| `pv1_alpha` | 1.0 | `0x48` |
| `cost_alpha` | 1.0 | `0x50` |
| `signal_trigger_mode` | "" | `0x18` |
| `vote_rate` | 0.1 | `0x58` |
| `quantile` | 0.9 | `0x60` |
| `signal_windows_s` | [] | `0x30` |
| `taker_rate_baseline` | 0.0 | `0x68` |
| `max_taker_rate` | 0.0 | `0x70` |
| `trade_slippery` | 0.0 | `0x78` |
| `close_position_block_ms` | 0.0 | `0x80` |
| `max_single_add_vol` | 1.0 | `0x88` |
| `max_single_net_vol` | 1.0 | `0x90` |
| `max_single_close_vol` | 1.7976931348623157e+308 | `0x98` |
| `long_open_threshold` | 0.0 | `0xa0` |
| `long_close_threshold` | 0.0 | `0xa8` |
| `short_open_threshold` | 0.0 | `0xb0` |
| `short_close_threshold` | 0.0 | `0xb8` |
| `dyn_score_position_ts_threshold_s` | 0.0 | `0xc0` |
| `dyn_score_max_position_ts_s` | 0.0 | `0xc8` |
| `dyn_score_delta_score` | 0.0 | `0xd0` |
| `dyn_pending_position_ts_threshold_s` | 0.0 | `0xd8` |
| `dyn_pending_max_position_ts_s` | 0.0 | `0xe0` |
| `dyn_pending_order_max_pending_time_ms` | 0.0 | `0xe8` |
| `dyn_pending_delta_max_pending_ts_ms` | 0.0 | `0xf0` |
| `max_try_hiter_times` | 0.0 | `0xf8` |
| `max_try_hiter_time_ms` | 0.0 | `0x100` |
| `price_range_bp` | 0.0 | `0x108` |

原始回执：[顶层解析](数学化还原_20261114/libstrategy_lf4.config_layout.json)；[字段数组](analysis/libstrategy_lf4/config_field_arrays.json)。默认字段是类型/初始化证据，不能代替历史加密配置的明文。

## 本轮机器码核验及其覆盖范围

| 原始函数/模型 | 案例数 | 通过 | 证据 |
|---|---:|---:|---|
| `point_signal_trigger_pv1_spread` | 1200 | 1200 | [回执](数学化还原_20261114/libstrategy_lf4.leaf_validation.json) |

本页上述新增检查合计 **1200/1200**。这是原始 ELF 叶函数/指定状态函数的合成输入检查，不能扩写为整个策略或全部历史订单的等价验收。点触发与枚举用精确比较；浮点核验容差和逐位比较范围写在脚本/回执中。

## 逐事件复现应保存的状态与尚未闭合项

每次回调记录输入时间、合约/信号标识、原信号值、盘口、SDK 持仓与在途信息；再记录变换信号、有效阈值、动作、报价类型、候选价量、撤单集合以及状态写回。对本库出现的窗口、阶段、配对树、目标任务或门控缓存，还必须记录其回调前后状态。上一个事件即使没有下单，也可能已经修改这些状态。

本轮未取得历史加密配置明文，未启动历史市场回测，未完成全部 SDK 撮合/费用/账户回报的逐事件等价重放。自动反编译的 Rust Option、复合返回值和 SIMD 临时变量不可靠；已纠正部分以本页公式与机器码探测为准，剩余不确定性在本库专属章节明确列出。本文不是能替换原 so 的完整插件源码。

## 本库业务函数证据索引

地址统一使用未重定位 ELF 虚拟地址；Ghidra C 中的 `001xxxxx` 是项目加载基址后的地址，两者不要混淆。下列索引使每个计算/回调都可回到本库证据，不用其他库的同名函数替代。

- [strategy_lf4::signal_trigger::SignalTrigger::update_score](analysis/libstrategy_lf4/decompiled_repaired/000000000004b690.c)（ELF `0x4b690`，1845 字节）。
- [strategy_lf4::signal_trigger::SignalTrigger::windows_rsi_trigger](analysis/libstrategy_lf4/decompiled_repaired/000000000004c990.c)（ELF `0x4c990`，554 字节）。
- [strategy_lf4::signal_trigger::SignalTrigger::windows_std_trigger](analysis/libstrategy_lf4/decompiled_repaired/000000000004bf70.c)（ELF `0x4bf70`，264 字节）。
- [strategy_lf4::signal_trigger::SignalTrigger::windows_mean_trigger](analysis/libstrategy_lf4/decompiled_repaired/000000000004be60.c)（ELF `0x4be60`，264 字节）。
- [strategy_lf4::signal_trigger::SignalTrigger::windows_sharpe_trigger](analysis/libstrategy_lf4/decompiled_repaired/000000000004c740.c)（ELF `0x4c740`，586 字节）。
- [strategy_lf4::signal_trigger::SignalTrigger::windows_quantile_trigger](analysis/libstrategy_lf4/decompiled_repaired/000000000004c080.c)（ELF `0x4c080`，1717 字节）。
- [strategy_lf4::signal_trigger::SignalTrigger::point_signal_trigger_pv1_spread](analysis/libstrategy_lf4/decompiled_repaired/000000000004bdd0.c)（ELF `0x4bdd0`，137 字节）。
- [strategy_lf4::signal_trigger::SignalTrigger::new](analysis/libstrategy_lf4/decompiled_repaired/000000000004b560.c)（ELF `0x4b560`，290 字节）。
- [_ZN12strategy_lf414signal_trigger17enum_rate_counter17hae8899c0d26c9baeE.llvm.754907104417532979](analysis/libstrategy_lf4/decompiled_repaired/000000000004cbc0.c)（ELF `0x4cbc0`，1378 字节）。
- [<strategy_lf4::TargetTaskStatus as core::fmt::Debug>::fmt](analysis/libstrategy_lf4/decompiled_repaired/0000000000044c20.c)（ELF `0x44c20`，307 字节）。
- [<strategy_lf4::StrategyLF4 as future_backtest_sdk::plugin::StrategyPlugin>::on_begin](analysis/libstrategy_lf4/decompiled_repaired/0000000000041c80.c)（ELF `0x41c80`，1371 字节）。
- [<strategy_lf4::StrategyLF4 as future_backtest_sdk::plugin::StrategyPlugin>::on_depth](analysis/libstrategy_lf4/decompiled_repaired/00000000000421e0.c)（ELF `0x421e0`，448 字节）。
- [<strategy_lf4::StrategyLF4 as future_backtest_sdk::plugin::StrategyPlugin>::on_finish](analysis/libstrategy_lf4/decompiled_repaired/0000000000044b00.c)（ELF `0x44b00`，280 字节）。
- [<strategy_lf4::StrategyLF4 as future_backtest_sdk::plugin::StrategyPlugin>::on_signal](analysis/libstrategy_lf4/decompiled_repaired/00000000000423a0.c)（ELF `0x423a0`，10073 字节）。
- [fb_strategy_sdk_abi_version](analysis/libstrategy_lf4/decompiled_repaired/000000000004efd0.c)（ELF `0x4efd0`，6 字节）。
- [fb_strategy_sdk_version_str](analysis/libstrategy_lf4/decompiled_repaired/000000000004efe0.c)（ELF `0x4efe0`，73 字节）。

[完整反汇编](analysis/libstrategy_lf4/assembly.txt)；[核心伪代码集合](analysis/libstrategy_lf4/核心伪代码.c)；[原自然语言说明](自然语言详解_20261114/19_lf4.md)。
